
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUser } from '@/contexts/UserContext';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { AlertCircle, Loader2 } from 'lucide-react';

const Index = () => {
  const navigate = useNavigate();
  const { session, loading, error } = useUser();
  const [loadingTimeout, setLoadingTimeout] = useState(false);
  
  useEffect(() => {
    // Set up loading timeout for UI feedback
    const timeoutId = setTimeout(() => {
      if (loading) {
        setLoadingTimeout(true);
      }
    }, 8000); // 8 seconds timeout
    
    return () => clearTimeout(timeoutId);
  }, [loading]);
  
  useEffect(() => {
    // Only redirect after loading is complete
    if (!loading) {
      console.log('Auth state determined in Index page:', session ? 'session exists' : 'no session');
      
      if (session) {
        console.log('Session exists in Index, redirecting to dashboard');
        navigate('/dashboard');
      } else {
        console.log('No session in Index, redirecting to login');
        navigate('/login');
      }
    }
  }, [navigate, session, loading]);

  // If there's an error or timeout, show option to go to login
  if (error || loadingTimeout) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="max-w-md w-full space-y-8 p-6">
          <div className="text-center">
            <div className="flex justify-center mb-4">
              <AlertCircle className="h-12 w-12 text-amber-500" />
            </div>
            <h1 className="text-2xl font-bold mb-2">Sistema de Regulação</h1>
            <p className="text-muted-foreground mb-6">
              {error ? "Erro ao inicializar o sistema" : "O carregamento está demorando mais que o esperado"}
            </p>
            <Button
              onClick={() => navigate('/login')}
              className="w-full"
            >
              Ir para Login
            </Button>
          </div>
        </div>
      </div>
    );
  }
  
  // Render loading state while checking authentication
  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="max-w-md w-full space-y-4">
        <div className="text-center">
          <div className="flex justify-center items-center mb-4">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
          <h1 className="text-2xl font-bold mb-2">Sistema de Regulação</h1>
          <p className="text-muted-foreground">Carregando sistema...</p>
        </div>
        <div className="space-y-2">
          <Skeleton className="h-4 w-3/4 mx-auto" />
          <Skeleton className="h-4 w-1/2 mx-auto" />
          <Skeleton className="h-4 w-2/3 mx-auto" />
        </div>
      </div>
    </div>
  );
};

export default Index;
