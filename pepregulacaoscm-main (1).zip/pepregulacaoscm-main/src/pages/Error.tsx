
import { useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Home, ArrowLeft, AlertTriangle } from "lucide-react";
import { useUser } from "@/contexts/UserContext";

interface ErrorProps {
  title?: string;
  message?: string;
  statusCode?: number;
}

const Error = ({ 
  title = "Erro no Sistema", 
  message = "Ocorreu um erro inesperado. Por favor, tente novamente mais tarde.", 
  statusCode = 500 
}: ErrorProps) => {
  const navigate = useNavigate();
  const { currentUser } = useUser();
  const location = useLocation();
  
  // Get error details from location state if available
  const state = location.state as ErrorProps | null;
  const errorTitle = state?.title || title;
  const errorMessage = state?.message || message;
  const errorCode = state?.statusCode || statusCode;

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="text-center space-y-6 max-w-md mx-auto p-6">
        <div className="w-20 h-20 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center mx-auto mb-4">
          <AlertTriangle className="h-10 w-10" />
        </div>
        <h1 className="text-6xl font-bold text-amber-600">{errorCode}</h1>
        <h2 className="text-2xl font-semibold mb-2">{errorTitle}</h2>
        <p className="text-muted-foreground mb-4">{errorMessage}</p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            onClick={() => navigate(-1)} 
            variant="outline"
            className="flex items-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Voltar</span>
          </Button>
          <Button 
            onClick={() => navigate(currentUser ? '/dashboard' : '/login')} 
            className="flex items-center gap-2"
          >
            <Home className="h-4 w-4" />
            <span>{currentUser ? 'Ir para o Dashboard' : 'Ir para o Login'}</span>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Error;
