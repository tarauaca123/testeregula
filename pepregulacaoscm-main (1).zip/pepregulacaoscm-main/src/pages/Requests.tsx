
import React, { useState, useCallback } from 'react';
import { Clock, CheckCircle, XCircle, Building2 } from 'lucide-react';
import { StatCard } from '@/components/dashboard/StatCard';
import { RequestFilters } from '@/components/requests/RequestFilters';
import { RequestActions } from '@/components/requests/RequestActions';
import { RequestTable } from '@/components/requests/RequestTable';
import { useRequestData } from '@/hooks/useRequestData';
import { useToast } from '@/components/ui/use-toast';
import { useUser } from '@/contexts/UserContext';

const Requests = () => {
  const {
    filteredRequests,
    stats,
    isLoading,
    statsLoading,
    error,
    searchTerm,
    setSearchTerm,
    statusFilter,
    priorityFilter,
    handleStatusFilterChange,
    handlePriorityFilterChange,
    handleDeleteRequest,
    updateRequestStatus,
    canCreateRequest,
    canEvaluateRequest,
    canDeleteRequest,
    refetch
  } = useRequestData();
  
  const { toast } = useToast();
  const { currentUser, hasPermission } = useUser();
  const [isProcessing, setIsProcessing] = useState(false);
  
  // Check if user can see all requests
  const canSeeAllRequests = hasPermission(['admin', 'manager']);

  // Use useCallback to prevent recreating this function on each render
  const safeDeleteRequest = useCallback(async (requestId: string) => {
    if (isProcessing) {
      console.log('Already processing a request, ignoring');
      return; // Prevent multiple simultaneous deletes
    }
    
    console.log('Starting delete operation for request:', requestId);
    
    try {
      setIsProcessing(true);
      await handleDeleteRequest(requestId);
      // Toast is shown in the RequestTable component
    } catch (error) {
      console.error("Error in delete operation:", error);
      toast({
        variant: "destructive",
        title: "Erro na operação",
        description: "Houve um problema ao excluir a solicitação. Tente novamente.",
      });
    } finally {
      console.log('Delete operation completed, resetting state');
      // Use setTimeout to ensure state updates are processed asynchronously
      setTimeout(() => {
        setIsProcessing(false);
      }, 0);
    }
  }, [handleDeleteRequest, isProcessing, toast]);

  if (error) {
    console.error("Error fetching requests:", error);
    return (
      <div className="p-4 text-center">
        <h2 className="text-xl font-semibold text-red-600">Erro ao carregar solicitações</h2>
        <p className="mt-2 text-gray-600">Ocorreu um erro ao carregar as solicitações. Tente novamente mais tarde.</p>
        <button 
          className="mt-4 bg-primary text-white px-4 py-2 rounded hover:bg-primary/90" 
          onClick={() => refetch()}
          disabled={isProcessing}
        >
          Tentar novamente
        </button>
      </div>
    );
  }

  // Determine the effective loading state
  const effectiveLoading = isLoading || isProcessing;

  return (
    <div className="space-y-4">
      {!canSeeAllRequests && currentUser?.unit && (
        <div className="bg-muted/50 p-3 rounded-lg flex items-center gap-2 text-sm">
          <Building2 className="h-4 w-4 text-muted-foreground" />
          <span>
            Mostrando solicitações da unidade: <strong>{currentUser.unit.name}</strong>
          </span>
        </div>
      )}
    
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard 
          title="Total de Solicitações" 
          value={statsLoading ? "..." : stats?.totalRequests} 
          icon={Clock} 
        />
        <StatCard 
          title="Solicitações Pendentes" 
          value={statsLoading ? "..." : stats?.pendingRequests} 
          icon={Clock}
          color="warning"
        />
        <StatCard 
          title="Solicitações Aprovadas" 
          value={statsLoading ? "..." : stats?.approvedRequests} 
          icon={CheckCircle}
          color="success"
        />
        <StatCard 
          title="Solicitações Rejeitadas" 
          value={statsLoading ? "..." : stats?.rejectedRequests} 
          icon={XCircle}
          color="destructive"
        />
      </div>
      
      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <RequestFilters
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          statusFilter={statusFilter}
          handleStatusFilterChange={handleStatusFilterChange}
          priorityFilter={priorityFilter}
          handlePriorityFilterChange={handlePriorityFilterChange}
        />
        
        <RequestActions 
          canCreateRequest={canCreateRequest} 
        />
      </div>
      
      <RequestTable
        filteredRequests={filteredRequests}
        isLoading={effectiveLoading}
        updateRequestStatus={updateRequestStatus}
        handleDeleteRequest={safeDeleteRequest}
        canEvaluateRequest={canEvaluateRequest}
        canDeleteRequest={canDeleteRequest}
      />
    </div>
  );
};

export default Requests;
