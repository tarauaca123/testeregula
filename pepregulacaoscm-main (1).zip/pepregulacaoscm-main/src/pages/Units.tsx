
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Search, 
  Plus, 
  Building2,
  Users,
  FileText,
  Map,
  Loader2,
  TestTube,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useHealthUnits } from '@/hooks/useHealthUnits';
import { useUser } from '@/contexts/UserContext';

const Units = () => {
  const navigate = useNavigate();
  const { hasPermission } = useUser();
  const [searchTerm, setSearchTerm] = useState('');
  const { units, loading, error } = useHealthUnits();
  
  // Filter units based on search term
  const filteredUnits = units.filter(unit => 
    unit.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    unit.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
    unit.type.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  // Permissions check for actions
  const canCreateUnit = hasPermission(['admin']);
  const canEditUnit = hasPermission(['admin']);
  
  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Buscar por nome, código ou tipo..."
            className="pl-9"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        {canCreateUnit && (
          <Button onClick={() => navigate('/units/new')} className="flex gap-2">
            <Plus className="h-4 w-4" />
            <span>Nova Unidade</span>
          </Button>
        )}
      </div>
      
      {loading ? (
        <div className="flex justify-center py-8">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      ) : error ? (
        <div className="text-center py-8 text-destructive">
          Ocorreu um erro ao carregar as unidades.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredUnits.length > 0 ? (
            filteredUnits.map((unit) => (
              <Card key={unit.id} className="overflow-hidden">
                <CardHeader className="bg-muted/30 py-4 flex flex-row items-center justify-between space-y-0">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-medical-primary flex items-center justify-center text-white">
                      <Building2 className="h-5 w-5" />
                    </div>
                    <CardTitle className="text-lg">{unit.name}</CardTitle>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <span className="sr-only">Abrir menu</span>
                        <span className="h-4 w-4">⋯</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => navigate(`/units/${unit.id}`)}>
                        Visualizar
                      </DropdownMenuItem>
                      {canEditUnit && (
                        <DropdownMenuItem onClick={() => navigate(`/units/edit/${unit.id}`)}>
                          Editar
                        </DropdownMenuItem>
                      )}
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => navigate(`/units/${unit.id}/procedures`)}>
                        Gerenciar Procedimentos
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => navigate(`/units/${unit.id}/professionals`)}>
                        Ver Profissionais
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => navigate(`/units/${unit.id}/requests`)}>
                        Ver Solicitações
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div className="flex items-center gap-2 text-sm">
                      <div className="text-muted-foreground">Código:</div>
                      <div className="font-medium">{unit.code}</div>
                    </div>
                    
                    <div className="flex items-center gap-2 text-sm">
                      <div className="text-muted-foreground">Tipo:</div>
                      <div className="font-medium">{unit.type}</div>
                    </div>
                    
                    <div className="flex items-start gap-2 text-sm">
                      <Map className="h-4 w-4 text-muted-foreground mt-0.5" />
                      <div>{unit.address}</div>
                    </div>
                    
                    <div className="grid grid-cols-3 gap-2 mt-4">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="flex gap-2 items-center"
                        onClick={() => navigate(`/units/${unit.id}/professionals`)}
                      >
                        <Users className="h-4 w-4" />
                        <span>Profissionais</span>
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="flex gap-2 items-center"
                        onClick={() => navigate(`/units/${unit.id}/requests`)}
                      >
                        <FileText className="h-4 w-4" />
                        <span>Solicitações</span>
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="flex gap-2 items-center"
                        onClick={() => navigate(`/units/${unit.id}/procedures`)}
                      >
                        <TestTube className="h-4 w-4" />
                        <span>Procedimentos</span>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="col-span-full py-6 text-center text-muted-foreground">
              Nenhuma unidade encontrada.
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default Units;
