
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import * as z from 'zod';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useUser } from '@/contexts/UserContext';

// Form validation schema
const unitFormSchema = z.object({
  name: z.string().min(3, 'O nome deve ter pelo menos 3 caracteres'),
  code: z.string().min(1, 'O código é obrigatório'),
  type: z.string().min(1, 'O tipo de unidade é obrigatório'),
  address: z.string().min(5, 'O endereço deve ter pelo menos 5 caracteres'),
  city: z.string().min(2, 'A cidade deve ter pelo menos 2 caracteres'),
  state: z.string().min(2, 'O estado deve ter pelo menos 2 caracteres'),
  zipCode: z.string().min(8, 'O CEP deve ter pelo menos 8 caracteres'),
  phone: z.string().optional(),
  email: z.string().email('Email inválido').optional().or(z.literal('')),
});

type UnitFormValues = z.infer<typeof unitFormSchema>;

const UnitNew = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { currentUser } = useUser();

  // Form initialization
  const form = useForm<UnitFormValues>({
    resolver: zodResolver(unitFormSchema),
    defaultValues: {
      name: '',
      code: '',
      type: '',
      address: '',
      city: '',
      state: '',
      zipCode: '',
      phone: '',
      email: '',
    },
  });

  const onSubmit = async (values: UnitFormValues) => {
    if (!currentUser) {
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Você precisa estar autenticado para criar uma unidade.",
      });
      return;
    }

    try {
      const { data, error } = await supabase
        .from('health_units')
        .insert({
          name: values.name,
          code: values.code,
          type: values.type,
          address: values.address,
          city: values.city,
          state: values.state,
          zip_code: values.zipCode,
          phone: values.phone || null,
          email: values.email || null,
          created_by: currentUser.id,
        })
        .select();

      if (error) throw error;

      toast({
        title: "Unidade criada",
        description: "Unidade de saúde criada com sucesso.",
      });

      navigate(`/units`);
    } catch (error: any) {
      console.error('Error creating unit:', error);
      
      // Check for duplicate code error
      if (error.code === '23505' && error.message.includes('code')) {
        toast({
          variant: "destructive",
          title: "Erro ao criar unidade",
          description: "Já existe uma unidade com este código. Use um código diferente.",
        });
      } else {
        toast({
          variant: "destructive",
          title: "Erro ao criar unidade",
          description: "Ocorreu um erro ao criar a unidade. Tente novamente.",
        });
      }
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-6">
        <Button 
          variant="outline" 
          size="icon" 
          onClick={() => navigate('/units')}
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-2xl font-bold">Nova Unidade</h1>
      </div>
      
      <Card>
        <CardContent className="pt-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Unit Name */}
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nome da Unidade</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Ex: Hospital Municipal São José" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Unit Code */}
                <FormField
                  control={form.control}
                  name="code"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Código da Unidade</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Ex: HMSJ001" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Unit Type */}
                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tipo de Unidade</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione o tipo" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="hospital">Hospital</SelectItem>
                          <SelectItem value="ubs">Unidade Básica de Saúde (UBS)</SelectItem>
                          <SelectItem value="clinic">Clínica</SelectItem>
                          <SelectItem value="emergency">Unidade de Pronto Atendimento (UPA)</SelectItem>
                          <SelectItem value="specializedCenter">Centro Especializado</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Address */}
                <FormField
                  control={form.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem className="md:col-span-2">
                      <FormLabel>Endereço</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Ex: Rua das Flores, 123" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* City */}
                <FormField
                  control={form.control}
                  name="city"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Cidade</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Ex: São Paulo" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* State */}
                <FormField
                  control={form.control}
                  name="state"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Estado</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Ex: SP" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Zip Code */}
                <FormField
                  control={form.control}
                  name="zipCode"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>CEP</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Ex: 01001-000" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Phone */}
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Telefone (opcional)</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Ex: (11) 3333-4444" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Email */}
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email (opcional)</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Ex: contato@hospital.com" type="email" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="flex justify-end gap-2">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => navigate('/units')}
                >
                  Cancelar
                </Button>
                <Button type="submit">Criar Unidade</Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
};

export default UnitNew;
