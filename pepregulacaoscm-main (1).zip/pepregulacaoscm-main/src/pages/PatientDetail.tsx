
import React from 'react';
import { usePatientDetail } from '@/hooks/usePatientDetail';
import { useUser } from '@/contexts/UserContext';
import { Skeleton } from '@/components/ui/skeleton';
import { PatientDetailHeader } from '@/components/patients/detail/PatientDetailHeader';
import { PatientPersonalInfo } from '@/components/patients/detail/PatientPersonalInfo';
import { PatientAddressInfo } from '@/components/patients/detail/PatientAddressInfo';
import { PatientContactInfo } from '@/components/patients/detail/PatientContactInfo';
import { PatientNotFound } from '@/components/patients/detail/PatientNotFound';

const PatientDetail = () => {
  const { patient, loading, formatCPF } = usePatientDetail();
  const { hasPermission } = useUser();
  
  // Permissions check for actions
  const canEditPatient = hasPermission(['admin', 'manager', 'operator', 'receptionist']);
  const canDeactivatePatient = hasPermission(['admin', 'manager']);
  
  if (loading) {
    return (
      <div className="space-y-4">
        <PatientDetailHeader
          patient={null}
          loading={true}
          canEditPatient={canEditPatient}
          canDeactivatePatient={canDeactivatePatient}
        />
        
        <PatientPersonalInfo 
          patient={null as any} 
          formatCPF={formatCPF} 
          loading={true} 
        />
        
        <PatientAddressInfo
          patient={null as any}
          loading={true}
        />
        
        <PatientContactInfo
          patient={null as any}
          loading={true}
        />
      </div>
    );
  }
  
  if (!patient) {
    return <PatientNotFound />;
  }
  
  return (
    <div className="space-y-4">
      <PatientDetailHeader
        patient={patient}
        loading={false}
        canEditPatient={canEditPatient}
        canDeactivatePatient={canDeactivatePatient}
      />
      
      <PatientPersonalInfo 
        patient={patient} 
        formatCPF={formatCPF} 
      />
      
      <PatientAddressInfo patient={patient} />
      
      <PatientContactInfo patient={patient} />
    </div>
  );
};

export default PatientDetail;
