
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { PatientFilters } from '@/components/patients/PatientFilters';
import { PatientActions } from '@/components/patients/PatientActions';
import { PatientListTable } from '@/components/patients/PatientListTable';
import { usePatients } from '@/hooks/usePatients';
import { useUser } from '@/contexts/UserContext';
import { Skeleton } from '@/components/ui/skeleton';
import { Building2 } from 'lucide-react';

const Patients = () => {
  const { hasPermission, currentUser } = useUser();
  const {
    searchTerm,
    setSearchTerm,
    statusFilter,
    handleStatusFilterChange,
    filteredPatients,
    formatCPF,
    loading,
    canSeeAllPatients
  } = usePatients();
  
  // Verificação de permissões para ações
  const canCreatePatient = hasPermission(['admin', 'manager', 'operator', 'receptionist']);
  const canEditPatient = hasPermission(['admin', 'manager', 'operator', 'receptionist']);
  const canDeactivatePatient = hasPermission(['admin', 'manager']);
  
  return (
    <div className="space-y-4">
      {!canSeeAllPatients && currentUser?.unit && (
        <div className="bg-muted/50 p-3 rounded-lg flex items-center gap-2 text-sm">
          <Building2 className="h-4 w-4 text-muted-foreground" />
          <span>
            Mostrando pacientes da unidade: <strong>{currentUser.unit.name}</strong>
          </span>
        </div>
      )}
      
      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <PatientFilters
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          statusFilter={statusFilter}
          handleStatusFilterChange={handleStatusFilterChange}
        />
        
        <PatientActions 
          canCreatePatient={canCreatePatient} 
        />
      </div>
      
      <Card>
        <CardHeader className="py-4">
          <CardTitle className="text-lg">Lista de Pacientes</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="space-y-2">
              <Skeleton className="h-12 w-full" />
              <Skeleton className="h-12 w-full" />
              <Skeleton className="h-12 w-full" />
              <Skeleton className="h-12 w-full" />
              <Skeleton className="h-12 w-full" />
            </div>
          ) : (
            <PatientListTable
              patients={filteredPatients}
              canEditPatient={canEditPatient}
              canDeactivatePatient={canDeactivatePatient}
              formatCPF={formatCPF}
            />
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Patients;
