
import React, { useState, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useUnitRequests } from '@/hooks/useUnitRequests';
import { useToast } from '@/components/ui/use-toast';
import { UnitRequestsTable } from '@/components/units/UnitRequestsTable';
import { RequestDeleteDialog } from '@/components/requests/RequestDeleteDialog';
import { RequestsLoadingState } from '@/components/units/RequestsLoadingState';
import { RequestsStatusMessage } from '@/components/units/RequestsStatusMessage';

const UnitRequests = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { requests, loading, error, deleteRequest, refetch } = useUnitRequests(id);
  const { toast } = useToast();
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [requestToDelete, setRequestToDelete] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const openDeleteDialog = useCallback((requestId: string) => {
    if (isDeleting) {
      console.log('Already processing a deletion, ignoring');
      return; // Prevent opening dialog during deletion
    }
    console.log('Opening delete dialog for request:', requestId);
    setRequestToDelete(requestId);
    setIsDeleteDialogOpen(true);
  }, [isDeleting]);

  const confirmDelete = useCallback(async () => {
    if (!requestToDelete || !id || isDeleting) {
      console.log('Invalid delete state, aborting');
      return;
    }
    
    console.log('Confirming delete for request:', requestToDelete);
    
    try {
      setIsDeleting(true);
      await deleteRequest(requestToDelete);
      
      toast({
        title: "Solicitação excluída",
        description: "A solicitação foi excluída com sucesso.",
      });
    } catch (error) {
      console.error("Error deleting request:", error);
      toast({
        variant: "destructive",
        title: "Erro ao excluir",
        description: "Ocorreu um erro ao excluir a solicitação.",
      });
    } finally {
      console.log('Delete operation completed, resetting state');
      // Use setTimeout to ensure state updates happen asynchronously
      setTimeout(() => {
        setIsDeleting(false);
        setRequestToDelete(null);
        setIsDeleteDialogOpen(false);
      }, 0);
    }
  }, [deleteRequest, id, isDeleting, requestToDelete, toast]);

  const effectiveLoading = loading || isDeleting;

  const handleDialogOpenChange = useCallback((open: boolean) => {
    // Prevent closing dialog during deletion
    if (isDeleting && !open) {
      console.log('Preventing dialog close during deletion');
      return;
    }
    console.log('Setting dialog open state:', open);
    setIsDeleteDialogOpen(open);
    
    // If closing the dialog, also reset the requestToDelete
    if (!open) {
      setRequestToDelete(null);
    }
  }, [isDeleting]);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 mb-6">
        <Button 
          variant="outline" 
          size="icon" 
          onClick={() => navigate(`/units/${id}`)}
          disabled={isDeleting}
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-2xl font-bold">Solicitações da Unidade</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Lista de Solicitações</CardTitle>
        </CardHeader>
        <CardContent>
          {effectiveLoading ? (
            <RequestsLoadingState />
          ) : error ? (
            <RequestsStatusMessage type="error" />
          ) : requests.length === 0 ? (
            <RequestsStatusMessage type="empty" />
          ) : (
            <UnitRequestsTable 
              requests={requests} 
              onDeleteRequest={openDeleteDialog} 
            />
          )}
        </CardContent>
      </Card>

      <RequestDeleteDialog 
        isOpen={isDeleteDialogOpen}
        isDeleting={isDeleting}
        onOpenChange={handleDialogOpenChange}
        onConfirm={confirmDelete}
      />
    </div>
  );
};

export default UnitRequests;
