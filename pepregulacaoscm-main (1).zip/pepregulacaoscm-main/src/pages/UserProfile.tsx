
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { useUser } from '@/contexts/UserContext';
import { UnitInformation } from '@/components/dashboard/UnitInformation';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Info, User } from 'lucide-react';

const UserProfile = () => {
  const { currentUser } = useUser();

  // Get user initials for avatar fallback
  const getUserInitials = () => {
    if (!currentUser?.name) return 'U';
    return currentUser.name
      .split(' ')
      .map(name => name[0])
      .join('')
      .toUpperCase()
      .substring(0, 2);
  };

  const roleLabels = {
    admin: { label: 'Administrador', class: 'bg-red-100 text-red-800' },
    manager: { label: 'Gerente', class: 'bg-purple-100 text-purple-800' },
    regulator: { label: 'Regulador', class: 'bg-blue-100 text-blue-800' },
    doctor: { label: 'Médico', class: 'bg-green-100 text-green-800' },
    operator: { label: 'Operador', class: 'bg-amber-100 text-amber-800' },
    receptionist: { label: 'Recepcionista', class: 'bg-indigo-100 text-indigo-800' },
    readonly: { label: 'Somente Leitura', class: 'bg-gray-100 text-gray-800' }
  };

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-3xl font-bold tracking-tight">Perfil do Usuário</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-1">
          <CardHeader className="pb-2">
            <CardTitle>Informações Pessoais</CardTitle>
            <CardDescription>
              Seus dados básicos de identificação
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center space-y-4 mb-6">
              <Avatar className="h-24 w-24">
                <AvatarImage src="" alt={currentUser?.name || 'Usuario'} />
                <AvatarFallback className="text-lg bg-medical-primary text-white">
                  {getUserInitials()}
                </AvatarFallback>
              </Avatar>
              <div className="text-center">
                <h2 className="text-xl font-semibold">{currentUser?.name || 'Não informado'}</h2>
                <p className="text-sm text-muted-foreground">{currentUser?.email || 'Não informado'}</p>
                <div className="mt-2">
                  {currentUser?.role && (
                    <Badge className={roleLabels[currentUser.role]?.class || 'bg-gray-100'}>
                      {roleLabels[currentUser.role]?.label || currentUser.role}
                    </Badge>
                  )}
                </div>
              </div>
            </div>

            <div className="space-y-4 pt-4 border-t">
              <div>
                <h3 className="text-sm font-medium text-muted-foreground mb-1">ID do Usuário</h3>
                <p className="text-sm font-mono bg-muted p-2 rounded overflow-x-auto">
                  {currentUser?.id || 'Não disponível'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="md:col-span-2 space-y-6">
          {currentUser?.unit ? (
            <UnitInformation currentUser={currentUser} />
          ) : (
            <Alert>
              <Info className="h-4 w-4" />
              <AlertTitle>Unidade não associada</AlertTitle>
              <AlertDescription>
                Você não está associado a nenhuma unidade de saúde no momento.
              </AlertDescription>
            </Alert>
          )}

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Acessos do Sistema</CardTitle>
              <CardDescription>Informações sobre seus acessos e permissões</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground mb-1">Nível de Acesso</h3>
                  <p className="font-medium capitalize">{currentUser?.role || 'Não definido'}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground mb-1">Status da Conta</h3>
                  <p className="font-medium">
                    <Badge variant="secondary" className="bg-green-100 text-green-800">
                      Ativo
                    </Badge>
                  </p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground mb-1">Última Atualização</h3>
                  <p className="font-medium">
                    {new Date().toLocaleDateString('pt-BR', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })}
                  </p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground mb-1">Gerenciador</h3>
                  <p className="font-medium">Sistema de Regulação</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default UserProfile;
