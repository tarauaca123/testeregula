
import React from 'react';
import { DashboardStats } from '@/components/dashboard/DashboardStats';
import { StatusCharts } from '@/components/dashboard/StatusCharts';
import { RecentRequestsTable } from '@/components/dashboard/RecentRequestsTable';
import { UnitInformation } from '@/components/dashboard/UnitInformation';
import { useUser } from '@/contexts/UserContext';
import { useDashboardStats } from '@/hooks/useDashboardStats';
import { useRecentRequests } from '@/hooks/useRecentRequests';
import { useUnitRecentRequests } from '@/hooks/useUnitRecentRequests';
import { Skeleton } from '@/components/ui/skeleton';
import { Building2 } from 'lucide-react';

const Dashboard = () => {
  const { currentUser, hasPermission } = useUser();
  const { stats, loading: statsLoading } = useDashboardStats();
  const { requests: allRecentRequests, loading: allRequestsLoading } = useRecentRequests(5);
  const { requests: unitRecentRequests, loading: unitRequestsLoading } = useUnitRecentRequests(5);
  
  // Determine if user is admin or manager to show all requests or just unit requests
  const isAdmin = hasPermission(['admin', 'manager']);
  const recentRequests = isAdmin ? allRecentRequests : unitRecentRequests;
  const requestsLoading = isAdmin ? allRequestsLoading : unitRequestsLoading;

  // Loading skeletons
  if (statsLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-32 w-full" />
          ))}
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Skeleton className="h-80 w-full" />
          <Skeleton className="h-80 w-full" />
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Skeleton className="h-96 w-full lg:col-span-2" />
          <Skeleton className="h-96 w-full" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {!isAdmin && currentUser?.unit && (
        <div className="bg-muted/50 p-3 rounded-lg flex items-center gap-2">
          <Building2 className="h-5 w-5 text-muted-foreground" />
          <span>
            Você está visualizando dados da unidade: <strong>{currentUser.unit.name}</strong>
          </span>
        </div>
      )}
      
      <DashboardStats stats={stats} />
      
      <StatusCharts stats={stats} statsLoading={statsLoading} />
      
      <RecentRequestsTable 
        recentRequests={recentRequests}
        requestsLoading={requestsLoading}
        isFilteredByUnit={!isAdmin}
      />
      
      <UnitInformation currentUser={currentUser} />
    </div>
  );
};

export default Dashboard;
