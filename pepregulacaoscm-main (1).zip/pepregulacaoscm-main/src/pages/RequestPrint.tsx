
import React from 'react';
import { Card } from '@/components/ui/card';
import { usePrintRequest } from '@/hooks/usePrintRequest';
import { PrintHeader } from '@/components/requests/print/PrintHeader';
import { PrintError } from '@/components/requests/print/PrintError';
import { PrintContent } from '@/components/requests/print/PrintContent';

const RequestPrint = () => {
  const {
    id,
    request,
    isLoading,
    error,
    navigate,
    printContentRef,
    handlePrint,
    baseUrl
  } = usePrintRequest();

  if (error) {
    return <PrintError />;
  }
  
  return (
    <div className="space-y-6">
      {/* Header with print button */}
      <PrintHeader handlePrint={handlePrint} />
      
      {/* Content for printing */}
      <Card className="p-6">
        <PrintContent
          isLoading={isLoading}
          id={id}
          request={request}
          printContentRef={printContentRef}
          baseUrl={baseUrl}
        />
      </Card>
    </div>
  );
};

export default RequestPrint;
