
import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ProceduresList } from '@/components/procedures/ProceduresList';
import { useUser } from '@/contexts/UserContext';

const UnitProcedures = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { hasPermission, currentUser } = useUser();
  
  // Check if user has permission to manage procedures
  // Now including receptionist in permissions to add procedures
  const canManage = hasPermission(['admin', 'manager', 'receptionist']);
  
  // Admins can change the unit in the context of the unit procedures page
  const isAdmin = hasPermission(['admin']);
  
  // If user is receptionist or manager, use their assigned unit
  const userUnitId = currentUser?.unit?.id;
  
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 mb-6">
        <Button 
          variant="outline" 
          size="icon" 
          onClick={() => navigate(`/units/${id || userUnitId}`)}
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-2xl font-bold">Procedimentos da Unidade</h1>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Gerenciar Procedimentos</CardTitle>
        </CardHeader>
        <CardContent>
          <ProceduresList 
            unitId={id || userUnitId} 
            canManage={canManage} 
            allowUnitChange={isAdmin}
          />
        </CardContent>
      </Card>
    </div>
  );
};

export default UnitProcedures;
