
import React, { useEffect } from 'react';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { PatientForm } from '@/components/patients/PatientForm';
import { useToast } from '@/components/ui/use-toast';
import { useUser } from '@/contexts/UserContext';
import { supabase } from '@/integrations/supabase/client';

const PatientNew = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { currentUser } = useUser();
  
  // Verifica se o usuário está autenticado
  useEffect(() => {
    const checkAuth = async () => {
      const { data } = await supabase.auth.getSession();
      
      if (!data.session) {
        toast({
          variant: "destructive",
          title: "Acesso não autorizado",
          description: "É necessário estar logado para cadastrar pacientes."
        });
        navigate('/login');
      }
    };
    
    checkAuth();
  }, [navigate, toast]);
  
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 mb-6">
        <Button variant="outline" size="icon" onClick={() => navigate('/patients')}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-2xl font-bold">Cadastro de Paciente</h1>
      </div>
      
      <PatientForm 
        isNew={true} 
        userData={{ userId: currentUser?.id }} 
      />
    </div>
  );
};

export default PatientNew;
