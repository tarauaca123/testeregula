
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";

const UserPreferences = () => {
  const { toast } = useToast();

  const handleSavePreferences = () => {
    toast({
      title: "Preferências salvas",
      description: "Suas preferências foram atualizadas com sucesso",
    });
  };

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Preferências</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Notificações</CardTitle>
          <CardDescription>
            Configure como você deseja receber notificações
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="notification-email" className="text-base">Email</Label>
                <p className="text-sm text-muted-foreground">Receber notificações por email</p>
              </div>
              <Switch id="notification-email" defaultChecked />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="notification-system" className="text-base">Sistema</Label>
                <p className="text-sm text-muted-foreground">Receber notificações no sistema</p>
              </div>
              <Switch id="notification-system" defaultChecked />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="notification-updates" className="text-base">Atualizações</Label>
                <p className="text-sm text-muted-foreground">Receber atualizações sobre novas funcionalidades</p>
              </div>
              <Switch id="notification-updates" />
            </div>
          </div>
          
          <div className="pt-4">
            <Button onClick={handleSavePreferences}>Salvar Preferências</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default UserPreferences;
