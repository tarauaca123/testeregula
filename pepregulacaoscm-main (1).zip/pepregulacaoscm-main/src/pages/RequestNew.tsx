
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { RequestForm } from '@/components/requests/form/RequestForm';

const RequestNew = () => {
  const navigate = useNavigate();
  
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-6">
        <Button 
          variant="outline" 
          size="icon" 
          onClick={() => navigate('/requests')}
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-2xl font-bold">Nova Solicitação</h1>
      </div>
      
      <RequestForm />
    </div>
  );
};

export default RequestNew;
