
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { PatientForm } from '@/components/patients/PatientForm';
import { usePatientDetail } from '@/hooks/usePatientDetail';
import { Skeleton } from '@/components/ui/skeleton';

const PatientEdit = () => {
  const navigate = useNavigate();
  const { patient, loading, isNewPatient } = usePatientDetail();
  
  if (loading) {
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2 mb-6">
          <Button variant="outline" size="icon" disabled>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <Skeleton className="h-8 w-40" />
        </div>
        
        <div className="space-y-4">
          <Skeleton className="h-64 w-full" />
          <Skeleton className="h-64 w-full" />
          <Skeleton className="h-64 w-full" />
          <Skeleton className="h-64 w-full" /> {/* One more for signature card */}
        </div>
      </div>
    );
  }
  
  if (!patient && !isNewPatient) {
    return (
      <div className="flex flex-col items-center justify-center py-10 space-y-4">
        <h2 className="text-xl font-semibold">Paciente não encontrado</h2>
        <p className="text-muted-foreground">O paciente solicitado não existe ou foi removido.</p>
        <Button onClick={() => navigate('/patients')}>
          Voltar para lista de pacientes
        </Button>
      </div>
    );
  }
  
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-6">
        <Button 
          variant="outline" 
          size="icon" 
          onClick={() => navigate(`/patients/${patient?.id}`)}
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-2xl font-bold">Editar Paciente</h1>
      </div>
      
      <PatientForm patient={patient} isNew={false} />
    </div>
  );
};

export default PatientEdit;
