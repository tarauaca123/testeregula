
import React from 'react';
import { 
  Users, 
  Settings as SettingsIcon, 
  Database
} from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useUser } from '@/contexts/UserContext';
import { useNavigate } from 'react-router-dom';
import { UsersTabContent } from '@/components/settings/UsersTabContent';
import { SystemTabContent } from '@/components/settings/SystemTabContent';
import { DataTabContent } from '@/components/settings/DataTabContent';

const Settings = () => {
  const { hasPermission } = useUser();
  const navigate = useNavigate();
  
  // Check if user has admin access
  if (!hasPermission(['admin'])) {
    // Redirect to dashboard if not admin
    navigate('/dashboard');
    return null;
  }
  
  return (
    <div>
      <Tabs defaultValue="users">
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="users" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            <span>Usuários</span>
          </TabsTrigger>
          <TabsTrigger value="system" className="flex items-center gap-2">
            <SettingsIcon className="h-4 w-4" />
            <span>Sistema</span>
          </TabsTrigger>
          <TabsTrigger value="data" className="flex items-center gap-2">
            <Database className="h-4 w-4" />
            <span>Importar/Exportar</span>
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="users">
          <UsersTabContent />
        </TabsContent>
        
        <TabsContent value="system">
          <SystemTabContent />
        </TabsContent>
        
        <TabsContent value="data">
          <DataTabContent />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Settings;
