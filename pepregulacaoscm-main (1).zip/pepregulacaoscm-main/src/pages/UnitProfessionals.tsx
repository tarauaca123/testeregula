
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, UserPlus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { useUnitProfessionals } from '@/hooks/useUnitProfessionals';
import { useUser } from '@/contexts/UserContext';
import { ProfessionalForm } from '@/components/professionals/ProfessionalForm';
import { ProfessionalsTable } from '@/components/professionals/ProfessionalsTable';
import { useRemoveProfessional } from '@/hooks/useRemoveProfessional';

const UnitProfessionals = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { currentUser, hasPermission } = useUser();
  const { professionals, loading, error } = useUnitProfessionals(id);
  const [addingProfessional, setAddingProfessional] = useState(false);
  const { removeProfessional } = useRemoveProfessional();

  const canManageProfessionals = hasPermission(['admin', 'manager']);

  const handleError = () => {
    navigate('/error', { 
      state: { 
        title: 'Erro na página de profissionais', 
        message: 'Ocorreu um erro ao carregar os profissionais desta unidade.',
        statusCode: 500
      }
    });
  };

  useEffect(() => {
    if (error) {
      console.error("Error in professionals page:", error);
    }
  }, [error]);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 mb-6">
        <Button 
          variant="outline" 
          size="icon" 
          onClick={() => navigate(`/units/${id}`)}
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-2xl font-bold">Profissionais da Unidade</h1>
      </div>

      {canManageProfessionals && (
        <div className="mb-6">
          {!addingProfessional ? (
            <Button onClick={() => setAddingProfessional(true)} className="flex gap-2">
              <UserPlus className="h-4 w-4" />
              <span>Adicionar Profissional</span>
            </Button>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle>Adicionar Profissional</CardTitle>
                <CardDescription>Adicione profissionais que já possuem uma conta no sistema.</CardDescription>
              </CardHeader>
              <CardContent>
                <ProfessionalForm 
                  unitId={id || ''} 
                  onSuccess={() => {
                    setAddingProfessional(false);
                    window.location.reload();
                  }} 
                  onCancel={() => setAddingProfessional(false)} 
                />
              </CardContent>
            </Card>
          )}
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Lista de Profissionais</CardTitle>
        </CardHeader>
        <CardContent>
          <ProfessionalsTable
            professionals={professionals}
            loading={loading}
            error={error}
            canManage={canManageProfessionals}
            onRemove={removeProfessional}
            onError={handleError}
          />
        </CardContent>
      </Card>
    </div>
  );
};

export default UnitProfessionals;
