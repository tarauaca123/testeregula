
import React from 'react';
import { useRequestDetail } from '@/hooks/useRequestDetail';
import { RequestDetailHeader } from '@/components/requests/detail/RequestDetailHeader';
import { RequestStatusCard } from '@/components/requests/detail/RequestStatusCard';
import { RequestHistoryCard } from '@/components/requests/detail/RequestHistoryCard';
import { PatientInfoCard } from '@/components/requests/detail/PatientInfoCard';
import { RequestInfoCard } from '@/components/requests/detail/RequestInfoCard';
import { ErrorState } from '@/components/requests/detail/ErrorState';
import { RequestProceduresSection } from '@/components/requests/procedures/RequestProceduresSection';

const RequestDetail = () => {
  const {
    id,
    request,
    isLoading,
    error,
    refetch,
    navigate,
    canEvaluateRequest,
    updateRequestStatus
  } = useRequestDetail();
  
  if (error) {
    return <ErrorState onBack={() => navigate(-1)} onRetry={() => refetch()} />;
  }
  
  return (
    <div className="space-y-6">
      {/* Header */}
      <RequestDetailHeader id={id} />
      
      {/* Main content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left column - Request information */}
        <div className="lg:col-span-2 space-y-6">
          {/* Status card */}
          <RequestStatusCard 
            isLoading={isLoading}
            request={request}
            canEvaluateRequest={canEvaluateRequest}
            updateRequestStatus={updateRequestStatus}
          />
          
          {/* Procedures section */}
          <RequestProceduresSection 
            requestId={id} 
            readOnly={!canEvaluateRequest}
          />
          
          {/* History card */}
          <RequestHistoryCard 
            isLoading={isLoading}
            history={request?.history}
          />
        </div>
        
        {/* Right column - Patient and requester information */}
        <div className="space-y-6">
          {/* Patient card */}
          <PatientInfoCard 
            isLoading={isLoading}
            patient={request?.patient}
          />
          
          {/* Request info card */}
          <RequestInfoCard 
            isLoading={isLoading}
            requestedBy={request?.requestedBy}
            requestedAt={request?.requested_at}
            evaluatedBy={request?.evaluatedBy}
            evaluatedAt={request?.evaluated_at}
          />
        </div>
      </div>
    </div>
  );
};

export default RequestDetail;
