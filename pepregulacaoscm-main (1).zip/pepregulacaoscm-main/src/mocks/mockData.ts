
import { 
  Patient, 
  RegulationRequest, 
  RequestStatus, 
  RequestPriority, 
  RequestType,
  IcdCode,
  Specialty,
  MedicalProcedure,
  HealthUnit,
  User,
  UserRole
} from '@/types';

// Mock health units
export const mockHealthUnits: HealthUnit[] = [
  {
    id: '1',
    name: 'Hospital Municipal',
    code: 'HM001',
    address: 'Rua Principal, 123',
    type: 'HOSPITAL'
  },
  {
    id: '2',
    name: 'UBS Central',
    code: 'UBS001',
    address: 'Avenida Central, 456',
    type: 'UBS'
  },
  {
    id: '3',
    name: 'Clínica Especializada',
    code: 'CE001',
    address: 'Rua dos Especialistas, 789',
    type: 'CLINIC'
  }
];

// Mock users
export const mockUsers: User[] = [
  {
    id: '1',
    name: 'John Doe',
    email: 'admin@example.com',
    role: 'admin',
    unit: mockHealthUnits[0]
  },
  {
    id: '2',
    name: 'Jane Smith',
    email: 'doctor@example.com',
    role: 'doctor',
    unit: mockHealthUnits[0]
  },
  {
    id: '3',
    name: 'Carlos Souza',
    email: 'regulator@example.com',
    role: 'regulator',
    unit: mockHealthUnits[1]
  },
  {
    id: '4',
    name: 'Maria Oliveira',
    email: 'receptionist@example.com',
    role: 'receptionist',
    unit: mockHealthUnits[2]
  }
];

// Mock patients
export const mockPatients: Patient[] = [
  {
    id: '1',
    name: 'João da Silva',
    cpf: '123.456.789-00',
    rg: '12.345.678-9',
    cns: '123456789012345',
    birthDate: '1980-05-15',
    gender: 'male',
    race: 'Pardo',
    bloodType: 'O+',
    motherName: 'Maria da Silva',
    fatherName: 'José da Silva',
    address: {
      street: 'Rua das Flores',
      number: '123',
      neighborhood: 'Centro',
      city: 'São Paulo',
      state: 'SP',
      zipCode: '01001-000'
    },
    contacts: [
      {
        type: 'phone',
        value: '(11) 3333-4444'
      },
      {
        type: 'mobile',
        value: '(11) 98888-9999'
      },
      {
        type: 'email',
        value: 'joao.silva@email.com'
      }
    ],
    status: 'active',
    createdAt: '2023-01-15T10:30:00Z',
    updatedAt: '2023-01-15T10:30:00Z'
  },
  {
    id: '2',
    name: 'Maria Oliveira',
    cpf: '987.654.321-00',
    rg: '98.765.432-1',
    cns: '987654321098765',
    birthDate: '1975-08-22',
    gender: 'female',
    race: 'Branca',
    bloodType: 'A+',
    motherName: 'Ana Oliveira',
    fatherName: 'Pedro Oliveira',
    address: {
      street: 'Avenida Paulista',
      number: '1500',
      complement: 'Apto 501',
      neighborhood: 'Bela Vista',
      city: 'São Paulo',
      state: 'SP',
      zipCode: '01310-200'
    },
    contacts: [
      {
        type: 'mobile',
        value: '(11) 97777-8888'
      },
      {
        type: 'email',
        value: 'maria.oliveira@email.com'
      }
    ],
    status: 'active',
    createdAt: '2023-02-10T14:45:00Z',
    updatedAt: '2023-02-10T14:45:00Z'
  },
  {
    id: '3',
    name: 'Pedro Santos',
    cpf: '111.222.333-44',
    cns: '111222333444555',
    birthDate: '1990-11-30',
    gender: 'male',
    motherName: 'Júlia Santos',
    address: {
      street: 'Rua Augusta',
      number: '789',
      neighborhood: 'Consolação',
      city: 'São Paulo',
      state: 'SP',
      zipCode: '01305-000'
    },
    contacts: [
      {
        type: 'mobile',
        value: '(11) 96666-7777'
      }
    ],
    status: 'active',
    createdAt: '2023-03-05T09:15:00Z',
    updatedAt: '2023-03-05T09:15:00Z'
  },
  {
    id: '4',
    name: 'Ana Souza',
    cpf: '444.555.666-77',
    rg: '44.555.666-7',
    cns: '444555666777888',
    birthDate: '1985-04-12',
    gender: 'female',
    race: 'Negra',
    bloodType: 'B-',
    motherName: 'Beatriz Souza',
    fatherName: 'Carlos Souza',
    address: {
      street: 'Rua Oscar Freire',
      number: '456',
      complement: 'Bloco B, Apto 202',
      neighborhood: 'Jardins',
      city: 'São Paulo',
      state: 'SP',
      zipCode: '01426-000'
    },
    contacts: [
      {
        type: 'phone',
        value: '(11) 2222-3333'
      },
      {
        type: 'mobile',
        value: '(11) 95555-6666'
      },
      {
        type: 'email',
        value: 'ana.souza@email.com'
      }
    ],
    status: 'inactive',
    createdAt: '2023-04-20T11:00:00Z',
    updatedAt: '2023-05-15T16:30:00Z'
  }
];

// Mock ICD codes
export const mockIcdCodes: IcdCode[] = [
  { code: 'I10', description: 'Hipertensão essencial (primária)' },
  { code: 'E11', description: 'Diabetes mellitus tipo 2' },
  { code: 'J45', description: 'Asma' },
  { code: 'M54.4', description: 'Lumbago com ciática' },
  { code: 'K29.7', description: 'Gastrite, não especificada' }
];

// Mock specialties
export const mockSpecialties: Specialty[] = [
  { id: '1', name: 'Cardiologia', description: 'Especialidade que trata de doenças do coração' },
  { id: '2', name: 'Ortopedia', description: 'Especialidade que trata de doenças do sistema músculo-esquelético' },
  { id: '3', name: 'Neurologia', description: 'Especialidade que trata de doenças do sistema nervoso' },
  { id: '4', name: 'Endocrinologia', description: 'Especialidade que trata de doenças hormonais' },
  { id: '5', name: 'Oftalmologia', description: 'Especialidade que trata de doenças dos olhos' }
];

// Mock medical procedures
export const mockMedicalProcedures: MedicalProcedure[] = [
  { 
    id: '1', 
    name: 'Consulta em Cardiologia', 
    code: 'CARD001', 
    specialty: mockSpecialties[0] 
  },
  { 
    id: '2', 
    name: 'Eletrocardiograma', 
    code: 'CARD002', 
    specialty: mockSpecialties[0] 
  },
  { 
    id: '3', 
    name: 'Consulta em Ortopedia', 
    code: 'ORTO001', 
    specialty: mockSpecialties[1] 
  },
  { 
    id: '4', 
    name: 'Raio-X de Membros Inferiores', 
    code: 'ORTO002', 
    specialty: mockSpecialties[1] 
  },
  { 
    id: '5', 
    name: 'Consulta em Neurologia', 
    code: 'NEURO001', 
    specialty: mockSpecialties[2] 
  }
];

// Mock regulation requests
export const mockRequests: RegulationRequest[] = [
  {
    id: '1',
    patient: mockPatients[0],
    requestType: 'consultation',
    specialty: 'Cardiologia',
    priority: 'high',
    icdCode: 'I10',
    clinicalReason: 'Paciente com hipertensão não controlada, necessita avaliação cardiológica urgente.',
    suggestedUnit: mockHealthUnits[2],
    status: 'pending',
    requestedBy: mockUsers[1],
    requestedAt: '2023-06-10T09:00:00Z',
    updatedAt: '2023-06-10T09:00:00Z',
    history: [
      {
        id: '1-1',
        status: 'pending',
        date: '2023-06-10T09:00:00Z',
        user: mockUsers[1],
        observations: 'Solicitação inicial'
      }
    ]
  },
  {
    id: '2',
    patient: mockPatients[1],
    requestType: 'exam',
    specialty: 'Ortopedia',
    priority: 'medium',
    icdCode: 'M54.4',
    clinicalReason: 'Paciente com dor lombar crônica, necessita avaliação por exame de imagem.',
    status: 'approved',
    requestedBy: mockUsers[1],
    requestedAt: '2023-06-08T14:30:00Z',
    updatedAt: '2023-06-09T10:15:00Z',
    evaluatedBy: mockUsers[2],
    evaluatedAt: '2023-06-09T10:15:00Z',
    observations: 'Aprovado para realização de exame na unidade de referência.',
    history: [
      {
        id: '2-1',
        status: 'pending',
        date: '2023-06-08T14:30:00Z',
        user: mockUsers[1],
        observations: 'Solicitação inicial'
      },
      {
        id: '2-2',
        status: 'approved',
        date: '2023-06-09T10:15:00Z',
        user: mockUsers[2],
        observations: 'Aprovado para realização de exame na unidade de referência.'
      }
    ]
  },
  {
    id: '3',
    patient: mockPatients[2],
    requestType: 'consultation',
    specialty: 'Endocrinologia',
    priority: 'low',
    icdCode: 'E11',
    clinicalReason: 'Paciente com diabetes tipo 2, necessita acompanhamento especializado.',
    suggestedUnit: mockHealthUnits[1],
    status: 'rejected',
    requestedBy: mockUsers[1],
    requestedAt: '2023-06-05T11:45:00Z',
    updatedAt: '2023-06-07T13:20:00Z',
    evaluatedBy: mockUsers[2],
    evaluatedAt: '2023-06-07T13:20:00Z',
    observations: 'Paciente já em acompanhamento na rede básica. Não há necessidade de especialista no momento.',
    history: [
      {
        id: '3-1',
        status: 'pending',
        date: '2023-06-05T11:45:00Z',
        user: mockUsers[1],
        observations: 'Solicitação inicial'
      },
      {
        id: '3-2',
        status: 'rejected',
        date: '2023-06-07T13:20:00Z',
        user: mockUsers[2],
        observations: 'Paciente já em acompanhamento na rede básica. Não há necessidade de especialista no momento.'
      }
    ]
  },
  {
    id: '4',
    patient: mockPatients[3],
    requestType: 'hospitalization',
    specialty: 'Neurologia',
    priority: 'high',
    icdCode: 'G40',
    clinicalReason: 'Paciente com crises convulsivas recorrentes, necessita internação para investigação.',
    status: 'processing',
    requestedBy: mockUsers[1],
    requestedAt: '2023-06-12T08:30:00Z',
    updatedAt: '2023-06-12T15:45:00Z',
    evaluatedBy: mockUsers[2],
    evaluatedAt: '2023-06-12T15:45:00Z',
    observations: 'Em processo de avaliação para definição da unidade de internação.',
    history: [
      {
        id: '4-1',
        status: 'pending',
        date: '2023-06-12T08:30:00Z',
        user: mockUsers[1],
        observations: 'Solicitação inicial'
      },
      {
        id: '4-2',
        status: 'processing',
        date: '2023-06-12T15:45:00Z',
        user: mockUsers[2],
        observations: 'Em processo de avaliação para definição da unidade de internação.'
      }
    ]
  }
];

// Generate dashboard stats
export const getDashboardStats = () => {
  const totalRequests = mockRequests.length;
  const pendingRequests = mockRequests.filter(r => r.status === 'pending').length;
  const highPriorityRequests = mockRequests.filter(r => r.priority === 'high').length;
  const approvedRequests = mockRequests.filter(r => r.status === 'approved').length;
  
  const requestsByStatus = {
    pending: pendingRequests,
    approved: approvedRequests,
    rejected: mockRequests.filter(r => r.status === 'rejected').length,
    processing: mockRequests.filter(r => r.status === 'processing').length
  };
  
  const requestsByType = {
    consultation: mockRequests.filter(r => r.requestType === 'consultation').length,
    exam: mockRequests.filter(r => r.requestType === 'exam').length,
    surgery: mockRequests.filter(r => r.requestType === 'surgery').length,
    hospitalization: mockRequests.filter(r => r.requestType === 'hospitalization').length
  };
  
  const requestsByPriority = {
    high: highPriorityRequests,
    medium: mockRequests.filter(r => r.priority === 'medium').length,
    low: mockRequests.filter(r => r.priority === 'low').length
  };
  
  return {
    totalRequests,
    pendingRequests,
    highPriorityRequests,
    approvedRequests,
    requestsByStatus,
    requestsByType,
    requestsByPriority
  };
};
