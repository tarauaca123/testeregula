
import { supabase } from '@/integrations/supabase/client';

// Get request stats with optional unit filtering
export const fetchRequestStats = async (unitId?: string) => {
  try {
    // Base query for counting requests
    const baseQuery = supabase.from('requests');
    
    // Get total requests count
    let totalCountQuery = baseQuery.select('*', { count: 'exact', head: true });
    
    // If unitId is provided, filter by suggested_unit_id
    if (unitId) {
      totalCountQuery = totalCountQuery.eq('suggested_unit_id', unitId);
    }

    const { count: totalRequests, error: totalError } = await totalCountQuery;
    if (totalError) throw totalError;

    // Get pending requests count
    let pendingCountQuery = supabase.from('requests').select('*', { count: 'exact', head: true }).eq('status', 'pending');
    if (unitId) {
      pendingCountQuery = pendingCountQuery.eq('suggested_unit_id', unitId);
    }
    const { count: pendingRequests, error: pendingError } = await pendingCountQuery;
    if (pendingError) throw pendingError;

    // Get approved requests count
    let approvedCountQuery = supabase.from('requests').select('*', { count: 'exact', head: true }).eq('status', 'approved');
    if (unitId) {
      approvedCountQuery = approvedCountQuery.eq('suggested_unit_id', unitId);
    }
    const { count: approvedRequests, error: approvedError } = await approvedCountQuery;
    if (approvedError) throw approvedError;

    // Get rejected requests count
    let rejectedCountQuery = supabase.from('requests').select('*', { count: 'exact', head: true }).eq('status', 'rejected');
    if (unitId) {
      rejectedCountQuery = rejectedCountQuery.eq('suggested_unit_id', unitId);
    }
    const { count: rejectedRequests, error: rejectedError } = await rejectedCountQuery;
    if (rejectedError) throw rejectedError;

    return {
      totalRequests: totalRequests || 0,
      pendingRequests: pendingRequests || 0,
      approvedRequests: approvedRequests || 0,
      rejectedRequests: rejectedRequests || 0,
      requestsByType: {},
      requestsByStatus: {
        pending: pendingRequests || 0,
        approved: approvedRequests || 0,
        rejected: rejectedRequests || 0,
      }
    };
  } catch (error) {
    console.error('Error in fetchRequestStats:', error);
    return {
      totalRequests: 0,
      pendingRequests: 0,
      approvedRequests: 0,
      rejectedRequests: 0,
      requestsByType: {},
      requestsByStatus: {
        pending: 0,
        approved: 0,
        rejected: 0,
      }
    };
  }
};
