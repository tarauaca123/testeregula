
import { supabase } from '@/integrations/supabase/client';
import { RequestRecord } from '@/types';

// Fetch requests from Supabase with optional unit filtering
export const fetchRequests = async (unitId?: string): Promise<RequestRecord[]> => {
  try {
    // Create a query builder
    let query = supabase.from('requests').select('*');
    
    // If unitId is provided, filter by suggested_unit_id
    if (unitId) {
      query = query.eq('suggested_unit_id', unitId);
    }
    
    // Complete the query execution
    const { data, error } = await query.order('requested_at', { ascending: false });

    if (error) throw error;

    // Now fetch related data separately and handle errors gracefully
    const requests = await Promise.all((data || []).map(async (request) => {
      try {
        // Fetch patient data with error handling
        const { data: patientData, error: patientError } = await supabase
          .from('patients')
          .select('*')
          .eq('id', request.patient_id)
          .single();

        if (patientError) {
          console.error('Error fetching patient:', patientError);
          // Create a minimal patient record with id to avoid breaks
          return {
            ...request,
            patient: { 
              id: request.patient_id,
              name: 'Unknown',
              cpf: 'N/A',
              birth_date: new Date().toISOString(),
              gender: 'other',
              status: 'active',
              created_at: request.requested_at,
              updated_at: request.updated_at
            },
            requestedBy: null,
            evaluatedBy: null,
            suggestedUnit: null
          } as RequestRecord;
        }

        // Fetch requester profile
        const { data: requesterData, error: requesterError } = await supabase
          .from('profiles')
          .select('id, name, email')
          .eq('id', request.requested_by)
          .single();
            
        if (requesterError) console.error('Error fetching requester:', requesterError);

        // Fetch evaluator profile if exists
        let evaluatorData = null;
        if (request.evaluated_by) {
          const { data } = await supabase
            .from('profiles')
            .select('id, name, email')
            .eq('id', request.evaluated_by)
            .single();
          evaluatorData = data;
        }

        // Fetch suggested unit if exists
        let unitData = null;
        if (request.suggested_unit_id) {
          const { data: unitResult, error: unitError } = await supabase
            .from('health_units')
            .select('id, name, type')
            .eq('id', request.suggested_unit_id);
            
          if (!unitError && unitResult && unitResult.length > 0) {
            unitData = unitResult[0];
          }
        }

        return {
          ...request,
          patient: patientData,
          requestedBy: requesterData || null,
          evaluatedBy: evaluatorData || null,
          suggestedUnit: unitData || null
        } as RequestRecord;
      } catch (error) {
        console.error('Error enriching request data:', error);
        // Return a basic record with the error
        return {
          ...request,
          patient: { 
            id: request.patient_id,
            name: 'Error loading patient',
            cpf: 'N/A',
            birth_date: new Date().toISOString(),
            gender: 'other',
            status: 'active',
            created_at: request.requested_at,
            updated_at: request.updated_at
          },
          requestedBy: null,
          evaluatedBy: null,
          suggestedUnit: null
        } as RequestRecord;
      }
    }));

    return requests;
  } catch (error) {
    console.error('Error in fetchRequests:', error);
    return [];
  }
};
