
import { supabase } from '@/integrations/supabase/client';
import { RequestStatus } from '@/types';

// Delete request
export const deleteRequest = async (requestId: string) => {
  const { error } = await supabase
    .from('requests')
    .delete()
    .eq('id', requestId);

  if (error) throw error;
};

// Update request status
export const updateRequestStatus = async (
  requestId: string, 
  status: RequestStatus, 
  userId: string | undefined,
  userName: string | undefined,
  userEmail: string | undefined
) => {
  // Get the current request to access its history
  const { data: currentRequest } = await supabase
    .from('requests')
    .select('history')
    .eq('id', requestId)
    .single();
  
  const now = new Date().toISOString();
  
  // Create the new history entry
  const historyEntry = {
    id: crypto.randomUUID(),
    status,
    date: now,
    user: {
      id: userId,
      name: userName,
      email: userEmail
    }
  };
  
  // Create a proper history array by combining existing history with new entry
  const updatedHistory = Array.isArray(currentRequest?.history) 
    ? [...currentRequest.history, historyEntry] 
    : [historyEntry];
  
  // For debugging
  console.log('Updating request status to:', status);
  
  // Update the request
  const { data, error } = await supabase
    .from('requests')
    .update({
      status,
      evaluated_by: userId,
      evaluated_at: now,
      history: updatedHistory
    })
    .eq('id', requestId);

  if (error) {
    console.error('Error updating request status:', error);
    throw error;
  }
  
  console.log('Status update successful:', data);
};
