
import { supabase } from '@/integrations/supabase/client';

export interface UnitProcedure {
  id: string;
  unit_id: string;
  name: string;
  description: string | null;
  price: number | null;
  type: 'exam' | 'surgery' | 'consultation';
  created_at: string;
  updated_at: string;
  created_by?: string;
  created_by_name?: string;
}

export interface RequestProcedure {
  id: string;
  request_id: string;
  procedure_id: string;
  quantity: number;
  notes: string | null;
  created_at: string;
  procedure?: UnitProcedure;
}

// Fetch procedures for a specific unit
export const fetchUnitProcedures = async (unitId?: string | null): Promise<UnitProcedure[]> => {
  if (!unitId) return [];
  
  console.log('Fetching procedures for unit:', unitId);
  
  const { data, error } = await supabase
    .from('unit_procedures')
    .select('*')
    .eq('unit_id', unitId)
    .order('name');
    
  if (error) {
    console.error('Error fetching unit procedures:', error);
    throw error;
  }
  
  console.log('Fetched procedures:', data);
  return data as UnitProcedure[] || [];
};

// Fetch procedures for a specific request
export const fetchRequestProcedures = async (requestId: string): Promise<RequestProcedure[]> => {
  console.log('Fetching procedures for request:', requestId);
  
  const { data, error } = await supabase
    .from('request_procedures')
    .select(`
      *,
      procedure:procedure_id (*)
    `)
    .eq('request_id', requestId);
    
  if (error) {
    console.error('Error fetching request procedures:', error);
    throw error;
  }
  
  console.log('Fetched request procedures:', data);
  return data as RequestProcedure[] || [];
};

// Create a new procedure for a unit
export const createUnitProcedure = async (procedure: Omit<UnitProcedure, 'id' | 'created_at' | 'updated_at'>) => {
  // Remove fields that are not in the database table
  const { created_by_name, created_by, ...procedureData } = procedure;
  
  console.log('Creating procedure with data:', procedureData);
  
  const { data, error } = await supabase
    .from('unit_procedures')
    .insert(procedureData)
    .select();
    
  if (error) {
    console.error('Error creating unit procedure:', error);
    throw error;
  }
  
  return data[0] as UnitProcedure;
};

// Create multiple procedures for a unit
export const createMultipleUnitProcedures = async (procedures: Omit<UnitProcedure, 'id' | 'created_at' | 'updated_at'>[]) => {
  // Remove fields that are not in the database table
  const proceduresData = procedures.map(({ created_by_name, created_by, ...procedureData }) => procedureData);
  
  console.log('Creating multiple procedures with data:', proceduresData);
  
  const { data, error } = await supabase
    .from('unit_procedures')
    .insert(proceduresData)
    .select();
    
  if (error) {
    console.error('Error creating multiple unit procedures:', error);
    throw error;
  }
  
  return data as UnitProcedure[];
};

// Update an existing procedure
export const updateUnitProcedure = async (id: string, updates: Partial<UnitProcedure>) => {
  // Remove fields that are not in the database table
  const { created_by_name, created_by, ...updatesData } = updates;
  
  const { data, error } = await supabase
    .from('unit_procedures')
    .update(updatesData)
    .eq('id', id)
    .select();
    
  if (error) {
    console.error('Error updating unit procedure:', error);
    throw error;
  }
  
  return data[0] as UnitProcedure;
};

// Delete a procedure
export const deleteUnitProcedure = async (id: string) => {
  const { error } = await supabase
    .from('unit_procedures')
    .delete()
    .eq('id', id);
    
  if (error) {
    console.error('Error deleting unit procedure:', error);
    throw error;
  }
};

// Add procedures to a request
export const addProceduresToRequest = async (procedures: Omit<RequestProcedure, 'id' | 'created_at'>[]) => {
  console.log('Adding procedures to request:', procedures);
  
  const { data, error } = await supabase
    .from('request_procedures')
    .insert(procedures)
    .select();
    
  if (error) {
    console.error('Error adding procedures to request:', error);
    throw error;
  }
  
  return data as RequestProcedure[];
};

// Remove a procedure from a request
export const removeProcedureFromRequest = async (id: string) => {
  const { error } = await supabase
    .from('request_procedures')
    .delete()
    .eq('id', id);
    
  if (error) {
    console.error('Error removing procedure from request:', error);
    throw error;
  }
};
