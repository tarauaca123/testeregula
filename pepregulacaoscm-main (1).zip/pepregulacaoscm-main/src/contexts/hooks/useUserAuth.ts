
import { useState, useCallback } from 'react';
import { Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';
import { User, UserRole } from '../types/userTypes';
import { ADMIN_EMAILS } from '../utils/userUtils';

export const useUserAuth = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchUserProfile = useCallback(async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (error) {
        console.error('Error fetching user profile:', error);
        return null;
      }

      if (data) {
        // Create user object from profile data
        let userRole = (data.role as UserRole) || 'readonly';
        
        // Check auth user's email against admin list
        const { data: authData } = await supabase.auth.getUser();
        const userEmail = authData?.user?.email?.toLowerCase();
        
        // If user email is in admin list, ensure they have admin role
        if (userEmail && ADMIN_EMAILS.includes(userEmail)) {
          userRole = 'admin';
          
          // Update the profile in database to persist the admin role
          await supabase
            .from('profiles')
            .update({ role: 'admin' })
            .eq('id', userId);
        }
        
        return {
          id: data.id,
          name: data.name || 'Unknown User',
          email: data.email || '',
          role: userRole,
        };
      }
    } catch (err) {
      console.error('Error in fetchUserProfile:', err);
    }
    return null;
  }, []);

  const login = async (email: string, password: string) => {
    setLoading(true);
    setError(null);
    
    try {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      
      if (error) throw error;
    } catch (err) {
      setError((err as Error).message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    try {
      await supabase.auth.signOut();
      setCurrentUser(null);
      setSession(null);
    } catch (err) {
      console.error('Error signing out:', err);
    }
  };

  return {
    currentUser,
    setCurrentUser,
    session,
    setSession,
    loading,
    setLoading,
    error,
    setError,
    fetchUserProfile,
    login,
    logout
  };
};
