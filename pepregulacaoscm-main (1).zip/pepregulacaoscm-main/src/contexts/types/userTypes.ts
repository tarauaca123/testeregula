
import { Session, User as SupabaseUser } from '@supabase/supabase-js';

export type UserRole = 'admin' | 'manager' | 'operator' | 'readonly' | 'doctor' | 'regulator' | 'receptionist';

export interface HealthUnit {
  id: string;
  name: string;
  code: string;
  address: string;
  type: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  unit?: HealthUnit;
}

export interface UserContextType {
  currentUser: User | null;
  loading: boolean;
  error: string | null;
  session: Session | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  hasPermission: (requiredRole: UserRole | UserRole[]) => boolean;
}
