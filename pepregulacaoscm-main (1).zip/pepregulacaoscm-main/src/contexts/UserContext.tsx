
import React, { createContext, useContext, useState, useEffect } from 'react';
import { Session, User } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';
import { UserRole, User as UserType } from './types/userTypes';
import { checkPermission } from './utils/userUtils';
import { useAuthState } from '@/hooks/useAuthState';

interface UserContextType {
  session: Session | null;
  currentUser: UserType | null;
  loading: boolean;
  hasPermission: (allowedRoles: UserRole[]) => boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  error: Error | null;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const UserProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<UserType | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  const { session, loading: sessionLoading } = useAuthState();

  useEffect(() => {
    const fetchUserProfile = async () => {
      try {
        if (!session?.user) {
          console.log('No session user, clearing current user');
          setCurrentUser(null);
          return;
        }

        const { data: profile, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', session.user.id)
          .single();

        if (error) {
          console.error('Error fetching user profile:', error);
          setError(new Error('Erro ao carregar perfil do usuário'));
          setCurrentUser(null);
          return;
        }

        console.log('Profile fetched:', profile);
        
        // Cast the profile role to UserRole type when setting the currentUser
        setCurrentUser({
          id: profile.id,
          name: profile.name || '',
          email: profile.email || '',
          role: (profile.role as string || 'readonly') as UserRole,
          ...(profile.unit_id ? { unit: { id: profile.unit_id, name: '', code: '', address: '', type: '' } } : {})
        });
      } catch (err) {
        console.error('Unexpected error in fetchUserProfile:', err);
        setError(err instanceof Error ? err : new Error('Erro desconhecido ao carregar perfil'));
      } finally {
        setLoading(false);
      }
    };

    if (!sessionLoading) {
      fetchUserProfile();
    }
  }, [session, sessionLoading]);

  // Automatic timeout for loading state to prevent infinite loading
  useEffect(() => {
    const loadingTimeout = setTimeout(() => {
      if (loading) {
        console.log('Auth loading timeout reached, forcing completion');
        setLoading(false);
      }
    }, 5000); // 5 second timeout

    return () => clearTimeout(loadingTimeout);
  }, [loading]);

  const login = async (email: string, password: string) => {
    try {
      setLoading(true);
      setError(null);
      
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      
      if (error) throw error;
      console.log('Login successful:', data.session ? 'session exists' : 'no session');
      
      // Successfully logged in, the session will be picked up by useAuthState
      return;
    } catch (error: any) {
      console.error('Login error:', error);
      setError(error instanceof Error ? error : new Error(error.message || 'Erro ao fazer login'));
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    try {
      setLoading(true);
      console.log('Logging out...');
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      console.log('Logout successful, clearing current user');
      setCurrentUser(null);
    } catch (error: any) {
      console.error('Logout error:', error);
      setError(error instanceof Error ? error : new Error(error.message || 'Erro ao fazer logout'));
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const hasPermission = (allowedRoles: UserRole[]) => {
    if (!currentUser) return false;
    return checkPermission(currentUser.role, allowedRoles, roleHierarchy);
  };

  // Role hierarchy for permission checks
  const roleHierarchy: Record<UserRole, number> = {
    admin: 100,
    manager: 80,
    regulator: 70,
    doctor: 60,
    operator: 50,
    receptionist: 40,
    readonly: 10
  };

  const value = {
    session,
    currentUser,
    loading: loading || sessionLoading,
    hasPermission,
    login,
    logout,
    error
  };

  return <UserContext.Provider value={value}>{children}</UserContext.Provider>;
};

export const useUser = () => {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};

// Export UserRole to be used in other components
export type { UserRole } from './types/userTypes';
