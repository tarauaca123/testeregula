
import { UserRole } from '../types/userTypes';

// List of admin emails
export const ADMIN_EMAILS = ['igordantasac17@gmail.com'];

// Role-based access control hierarchy
export const roleHierarchy: Record<UserRole, number> = {
  admin: 100,
  manager: 80,
  regulator: 70,
  doctor: 60,
  operator: 50,
  receptionist: 40,
  readonly: 10
};

/**
 * Checks if a user has permission based on their role
 */
export const checkPermission = (
  userRole: UserRole, 
  requiredRoles: UserRole | UserRole[], 
  roleHierarchyMap: Record<UserRole, number>
): boolean => {
  if (!userRole) return false;
  
  const userRoleLevel = roleHierarchyMap[userRole];
  
  if (Array.isArray(requiredRoles)) {
    // Check if user role has at least the permission level of any of the required roles
    return requiredRoles.some(role => userRoleLevel >= roleHierarchyMap[role]);
  }
  
  // Check if user role has at least the permission level of the required role
  return userRoleLevel >= roleHierarchyMap[requiredRoles];
};

// Export for backward compatibility
export const hasPermission = checkPermission;
