import { UserRole, User, HealthUnit } from '@/contexts/types/userTypes';
import { Json } from '@/integrations/supabase/types';

export interface Patient {
  id: string;
  name: string;
  cpf: string;
  rg?: string;
  cns?: string; // Cartão Nacional de Saúde
  birthDate: string;
  gender: 'male' | 'female' | 'other';
  race?: string;
  bloodType?: string;
  motherName?: string;
  fatherName?: string;
  address: {
    street: string;
    number: string;
    complement?: string;
    neighborhood: string;
    city: string;
    state: string;
    zipCode: string;
  };
  contacts: {
    type: 'phone' | 'mobile' | 'email';
    value: string;
  }[];
  status: 'active' | 'inactive';
  createdAt: string;
  updatedAt: string;
  signature?: string | null;
  unitId?: string;
  unitName?: string;
}

export type RequestStatus = 'pending' | 'approved' | 'rejected' | 'processing' | 'closed' | 'in_unit';
export type RequestPriority = 'low' | 'medium' | 'high';
export type RequestType = 'consultation' | 'exam' | 'surgery' | 'hospitalization';

export interface RegulationRequest {
  id: string;
  patient: Patient;
  requestType: RequestType;
  specialty: string;
  priority: RequestPriority;
  icdCode: string; // CID
  clinicalReason: string;
  suggestedUnit?: HealthUnit;
  status: RequestStatus;
  requestedBy: User;
  requestedAt: string;
  updatedAt: string;
  evaluatedBy?: User;
  evaluatedAt?: string;
  observations?: string;
  attachments?: {
    id: string;
    name: string;
    url: string;
    type: string;
    uploadedAt: string;
  }[];
  history: {
    id: string;
    status: RequestStatus;
    date: string;
    user: User;
    observations?: string;
  }[];
}

export interface IcdCode {
  code: string;
  description: string;
}

export interface Specialty {
  id: string;
  name: string;
  description?: string;
}

export interface MedicalProcedure {
  id: string;
  name: string;
  code: string;
  description?: string;
  specialty: Specialty;
}

export interface SystemConfig {
  id: string;
  key: string;
  value: string;
  description?: string;
}

export interface Feedback {
  id: string;
  user: User;
  message: string;
  createdAt: string;
}

export interface PatientRecord {
  id: string;
  name: string;
  cpf: string;
  birth_date: string;
  gender: string;
  race?: string;
  blood_type?: string;
  mother_name?: string;
  father_name?: string;
  street: string;
  number: string;
  complement?: string;
  neighborhood: string;
  city: string;
  state: string;
  zip_code: string;
  contacts: Json;
  status: string;
  created_at: string;
  updated_at: string;
  signature?: string | null;
}

export interface UserRecord {
  id: string;
  name: string | null;
  email: string | null;
  role?: string | null;
}

export interface UnitRecord {
  id: string;
  name: string;
  code: string;
  type: string;
  address: string;
  city: string;
  state: string;
  zip_code: string;
  phone?: string;
  email?: string;
  created_at: string;
  updated_at: string;
}

export interface RequestRecord {
  id: string;
  patient_id: string;
  request_type: string;
  specialty: string;
  priority: string;
  icd_code: string;
  clinical_reason: string;
  suggested_unit_id: string | null;
  status: string;
  requested_by: string;
  requested_at: string;
  updated_at: string;
  evaluated_by: string | null;
  evaluated_at: string | null;
  observations: string | null;
  attachments: Json | null;
  history: Json | null;
  patient?: PatientRecord | null;
  requestedBy?: UserRecord | null;
  evaluatedBy?: UserRecord | null;
  suggestedUnit?: UnitRecord | null;
}

export type { UserRole, User, HealthUnit };
