
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';
import { HealthUnit } from '@/types';

export const useHealthUnits = () => {
  const [units, setUnits] = useState<HealthUnit[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    const fetchHealthUnits = async () => {
      try {
        setLoading(true);
        
        const { data, error } = await supabase
          .from('health_units')
          .select('*')
          .order('name');

        if (error) throw error;

        // Transform the data to match our HealthUnit type
        const healthUnits: HealthUnit[] = data.map(unit => ({
          id: unit.id,
          name: unit.name,
          code: unit.code,
          type: unit.type,
          address: unit.address,
        }));

        setUnits(healthUnits);
      } catch (err) {
        console.error('Error fetching health units:', err);
        setError(err as Error);
        toast({
          variant: "destructive",
          title: "Erro ao carregar unidades",
          description: "Ocorreu um erro ao carregar as unidades de saúde."
        });
      } finally {
        setLoading(false);
      }
    };

    fetchHealthUnits();
  }, [toast]);

  return { units, loading, error };
};
