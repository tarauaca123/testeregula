
import { useState, useCallback } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { RegulationRequest, RequestStatus } from '@/types';

export const useUnitRequests = (unitId: string | undefined) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  const { data: requests = [], refetch } = useQuery({
    queryKey: ['unitRequests', unitId],
    queryFn: async () => {
      if (!unitId) return [];
      
      try {
        setLoading(true);
        console.log('Fetching requests for unit:', unitId);
        
        // Get requests for this unit
        const { data, error } = await supabase
          .from('requests')
          .select('*')
          .eq('suggested_unit_id', unitId);
          
        if (error) throw error;
        
        // Now enrich the data with patient information
        const enrichedRequests = await Promise.all(
          data.map(async (request) => {
            // Get patient data
            const { data: patientData, error: patientError } = await supabase
              .from('patients')
              .select('*')
              .eq('id', request.patient_id)
              .single();
              
            if (patientError) console.error('Error fetching patient:', patientError);
            
            // Get requester data
            const { data: requesterData, error: requesterError } = await supabase
              .from('profiles')
              .select('*')
              .eq('id', request.requested_by)
              .single();
            
            if (requesterError) console.error('Error fetching requester:', requesterError);
            
            // Transform to frontend model
            return {
              id: request.id,
              patient: patientData || { 
                name: 'Unknown', 
                id: request.patient_id,
                cpf: 'N/A',
                birthDate: new Date().toISOString(),
                gender: 'other',
                address: {
                  street: '',
                  number: '',
                  neighborhood: '',
                  city: '',
                  state: '',
                  zipCode: ''
                },
                contacts: [],
                status: 'inactive',
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
              },
              requestType: request.request_type,
              specialty: request.specialty,
              priority: request.priority,
              status: request.status,
              requestedAt: request.requested_at,
              suggestedUnitId: request.suggested_unit_id,
              
              // Add missing required fields from RegulationRequest type
              icdCode: request.icd_code || '',
              clinicalReason: request.clinical_reason || '',
              requestedBy: requesterData || { 
                id: request.requested_by, 
                name: 'Unknown User', 
                email: 'unknown@example.com',
                role: 'readonly'
              },
              updatedAt: request.updated_at,
              
              // Transform history entries to match the expected structure
              history: Array.isArray(request.history) 
                ? request.history.map((entry: any) => ({
                    id: entry.id || `history-${Math.random().toString(36).substr(2, 9)}`,
                    status: (entry.status || 'pending') as RequestStatus,
                    date: entry.date || new Date().toISOString(),
                    user: entry.user || {
                      id: entry.user_id || requesterData?.id || 'unknown',
                      name: entry.user_name || requesterData?.name || 'Usuário desconhecido',
                      email: entry.user_email || requesterData?.email || 'email@desconhecido',
                      role: entry.user_role || requesterData?.role || 'readonly'
                    },
                    observations: entry.observations
                  }))
                : [],
              
              // Optional fields with defaults
              evaluatedAt: request.evaluated_at,
              evaluatedBy: null,
              observations: request.observations || '',
              // Transform attachments to match the expected type
              attachments: Array.isArray(request.attachments) 
                ? request.attachments.map((attachment: any, index: number) => ({
                    id: attachment.id || `attachment-${index}`,
                    name: attachment.name || `File ${index + 1}`,
                    url: attachment.url || '',
                    type: attachment.type || 'unknown',
                    uploadedAt: attachment.uploadedAt || new Date().toISOString()
                  }))
                : []
            } as RegulationRequest;
          })
        );
        
        console.log(`Fetched ${enrichedRequests.length} requests for unit ${unitId}`);
        return enrichedRequests;
      } catch (err: any) {
        setError(err);
        console.error('Error fetching unit requests:', err);
        return [];
      } finally {
        setLoading(false);
      }
    },
    enabled: !!unitId,
  });

  const deleteRequest = useCallback(async (requestId: string) => {
    try {
      setLoading(true);
      
      // Add more detailed console logs to track deletion process
      console.log('Starting deletion process for request:', requestId);
      
      const { error } = await supabase
        .from('requests')
        .delete()
        .eq('id', requestId);
        
      if (error) {
        console.error('Error during deletion:', error);
        throw error;
      }
      
      console.log('Request deleted successfully from database');
      
      // Refresh the requests list
      await refetch();
      console.log('Request list refreshed after deletion');
      
      return true;
    } catch (err: any) {
      console.error('Delete request error:', err);
      setError(err);
      throw err;
    } finally {
      console.log('Resetting loading state after deletion');
      // Use setTimeout to ensure state updates happen in next tick
      setTimeout(() => {
        setLoading(false);
      }, 0);
    }
  }, [refetch]);

  return {
    requests,
    loading,
    error,
    deleteRequest,
    refetch
  };
};
