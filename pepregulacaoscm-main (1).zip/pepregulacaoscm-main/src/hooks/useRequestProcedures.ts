
import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/components/ui/use-toast';
import { 
  RequestProcedure, 
  UnitProcedure,
  fetchRequestProcedures,
  addProceduresToRequest,
  removeProcedureFromRequest
} from '@/services/procedures';

export const useRequestProcedures = (requestId?: string) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  
  // Fetch procedures for this request
  const {
    data: requestProcedures = [],
    isLoading,
    error,
    refetch
  } = useQuery({
    queryKey: ['requestProcedures', requestId],
    queryFn: () => requestId ? fetchRequestProcedures(requestId) : Promise.resolve([]),
    enabled: !!requestId,
  });
  
  console.log('Request procedures data:', requestProcedures);
  
  // Add procedures mutation
  const addProceduresMutation = useMutation({
    mutationFn: addProceduresToRequest,
    onSuccess: () => {
      toast({
        title: "Procedimentos adicionados",
        description: "Os procedimentos foram adicionados com sucesso à solicitação.",
      });
      queryClient.invalidateQueries({ queryKey: ['requestProcedures', requestId] });
      setIsDialogOpen(false);
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Erro ao adicionar procedimentos",
        description: (error as Error).message || "Ocorreu um erro ao adicionar os procedimentos.",
      });
    }
  });
  
  // Remove procedure mutation
  const removeProcedureMutation = useMutation({
    mutationFn: removeProcedureFromRequest,
    onSuccess: () => {
      toast({
        title: "Procedimento removido",
        description: "O procedimento foi removido da solicitação.",
      });
      queryClient.invalidateQueries({ queryKey: ['requestProcedures', requestId] });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Erro ao remover procedimento",
        description: (error as Error).message || "Ocorreu um erro ao remover o procedimento.",
      });
    }
  });
  
  const openAddDialog = () => {
    setIsDialogOpen(true);
  };
  
  const handleAddProcedures = (selectedProcedures: { 
    procedureId: string; 
    quantity: number; 
    notes?: string;
  }[]) => {
    if (!requestId) return;
    
    const proceduresToAdd = selectedProcedures.map(item => ({
      request_id: requestId,
      procedure_id: item.procedureId,
      quantity: item.quantity,
      notes: item.notes || null
    }));
    
    console.log('Adding procedures:', proceduresToAdd);
    addProceduresMutation.mutate(proceduresToAdd);
  };
  
  const handleRemoveProcedure = (procedureId: string) => {
    console.log('Removing procedure:', procedureId);
    removeProcedureMutation.mutate(procedureId);
  };
  
  // Calculate total price
  const totalPrice = requestProcedures.reduce((sum, item) => {
    const price = item.procedure?.price || 0;
    return sum + (price * item.quantity);
  }, 0);
  
  return {
    requestProcedures,
    isLoading,
    error,
    isDialogOpen,
    setIsDialogOpen,
    openAddDialog,
    handleAddProcedures,
    handleRemoveProcedure,
    totalPrice,
    refetch
  };
};
