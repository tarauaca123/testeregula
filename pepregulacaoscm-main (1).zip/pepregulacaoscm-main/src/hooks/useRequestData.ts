
import { useQuery } from '@tanstack/react-query';
import { useToast } from '@/components/ui/use-toast';
import { useUser } from '@/contexts/UserContext';
import { RequestStatus, RequestRecord } from '@/types';
import { fetchRequests, fetchRequestStats, deleteRequest, updateRequestStatus } from '@/services/requests';
import { useRequestFilters } from '@/hooks/useRequestFilters';
import { useCallback } from 'react';

export const useRequestData = () => {
  const { toast } = useToast();
  const { hasPermission, currentUser } = useUser();
  
  // Determine if admin/manager, who can see all requests
  const canSeeAllRequests = hasPermission(['admin', 'manager']);
  
  // Get the user's unit ID for filtering
  const userUnitId = currentUser?.unit?.id;
  
  // Fetch requests data with appropriate filtering
  const { data: requests = [], isLoading, error, refetch } = useQuery({
    queryKey: ['requests', userUnitId, canSeeAllRequests],
    queryFn: async () => {
      // If user can see all requests, don't filter by unit
      // Otherwise filter by the user's unit
      return fetchRequests(canSeeAllRequests ? undefined : userUnitId);
    },
  });

  // Use the filters hook
  const { 
    searchTerm, 
    setSearchTerm, 
    statusFilter, 
    priorityFilter,
    handleStatusFilterChange,
    handlePriorityFilterChange,
    filteredRequests 
  } = useRequestFilters(requests);

  // Fetch stats data with appropriate filtering
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ['requestStats', userUnitId, canSeeAllRequests],
    queryFn: async () => {
      // If user can see all stats, don't filter by unit
      // Otherwise filter by the user's unit
      return fetchRequestStats(canSeeAllRequests ? undefined : userUnitId);
    },
  });
  
  // Permissions check for actions
  const canCreateRequest = hasPermission(['admin', 'manager', 'operator', 'doctor', 'receptionist']);
  const canEvaluateRequest = hasPermission(['admin', 'manager', 'regulator']);
  const canDeleteRequest = hasPermission(['admin']);

  const handleDeleteRequest = useCallback(async (requestId: string) => {
    try {
      console.log('Starting delete operation in service for request:', requestId);
      
      // Perform the deletion in Supabase
      await deleteRequest(requestId);

      console.log('Delete successful in Supabase, updating UI');
      
      // Show success toast
      toast({
        title: "Solicitação excluída",
        description: "A solicitação foi excluída com sucesso.",
      });

      // Refetch the data to update the UI
      await refetch();
      
      console.log('UI updated after deletion');
      return true;
    } catch (error) {
      console.error('Error deleting request:', error);
      toast({
        variant: "destructive",
        title: "Erro ao excluir solicitação",
        description: "Ocorreu um erro ao excluir a solicitação. Tente novamente.",
      });
      throw error; // Rethrow to allow calling code to handle
    }
  }, [refetch, toast]);

  const handleUpdateRequestStatus = useCallback(async (requestId: string, status: RequestStatus) => {
    try {
      console.log('Updating status to:', status);
      
      await updateRequestStatus(
        requestId, 
        status, 
        currentUser?.id, 
        currentUser?.name, 
        currentUser?.email
      );

      let statusMessage = '';
      switch(status) {
        case 'approved': statusMessage = 'aprovada'; break;
        case 'rejected': statusMessage = 'rejeitada'; break;
        case 'processing': statusMessage = 'colocada em análise'; break;
        case 'closed': statusMessage = 'fechada'; break;
        case 'in_unit': statusMessage = 'atualizada para paciente na unidade'; break;
        default: statusMessage = 'atualizada';
      }

      toast({
        title: "Status atualizado",
        description: `A solicitação foi ${statusMessage}.`,
      });

      refetch();
    } catch (error) {
      console.error('Error updating request status:', error);
      toast({
        variant: "destructive",
        title: "Erro ao atualizar status",
        description: "Ocorreu um erro ao atualizar o status da solicitação. Tente novamente.",
      });
    }
  }, [currentUser, refetch, toast]);

  return {
    requests,
    filteredRequests,
    stats,
    isLoading,
    statsLoading,
    error,
    searchTerm,
    setSearchTerm,
    statusFilter,
    priorityFilter,
    handleStatusFilterChange,
    handlePriorityFilterChange,
    handleDeleteRequest,
    updateRequestStatus: handleUpdateRequestStatus,
    canCreateRequest,
    canEvaluateRequest,
    canDeleteRequest,
    refetch
  };
};
