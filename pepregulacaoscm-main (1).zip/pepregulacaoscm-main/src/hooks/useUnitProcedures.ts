
import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/components/ui/use-toast';
import { useUser } from '@/contexts/UserContext';
import { 
  UnitProcedure, 
  fetchUnitProcedures, 
  createUnitProcedure, 
  updateUnitProcedure, 
  deleteUnitProcedure,
  createMultipleUnitProcedures
} from '@/services/procedures';

export const useUnitProcedures = (unitId?: string) => {
  const { toast } = useToast();
  const { currentUser } = useUser();
  const queryClient = useQueryClient();
  const [procedureToEdit, setProcedureToEdit] = useState<UnitProcedure | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // Use the user's unit if no specific unit is provided
  const effectiveUnitId = unitId || currentUser?.unit?.id;
  
  console.log('useUnitProcedures - effectiveUnitId:', effectiveUnitId);

  // Fetch procedures for the unit
  const { 
    data: procedures = [], 
    isLoading, 
    error 
  } = useQuery({
    queryKey: ['unitProcedures', effectiveUnitId],
    queryFn: () => fetchUnitProcedures(effectiveUnitId),
    enabled: !!effectiveUnitId,
  });
  
  console.log('Fetched procedures in hook:', procedures);

  // Create procedure mutation
  const createMutation = useMutation({
    mutationFn: createUnitProcedure,
    onSuccess: () => {
      toast({
        title: "Procedimento criado",
        description: "O procedimento foi adicionado com sucesso.",
      });
      queryClient.invalidateQueries({ queryKey: ['unitProcedures'] });
      setIsDialogOpen(false);
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Erro ao criar procedimento",
        description: (error as Error).message || "Ocorreu um erro ao criar o procedimento.",
      });
    }
  });

  // Create multiple procedures mutation
  const createMultipleMutation = useMutation({
    mutationFn: createMultipleUnitProcedures,
    onSuccess: (data) => {
      toast({
        title: "Procedimentos criados",
        description: `${data.length} procedimentos foram adicionados com sucesso.`,
      });
      queryClient.invalidateQueries({ queryKey: ['unitProcedures'] });
      setIsDialogOpen(false);
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Erro ao criar procedimentos",
        description: (error as Error).message || "Ocorreu um erro ao criar os procedimentos.",
      });
    }
  });

  // Update procedure mutation
  const updateMutation = useMutation({
    mutationFn: ({ id, updates }: { id: string; updates: Partial<UnitProcedure> }) => 
      updateUnitProcedure(id, updates),
    onSuccess: () => {
      toast({
        title: "Procedimento atualizado",
        description: "O procedimento foi atualizado com sucesso.",
      });
      queryClient.invalidateQueries({ queryKey: ['unitProcedures'] });
      setIsDialogOpen(false);
      setProcedureToEdit(null);
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Erro ao atualizar procedimento",
        description: (error as Error).message || "Ocorreu um erro ao atualizar o procedimento.",
      });
    }
  });

  // Delete procedure mutation
  const deleteMutation = useMutation({
    mutationFn: deleteUnitProcedure,
    onSuccess: () => {
      toast({
        title: "Procedimento excluído",
        description: "O procedimento foi excluído com sucesso.",
      });
      queryClient.invalidateQueries({ queryKey: ['unitProcedures'] });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Erro ao excluir procedimento",
        description: (error as Error).message || "Ocorreu um erro ao excluir o procedimento.",
      });
    }
  });

  // Filter procedures by type
  const filterProceduresByType = (type: UnitProcedure['type']) => {
    return procedures.filter(procedure => procedure.type === type);
  };

  const exams = filterProceduresByType('exam');
  const surgeries = filterProceduresByType('surgery');
  const consultations = filterProceduresByType('consultation');
  
  console.log('Filtered procedures:', { exams, surgeries, consultations });

  const openCreateDialog = () => {
    setProcedureToEdit(null);
    setIsDialogOpen(true);
  };

  const openEditDialog = (procedure: UnitProcedure) => {
    setProcedureToEdit(procedure);
    setIsDialogOpen(true);
  };

  const handleCreateProcedure = (procedure: Omit<UnitProcedure, 'id' | 'created_at' | 'updated_at'>) => {
    createMutation.mutate(procedure);
  };

  const handleCreateMultipleProcedures = (procedures: Omit<UnitProcedure, 'id' | 'created_at' | 'updated_at'>[]) => {
    createMultipleMutation.mutate(procedures);
  };

  const handleUpdateProcedure = (id: string, updates: Partial<UnitProcedure>) => {
    updateMutation.mutate({ id, updates });
  };

  const handleDeleteProcedure = (id: string) => {
    deleteMutation.mutate(id);
  };

  const handleSubmit = (data: UnitProcedure | { id: string; updates: Partial<UnitProcedure> } | UnitProcedure[]) => {
    if (Array.isArray(data)) {
      handleCreateMultipleProcedures(data);
    } else if ('id' in data && 'updates' in data) {
      handleUpdateProcedure(data.id, data.updates);
    } else {
      handleCreateProcedure(data as Omit<UnitProcedure, 'id' | 'created_at' | 'updated_at'>);
    }
  };

  return {
    procedures,
    exams,
    surgeries,
    consultations,
    isLoading,
    error,
    isDialogOpen,
    setIsDialogOpen,
    procedureToEdit,
    setProcedureToEdit,
    openCreateDialog,
    openEditDialog,
    handleCreateProcedure,
    handleCreateMultipleProcedures,
    handleUpdateProcedure,
    handleDeleteProcedure,
    handleSubmit,
    effectiveUnitId
  };
};
