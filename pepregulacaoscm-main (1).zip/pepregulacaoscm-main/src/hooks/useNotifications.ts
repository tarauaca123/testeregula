
import { useState, useEffect } from 'react';
import { useToast } from '@/components/ui/use-toast';
import { RegulationRequest } from '@/types';

interface UseNotificationsProps {
  requests: RegulationRequest[] | null;
  onNavigate: (requestId: string) => void;
}

export const useNotifications = ({ requests, onNavigate }: UseNotificationsProps) => {
  const { toast } = useToast();
  
  // Store viewed notification IDs in local storage
  const [viewedNotifications, setViewedNotifications] = useState<string[]>(() => {
    const saved = localStorage.getItem('viewedNotifications');
    return saved ? JSON.parse(saved) : [];
  });

  // State to track if dropdown is open
  const [isOpen, setIsOpen] = useState(false);

  // Save viewed notifications to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('viewedNotifications', JSON.stringify(viewedNotifications));
  }, [viewedNotifications]);

  // Calculate unviewed notifications
  const unviewedCount = requests ? 
    requests.filter(req => !viewedNotifications.includes(req.id)).length : 0;

  // Mark a notification as viewed and navigate to its detail page
  const handleNotificationClick = (requestId: string) => {
    // Add to viewed notifications if not already viewed
    if (!viewedNotifications.includes(requestId)) {
      const newViewedNotifications = [...viewedNotifications, requestId];
      setViewedNotifications(newViewedNotifications);
      localStorage.setItem('viewedNotifications', JSON.stringify(newViewedNotifications));
      
      toast({
        description: "Notificação marcada como visualizada",
        duration: 3000,
      });
    }
    
    // Close the dropdown
    setIsOpen(false);
    
    // Navigate to the specific request page
    onNavigate(requestId);
  };

  // When dropdown is opened, mark all notifications as viewed
  const handleDropdownOpenChange = (open: boolean) => {
    setIsOpen(open);
    
    // If opening the dropdown and there are unviewed notifications, mark them as viewed
    if (open && requests && unviewedCount > 0) {
      const newRequestIds = requests
        .filter(request => !viewedNotifications.includes(request.id))
        .map(request => request.id);
      
      if (newRequestIds.length > 0) {
        const allViewedNotifications = [...viewedNotifications, ...newRequestIds];
        setViewedNotifications(allViewedNotifications);
        localStorage.setItem('viewedNotifications', JSON.stringify(allViewedNotifications));
      }
    }
  };

  return {
    viewedNotifications,
    unviewedCount,
    isOpen,
    handleNotificationClick,
    handleDropdownOpenChange
  };
};
