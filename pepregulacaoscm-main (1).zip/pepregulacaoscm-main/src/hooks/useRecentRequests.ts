
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';
import { RegulationRequest, Patient, RequestStatus } from '@/types';

export const useRecentRequests = (limit: number = 5) => {
  const [requests, setRequests] = useState<RegulationRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    const fetchRecentRequests = async () => {
      try {
        setLoading(true);

        // Fetch recent requests
        const { data: requestsData, error: requestsError } = await supabase
          .from('requests')
          .select('*')
          .order('updated_at', { ascending: false })
          .limit(limit);

        if (requestsError) throw requestsError;

        // Fetch related data for each request
        const recentRequests = await Promise.all((requestsData || []).map(async (request) => {
          // Fetch patient data
          const { data: patientData, error: patientError } = await supabase
            .from('patients')
            .select('*')
            .eq('id', request.patient_id)
            .single();

          if (patientError) console.error('Error fetching patient:', patientError);

          // Fetch requester profile
          const { data: requesterData, error: requesterError } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', request.requested_by)
            .single();

          if (requesterError) console.error('Error fetching requester:', requesterError);

          // Transform patient data to match the Patient type
          const patient: Patient = patientData ? {
            id: patientData.id,
            name: patientData.name,
            cpf: patientData.cpf,
            rg: patientData.rg || undefined,
            cns: patientData.cns || undefined,
            birthDate: patientData.birth_date,
            gender: patientData.gender as 'male' | 'female' | 'other',
            race: patientData.race || undefined,
            bloodType: patientData.blood_type || undefined,
            motherName: patientData.mother_name || undefined,
            fatherName: patientData.father_name || undefined,
            address: {
              street: patientData.street,
              number: patientData.number,
              complement: patientData.complement || undefined,
              neighborhood: patientData.neighborhood,
              city: patientData.city,
              state: patientData.state,
              zipCode: patientData.zip_code
            },
            contacts: Array.isArray(patientData.contacts) 
              ? patientData.contacts.map((contact: any) => ({
                  type: contact.type as 'phone' | 'mobile' | 'email',
                  value: contact.value
                }))
              : [],
            status: patientData.status as 'active' | 'inactive',
            createdAt: patientData.created_at || new Date().toISOString(),
            updatedAt: patientData.updated_at || new Date().toISOString()
          } : {
            id: request.patient_id,
            name: 'Paciente não encontrado',
            cpf: 'N/A',
            birthDate: new Date().toISOString(),
            gender: 'other',
            address: {
              street: '',
              number: '',
              neighborhood: '',
              city: '',
              state: '',
              zipCode: ''
            },
            contacts: [],
            status: 'inactive',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          };

          // Transform history data to match the expected structure
          const historyEntries = Array.isArray(request.history) 
            ? request.history.map((entry: any) => ({
                id: entry.id || `history-${Math.random().toString(36).substr(2, 9)}`,
                status: (entry.status || 'pending') as RequestStatus,
                date: entry.date || new Date().toISOString(),
                user: entry.user || {
                  id: entry.user_id || requesterData?.id || 'unknown',
                  name: entry.user_name || requesterData?.name || 'Usuário desconhecido',
                  email: entry.user_email || requesterData?.email || 'email@desconhecido',
                  role: entry.user_role || requesterData?.role || 'readonly'
                },
                observations: entry.observations
              }))
            : [];

          // Construct the request with associated data
          return {
            id: request.id,
            patient: patient,
            requestType: request.request_type,
            specialty: request.specialty,
            priority: request.priority,
            icdCode: request.icd_code,
            clinicalReason: request.clinical_reason,
            suggestedUnit: null, // We'll handle this as optional
            status: request.status,
            requestedBy: requesterData || { id: request.requested_by, name: 'Usuário não encontrado', email: 'N/A' },
            requestedAt: request.requested_at,
            updatedAt: request.updated_at,
            evaluatedBy: null, // We'll handle this as optional
            evaluatedAt: request.evaluated_at,
            observations: request.observations,
            history: historyEntries
          } as RegulationRequest;
        }));

        setRequests(recentRequests);
      } catch (err) {
        console.error('Error fetching recent requests:', err);
        setError(err as Error);
        toast({
          variant: "destructive",
          title: "Erro ao carregar solicitações recentes",
          description: "Ocorreu um erro ao carregar as solicitações recentes."
        });
      } finally {
        setLoading(false);
      }
    };

    fetchRecentRequests();
  }, [toast, limit]);

  return { requests, loading, error };
};
