
import { useState, useEffect } from 'react';
import { UnitProcedure, fetchUnitProcedures } from '@/services/procedures';

interface SelectedProcedure {
  quantity: number;
  notes: string;
}

interface UseProcedureSelectionProps {
  open: boolean;
  unitId?: string;
}

export const useProcedureSelection = ({ open, unitId }: UseProcedureSelectionProps) => {
  const [procedures, setProcedures] = useState<UnitProcedure[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedTab, setSelectedTab] = useState('exams');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedProcedures, setSelectedProcedures] = useState<{
    [key: string]: SelectedProcedure;
  }>({});

  // Load procedures when dialog opens
  useEffect(() => {
    if (open && unitId) {
      setLoading(true);
      fetchUnitProcedures(unitId)
        .then((data) => {
          setProcedures(data);
        })
        .catch((error) => {
          console.error('Error loading procedures:', error);
        })
        .finally(() => {
          setLoading(false);
        });
    } else {
      // Reset selections when dialog closes
      setSelectedProcedures({});
      setSearchTerm('');
    }
  }, [open, unitId]);

  const filteredProcedures = procedures.filter((procedure) => {
    const matchesSearch = procedure.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (procedure.description?.toLowerCase().includes(searchTerm.toLowerCase()) || false);
    const matchesTab = 
      (selectedTab === 'exams' && procedure.type === 'exam') ||
      (selectedTab === 'surgeries' && procedure.type === 'surgery') ||
      (selectedTab === 'consultations' && procedure.type === 'consultation');
    
    return matchesSearch && matchesTab;
  });

  const toggleProcedure = (id: string) => {
    setSelectedProcedures((prev) => {
      const newSelection = { ...prev };
      if (newSelection[id]) {
        delete newSelection[id];
      } else {
        newSelection[id] = { quantity: 1, notes: '' };
      }
      return newSelection;
    });
  };

  const updateQuantity = (id: string, quantity: number) => {
    setSelectedProcedures((prev) => ({
      ...prev,
      [id]: { ...prev[id], quantity: quantity }
    }));
  };

  const updateNotes = (id: string, notes: string) => {
    setSelectedProcedures((prev) => ({
      ...prev,
      [id]: { ...prev[id], notes }
    }));
  };

  const getSelectedProcedures = () => {
    return Object.entries(selectedProcedures).map(([procedureId, data]) => ({
      procedureId,
      quantity: data.quantity,
      notes: data.notes || undefined
    }));
  };

  return {
    procedures,
    filteredProcedures,
    loading,
    selectedTab,
    setSelectedTab,
    searchTerm,
    setSearchTerm,
    selectedProcedures,
    toggleProcedure,
    updateQuantity,
    updateNotes,
    getSelectedProcedures
  };
};

export type { SelectedProcedure };
