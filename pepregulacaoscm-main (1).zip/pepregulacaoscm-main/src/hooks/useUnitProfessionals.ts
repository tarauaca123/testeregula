
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';
import { UserRole } from '@/contexts/types/userTypes';

// Define a User interface that uses the imported UserRole type
interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
}

export const useUnitProfessionals = (unitId: string | undefined) => {
  const [professionals, setProfessionals] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    // Don't fetch if no unitId is provided
    if (!unitId) {
      setLoading(false);
      return;
    }

    const fetchProfessionals = async () => {
      try {
        setLoading(true);

        // Query profiles where the unit_id matches
        const { data, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('unit_id', unitId);

        if (error) throw error;

        // Transform the data to match our User type
        const userProfiles: User[] = data.map(profile => ({
          id: profile.id,
          name: profile.name || 'Sem nome',
          email: profile.email || '',
          // Fix for excessive type recursion - explicitly cast to string first, then to UserRole
          role: (profile.role as string || 'readonly') as UserRole,
        }));

        setProfessionals(userProfiles);
      } catch (err) {
        console.error('Error fetching professionals:', err);
        setError(err as Error);
        toast({
          variant: "destructive",
          title: "Erro ao carregar profissionais",
          description: "Ocorreu um erro ao carregar os profissionais desta unidade."
        });
      } finally {
        setLoading(false);
      }
    };

    fetchProfessionals();
  }, [unitId, toast]);

  return { professionals, loading, error };
};
