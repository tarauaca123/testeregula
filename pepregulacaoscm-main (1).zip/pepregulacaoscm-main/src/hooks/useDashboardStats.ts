
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';

export interface DashboardStats {
  totalRequests: number;
  pendingRequests: number;
  highPriorityRequests: number;
  approvedRequests: number;
  requestsByStatus: {
    pending: number;
    approved: number;
    rejected: number;
    processing: number;
  };
  requestsByType: {
    consultation: number;
    exam: number;
    surgery: number;
    hospitalization: number;
  };
  requestsByPriority: {
    high: number;
    medium: number;
    low: number;
  };
}

export const useDashboardStats = () => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    const fetchStats = async () => {
      try {
        setLoading(true);

        // Get all requests to calculate statistics
        const { data: requests, error: requestsError } = await supabase
          .from('requests')
          .select('*');

        if (requestsError) throw requestsError;

        // Calculate dashboard statistics
        const totalRequests = requests.length;
        const pendingRequests = requests.filter(r => r.status === 'pending').length;
        const highPriorityRequests = requests.filter(r => r.priority === 'high').length;
        const approvedRequests = requests.filter(r => r.status === 'approved').length;
        
        const requestsByStatus = {
          pending: pendingRequests,
          approved: approvedRequests,
          rejected: requests.filter(r => r.status === 'rejected').length,
          processing: requests.filter(r => r.status === 'processing').length
        };
        
        const requestsByType = {
          consultation: requests.filter(r => r.request_type === 'consultation').length,
          exam: requests.filter(r => r.request_type === 'exam').length,
          surgery: requests.filter(r => r.request_type === 'surgery').length,
          hospitalization: requests.filter(r => r.request_type === 'hospitalization').length
        };
        
        const requestsByPriority = {
          high: highPriorityRequests,
          medium: requests.filter(r => r.priority === 'medium').length,
          low: requests.filter(r => r.priority === 'low').length
        };

        setStats({
          totalRequests,
          pendingRequests,
          highPriorityRequests,
          approvedRequests,
          requestsByStatus,
          requestsByType,
          requestsByPriority
        });

      } catch (err) {
        console.error('Error fetching dashboard stats:', err);
        setError(err as Error);
        toast({
          variant: "destructive",
          title: "Erro ao carregar estatísticas",
          description: "Ocorreu um erro ao carregar as estatísticas do dashboard."
        });
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, [toast]);

  return { stats, loading, error };
};
