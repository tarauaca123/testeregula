
import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Patient } from '@/types';
import { toast } from '@/components/ui/use-toast';

export const usePatientDetail = () => {
  const { id } = useParams<{ id: string }>();
  const [patient, setPatient] = useState<Patient | null>(null);
  const [loading, setLoading] = useState(true);
  
  // Format a CPF (Brazilian tax ID) string
  const formatCPF = (cpf: string) => {
    // Return the CPF already formatted if it contains dots or dashes
    if (cpf.includes('.') || cpf.includes('-')) {
      return cpf;
    }
    
    // Format a plain CPF string
    return cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
  };
  
  useEffect(() => {
    const fetchPatient = async () => {
      try {
        setLoading(true);
        
        // If id is 'new', we're creating a new patient, so don't fetch from database
        if (!id || id === 'new') {
          setLoading(false);
          return;
        }
        
        // First get the patient data
        const { data, error } = await supabase
          .from('patients')
          .select('*')
          .eq('id', id)
          .single();
          
        if (error) {
          throw error;
        }
        
        if (data) {
          // Ensure contacts is properly typed as an array
          let typedContacts: { type: 'phone' | 'mobile' | 'email'; value: string }[] = [];
          
          // Handle different possible types of the contacts field
          if (Array.isArray(data.contacts)) {
            typedContacts = data.contacts
              .map((contact: any) => {
                // Ensure each contact has the required structure
                if (typeof contact === 'object' && contact !== null && 'type' in contact && 'value' in contact) {
                  // Validate the type is one of the allowed values
                  const contactType = String(contact.type).toLowerCase();
                  const validValue = String(contact.value);
                  
                  // Only include contacts with non-empty values
                  if (validValue.trim() === '') {
                    return null;
                  }
                  
                  // Map the contact type to one of our valid types
                  if (contactType === 'email') {
                    return { type: 'email' as const, value: validValue };
                  } else if (contactType === 'mobile') {
                    return { type: 'mobile' as const, value: validValue };
                  } else {
                    // Default to 'phone' for any other value
                    return { type: 'phone' as const, value: validValue };
                  }
                }
                return null; // Return null for invalid contacts
              })
              .filter((contact): contact is { type: 'phone' | 'mobile' | 'email'; value: string } => 
                contact !== null
              ); // Filter out null entries and assert the type
          }
          
          // Handle unit data separately if unit_id exists
          let unitName: string | undefined;
          if (data.unit_id) {
            const { data: unitData } = await supabase
              .from('health_units')
              .select('name')
              .eq('id', data.unit_id)
              .single();
            
            unitName = unitData?.name;
          }
          
          // Transform database patient to match the frontend Patient type
          const transformedPatient: Patient = {
            id: data.id,
            name: data.name,
            cpf: data.cpf,
            rg: data.rg || undefined,
            cns: data.cns || undefined,
            birthDate: data.birth_date,
            gender: data.gender as 'male' | 'female' | 'other',
            race: data.race || undefined,
            bloodType: data.blood_type || undefined,
            motherName: data.mother_name || undefined,
            fatherName: data.father_name || undefined,
            address: {
              street: data.street,
              number: data.number,
              complement: data.complement || undefined,
              neighborhood: data.neighborhood,
              city: data.city,
              state: data.state,
              zipCode: data.zip_code
            },
            contacts: typedContacts,
            status: data.status as 'active' | 'inactive',
            createdAt: data.created_at,
            updatedAt: data.updated_at,
            signature: data.signature || null,
            unitId: data.unit_id || undefined,
            unitName
          };
          
          setPatient(transformedPatient);
        }
      } catch (error) {
        console.error('Error fetching patient details:', error);
        toast({
          variant: "destructive",
          title: "Erro ao carregar dados do paciente",
          description: "Não foi possível carregar os detalhes do paciente."
        });
      } finally {
        setLoading(false);
      }
    };
    
    fetchPatient();
  }, [id]);
  
  return {
    patient,
    loading,
    formatCPF,
    isNewPatient: id === 'new'
  };
};
