
import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';
import { useUser } from '@/contexts/UserContext';
import { RequestStatus } from '@/types';

export const useRequestDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { currentUser, hasPermission } = useUser();
  
  // Check permissions
  const canEvaluateRequest = hasPermission(['admin', 'manager', 'regulator']);
  
  // Fetch request data
  const { data: request, isLoading, error, refetch } = useQuery({
    queryKey: ['request', id],
    queryFn: async () => {
      if (!id) throw new Error('ID da solicitação não fornecido');
      
      // Fetch request
      const { data: requestData, error: requestError } = await supabase
        .from('requests')
        .select('*')
        .eq('id', id)
        .single();
        
      if (requestError) throw requestError;
      
      // Fetch patient
      const { data: patientData, error: patientError } = await supabase
        .from('patients')
        .select('id, name, cpf, gender, birth_date')
        .eq('id', requestData.patient_id)
        .single();
        
      if (patientError) throw patientError;
      
      // Fetch requester
      const { data: requesterData } = await supabase
        .from('profiles')
        .select('id, name, email')
        .eq('id', requestData.requested_by)
        .single();
        
      // Fetch evaluator (if exists)
      let evaluatorData = null;
      if (requestData.evaluated_by) {
        const { data } = await supabase
          .from('profiles')
          .select('id, name, email')
          .eq('id', requestData.evaluated_by)
          .single();
        evaluatorData = data;
      }
      
      // Return complete data
      return {
        ...requestData,
        patient: patientData,
        requestedBy: requesterData,
        evaluatedBy: evaluatorData
      };
    },
  });
  
  // Update request status
  const updateRequestStatus = async (status: RequestStatus) => {
    try {
      if (!id) return;
      
      const now = new Date().toISOString();
      
      // Get current history
      const { data: currentRequest } = await supabase
        .from('requests')
        .select('history')
        .eq('id', id)
        .single();
      
      // Create new history entry
      const historyEntry = {
        id: crypto.randomUUID(),
        status,
        date: now,
        user: {
          id: currentUser?.id,
          name: currentUser?.name,
          email: currentUser?.email
        }
      };
      
      // Update history
      const updatedHistory = Array.isArray(currentRequest?.history) 
        ? [...currentRequest.history, historyEntry] 
        : [historyEntry];
      
      console.log('Updating to status:', status);
      
      // Update request
      const { error } = await supabase
        .from('requests')
        .update({
          status,
          evaluated_by: currentUser?.id,
          evaluated_at: now,
          history: updatedHistory
        })
        .eq('id', id);

      if (error) {
        console.error('Error updating request status:', error);
        throw error;
      }

      let statusMessage = '';
      switch(status) {
        case 'approved': statusMessage = 'aprovada'; break;
        case 'rejected': statusMessage = 'rejeitada'; break;
        case 'processing': statusMessage = 'colocada em análise'; break;
        case 'closed': statusMessage = 'fechada'; break;
        case 'in_unit': statusMessage = 'atualizada para paciente na unidade'; break;
        default: statusMessage = 'atualizada';
      }

      toast({
        title: "Status atualizado",
        description: `A solicitação foi ${statusMessage}.`,
      });

      refetch();
    } catch (error) {
      console.error('Erro ao atualizar status:', error);
      toast({
        variant: "destructive",
        title: "Erro ao atualizar status",
        description: "Ocorreu um erro ao atualizar o status da solicitação. Tente novamente.",
      });
    }
  };
  
  return {
    id,
    request,
    isLoading,
    error,
    refetch,
    navigate,
    canEvaluateRequest,
    updateRequestStatus
  };
};
