
import { useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';
import { useAuthState } from './useAuthState';

export const useSupabaseAuth = () => {
  const { session } = useAuthState();
  const navigate = useNavigate();
  const { toast } = useToast();

  const getCurrentUserId = useCallback(() => {
    return session?.user?.id || null;
  }, [session]);

  const signIn = useCallback(async (email: string, password: string) => {
    try {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;
      
      toast({
        title: "Login realizado com sucesso",
        description: "Bem-vindo ao Sistema de Regulação em Saúde",
      });
      
      navigate('/dashboard');
      return { success: true };
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Erro ao realizar login",
        description: error.message || "Ocorreu um erro durante o login",
      });
      return { success: false, error };
    }
  }, [navigate, toast]);

  const signOut = useCallback(async () => {
    try {
      await supabase.auth.signOut();
      toast({
        title: "Logout realizado",
        description: "Você foi desconectado com sucesso.",
      });
      navigate('/login');
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Erro ao realizar logout",
        description: error.message || "Ocorreu um erro durante o logout",
      });
    }
  }, [navigate, toast]);

  return {
    session,
    isAuthenticated: !!session,
    userId: getCurrentUserId(),
    getCurrentUserId,
    signIn,
    signOut,
  };
};
