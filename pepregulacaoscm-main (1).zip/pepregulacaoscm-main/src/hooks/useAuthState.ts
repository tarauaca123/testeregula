
import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Session } from '@supabase/supabase-js';

export const useAuthState = () => {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Set up auth state listener FIRST to not miss any auth events
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (_event, newSession) => {
        console.log('Auth state changed:', _event, newSession ? 'session exists' : 'no session');
        setSession(newSession);
        if (_event === 'SIGNED_OUT') {
          // Make sure we clear session on sign out
          setSession(null);
        }
        // Finish loading after auth state change is processed
        setLoading(false);
      }
    );

    // THEN check for existing session
    const getInitialSession = async () => {
      try {
        const { data, error } = await supabase.auth.getSession();
        if (error) {
          console.error('Error getting session:', error);
        }
        console.log('Initial session check:', data.session ? 'session exists' : 'no session');
        setSession(data.session);
        // Only set loading to false if no auth state change has occurred yet
        setLoading(false);
      } catch (error) {
        console.error('Unexpected error in getInitialSession:', error);
        setLoading(false);
      }
    };

    getInitialSession();

    // Failsafe timeout to prevent infinite loading
    const timeoutId = setTimeout(() => {
      if (loading) {
        console.log('Auth loading timeout reached in useAuthState');
        setLoading(false);
      }
    }, 5000); // 5 second timeout

    return () => {
      subscription.unsubscribe();
      clearTimeout(timeoutId);
    };
  }, []);

  return { session, loading };
};
