
import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export const useRemoveProfessional = () => {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const removeProfessional = async (professionalId: string) => {
    if (!confirm('Tem certeza que deseja remover este profissional da unidade?')) return;

    try {
      setLoading(true);
      const { error } = await supabase
        .from('profiles')
        .update({ unit_id: null })
        .eq('id', professionalId);

      if (error) throw error;

      toast({
        title: "Profissional removido",
        description: "O profissional foi removido da unidade com sucesso.",
      });

      window.location.reload();
    } catch (error: any) {
      console.error('Error removing professional:', error);
      toast({
        variant: "destructive",
        title: "Erro ao remover profissional",
        description: error.message || "Ocorreu um erro ao remover o profissional.",
      });
    } finally {
      setLoading(false);
    }
  };

  return { removeProfessional, loading };
};
