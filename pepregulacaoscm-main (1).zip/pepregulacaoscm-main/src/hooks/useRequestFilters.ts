
import { useState } from 'react';
import { RequestStatus, RequestPriority, RequestRecord } from '@/types';

export const useRequestFilters = (requests: RequestRecord[]) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<RequestStatus | 'all'>('all');
  const [priorityFilter, setPriorityFilter] = useState<RequestPriority | 'all'>('all');

  // Filter requests based on search term, status, and priority
  const filteredRequests = requests.filter(request => {
    const matchesSearch = 
      (request.patient?.name?.toLowerCase().includes(searchTerm.toLowerCase()) || '') ||
      request.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      request.specialty.toLowerCase().includes(searchTerm.toLowerCase());
      
    const matchesStatus = 
      statusFilter === 'all' || 
      request.status === statusFilter;
      
    const matchesPriority = 
      priorityFilter === 'all' || 
      request.priority === priorityFilter;
      
    return matchesSearch && matchesStatus && matchesPriority;
  });
  
  const handleStatusFilterChange = (status: RequestStatus | 'all') => {
    setStatusFilter(status);
  };
  
  const handlePriorityFilterChange = (priority: RequestPriority | 'all') => {
    setPriorityFilter(priority);
  };

  return {
    searchTerm,
    setSearchTerm,
    statusFilter,
    priorityFilter,
    handleStatusFilterChange,
    handlePriorityFilterChange,
    filteredRequests
  };
};
