
import { useState, useCallback, useEffect } from 'react';
import { Patient } from '@/types';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/components/ui/use-toast';
import { useUser } from '@/contexts/UserContext';

export const usePatients = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('all');
  const [patients, setPatients] = useState<Patient[]>([]);
  const [loading, setLoading] = useState(false);
  
  // Get the current user to filter by unit
  const { currentUser, hasPermission } = useUser();
  
  // Check if user is admin or manager (can see all patients)
  const canSeeAllPatients = hasPermission(['admin', 'manager']);
  
  // Format a CPF (Brazilian tax ID) string
  const formatCPF = useCallback((cpf: string) => {
    // Return the CPF already formatted if it contains dots or dashes
    if (cpf.includes('.') || cpf.includes('-')) {
      return cpf;
    }
    
    // Format a plain CPF string
    return cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
  }, []);
  
  // Fetch patients from Supabase
  useEffect(() => {
    const fetchPatients = async () => {
      try {
        setLoading(true);
        
        // Start building the query
        let query = supabase.from('patients').select('*');
        
        // Filter by unit if user is not admin/manager and has a unit
        if (!canSeeAllPatients && currentUser?.unit?.id) {
          query = query.eq('unit_id', currentUser.unit.id);
        }
        
        const { data, error } = await query;
          
        if (error) {
          throw error;
        }
        
        if (!data) {
          setPatients([]);
          return;
        }
        
        // Get unit names for patients with unit_id
        const patientUnits = new Map();
        
        if (data.length > 0) {
          const unitIds = data
            .filter(patient => patient.unit_id)
            .map(patient => patient.unit_id);
            
          if (unitIds.length > 0) {
            const { data: unitData } = await supabase
              .from('health_units')
              .select('id, name')
              .in('id', unitIds);
              
            if (unitData) {
              unitData.forEach(unit => {
                patientUnits.set(unit.id, unit.name);
              });
            }
          }
        }
        
        // Transform database patients to match the frontend Patient type
        const transformedPatients: Patient[] = data.map(patient => {
          // Ensure contacts is properly transformed to match the Patient type
          let typedContacts: { type: 'phone' | 'mobile' | 'email'; value: string }[] = [];
          
          if (Array.isArray(patient.contacts)) {
            typedContacts = patient.contacts
              .filter((contact: any) => 
                contact && typeof contact === 'object' && contact.type && contact.value
              )
              .map((contact: any) => ({
                type: ['phone', 'mobile', 'email'].includes(contact.type) 
                  ? (contact.type as 'phone' | 'mobile' | 'email')
                  : 'phone', // Default to phone if type is invalid
                value: String(contact.value)
              }));
          }
          
          // Get unit name from our map if available
          const unitName = patient.unit_id ? patientUnits.get(patient.unit_id) : undefined;
          
          return {
            id: patient.id,
            name: patient.name,
            cpf: patient.cpf,
            rg: patient.rg || undefined,
            cns: patient.cns || undefined,
            birthDate: patient.birth_date,
            gender: patient.gender as 'male' | 'female' | 'other',
            race: patient.race || undefined,
            bloodType: patient.blood_type || undefined,
            motherName: patient.mother_name || undefined,
            fatherName: patient.father_name || undefined,
            address: {
              street: patient.street,
              number: patient.number,
              complement: patient.complement || undefined,
              neighborhood: patient.neighborhood,
              city: patient.city,
              state: patient.state,
              zipCode: patient.zip_code
            },
            contacts: typedContacts,
            status: patient.status as 'active' | 'inactive',
            createdAt: patient.created_at,
            updatedAt: patient.updated_at,
            unitId: patient.unit_id || undefined,
            unitName: unitName || currentUser?.unit?.name
          };
        });
        
        setPatients(transformedPatients);
      } catch (error) {
        console.error('Error fetching patients:', error);
        toast({
          variant: "destructive",
          title: "Erro ao carregar pacientes",
          description: "Não foi possível carregar a lista de pacientes."
        });
      } finally {
        setLoading(false);
      }
    };
    
    fetchPatients();
  }, [canSeeAllPatients, currentUser?.unit?.id, currentUser?.unit?.name]);
  
  // Filter patients based on search term and status
  const filteredPatients = patients.filter(patient => {
    const matchesSearch = 
      patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patient.cpf.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (patient.cns && patient.cns.toLowerCase().includes(searchTerm.toLowerCase()));
      
    const matchesStatus = 
      statusFilter === 'all' || 
      patient.status === statusFilter;
      
    return matchesSearch && matchesStatus;
  });
  
  const handleStatusFilterChange = (status: 'all' | 'active' | 'inactive') => {
    setStatusFilter(status);
  };
  
  return {
    searchTerm,
    setSearchTerm,
    statusFilter,
    handleStatusFilterChange,
    filteredPatients,
    formatCPF,
    loading,
    canSeeAllPatients
  };
};
