
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useUser } from '@/contexts/UserContext';
import { requestFormSchema, RequestFormValues } from '@/components/requests/form/RequestFormSchema';

export const useRequestForm = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { currentUser } = useUser();
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form initialization
  const form = useForm<RequestFormValues>({
    resolver: zodResolver(requestFormSchema),
    defaultValues: {
      requestType: 'consultation',
      priority: 'medium',
      specialty: '',
      icdCode: '',
      clinicalReason: '',
      observations: '',
    },
  });

  const onSubmit = async (values: RequestFormValues) => {
    if (!currentUser) {
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Você precisa estar autenticado para criar uma solicitação.",
      });
      return;
    }

    setIsSubmitting(true);

    try {
      const { data, error } = await supabase
        .from('requests')
        .insert({
          patient_id: values.patientId,
          request_type: values.requestType,
          specialty: values.specialty,
          priority: values.priority,
          icd_code: values.icdCode,
          clinical_reason: values.clinicalReason,
          suggested_unit_id: values.suggestedUnitId || null,
          observations: values.observations || null,
          requested_by: currentUser.id,
        })
        .select();

      if (error) throw error;

      toast({
        title: "Solicitação criada",
        description: "Solicitação criada com sucesso.",
      });

      navigate('/requests');
    } catch (error) {
      console.error('Error creating request:', error);
      toast({
        variant: "destructive",
        title: "Erro ao criar solicitação",
        description: "Ocorreu um erro ao criar a solicitação. Tente novamente.",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return {
    form,
    onSubmit,
    isSubmitting,
  };
};
