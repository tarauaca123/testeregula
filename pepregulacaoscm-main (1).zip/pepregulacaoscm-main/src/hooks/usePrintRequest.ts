
import { useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export const usePrintRequest = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const printContentRef = useRef<HTMLDivElement>(null);
  
  // Fetch request data
  const { data: request, isLoading, error } = useQuery({
    queryKey: ['request-print', id],
    queryFn: async () => {
      if (!id) throw new Error('ID da solicitação não fornecido');
      
      // Buscar solicitação
      const { data: requestData, error: requestError } = await supabase
        .from('requests')
        .select('*')
        .eq('id', id)
        .single();
        
      if (requestError) throw requestError;
      
      // Buscar paciente
      const { data: patientData, error: patientError } = await supabase
        .from('patients')
        .select('id, name, cpf, gender, birth_date, signature')
        .eq('id', requestData.patient_id)
        .single();
        
      if (patientError) throw patientError;
      
      // Buscar solicitante
      const { data: requesterData } = await supabase
        .from('profiles')
        .select('id, name, email')
        .eq('id', requestData.requested_by)
        .single();
      
      // Buscar unidade sugerida (se existir)
      let suggestedUnitData = null;
      if (requestData.suggested_unit_id) {
        const { data } = await supabase
          .from('health_units')
          .select('id, name')
          .eq('id', requestData.suggested_unit_id)
          .single();
        suggestedUnitData = data;
      }
      
      // Retornar dados completos
      return {
        ...requestData,
        patient: patientData,
        requestedBy: requesterData,
        suggestedUnit: suggestedUnitData
      };
    },
  });

  const handlePrint = () => {
    const printContent = printContentRef.current;
    if (!printContent) return;
    
    // Create a new window for printing
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('Por favor, permita pop-ups para imprimir');
      return;
    }
    
    // Get the HTML content to print
    const contentToPrint = printContent.innerHTML;
    
    // Write to the new window
    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Solicitação #${id}</title>
          <style>
            @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
            
            body {
              font-family: 'Inter', sans-serif;
              line-height: 1.5;
              margin: 0;
              padding: 20px;
              color: #374151;
              background-color: #f9fafb;
            }
            
            .print-container {
              max-width: 800px;
              margin: 0 auto;
              background-color: #ffffff;
              border-radius: 8px;
              box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
              padding: 24px;
            }
            
            .header {
              text-align: center;
              margin-bottom: 24px;
              padding-bottom: 16px;
              border-bottom: 1px solid #e5e7eb;
              position: relative;
            }
            
            .header h1 {
              margin-bottom: 4px;
              color: #1f2937;
              font-size: 24px;
              font-weight: 700;
            }
            
            .header-code {
              display: inline-flex;
              align-items: center;
              background-color: #f3f4f6;
              border-radius: 50px;
              padding: 6px 12px;
              font-size: 14px;
              font-weight: 500;
              margin-top: 8px;
              color: #4b5563;
            }
            
            .header-code .dots {
              display: flex;
              align-items: center;
              margin-right: 8px;
            }
            
            .dot {
              width: 6px;
              height: 6px;
              border-radius: 50%;
              margin-right: 4px;
              background-color: #0077B6;
            }
            
            .dot:nth-child(2) {
              background-color: #00B4D8;
            }
            
            .dot:nth-child(3) {
              background-color: #57CC99;
            }
            
            .code-text {
              letter-spacing: 1px;
              font-family: monospace;
            }
            
            .header-date {
              display: flex;
              align-items: center;
              justify-content: center;
              margin-top: 8px;
              font-size: 14px;
              color: #6b7280;
            }
            
            .header-date > div {
              display: flex;
              align-items: center;
              margin: 0 8px;
            }
            
            .header-date svg {
              margin-right: 4px;
            }
            
            .section {
              margin-bottom: 24px;
              padding-bottom: 16px;
              border-bottom: 1px solid #f3f4f6;
            }
            
            .section-title {
              font-size: 16px;
              font-weight: 600;
              margin-bottom: 12px;
              padding-left: 12px;
              border-left: 4px solid #0077B6;
              color: #1f2937;
            }
            
            .field {
              display: flex;
              margin-bottom: 8px;
              padding: 4px 0;
            }
            
            .field-label {
              font-weight: 500;
              width: 200px;
              color: #4b5563;
            }
            
            .field-value {
              flex: 1;
              color: #1f2937;
            }
            
            .priority-high {
              color: #DC2626;
              font-weight: 600;
            }
            
            .priority-medium {
              color: #F59E0B;
              font-weight: 600;
            }
            
            .priority-low {
              color: #059669;
              font-weight: 600;
            }
            
            .status-approved {
              color: #059669;
              font-weight: 600;
            }
            
            .status-rejected {
              color: #DC2626;
              font-weight: 600;
            }
            
            .status-processing {
              color: #3B82F6;
              font-weight: 600;
            }
            
            .status-pending {
              color: #F59E0B;
              font-weight: 600;
            }
            
            .footer {
              margin-top: 32px;
              display: flex;
              justify-content: space-between;
              align-items: flex-end;
            }
            
            .signature {
              border-top: 1px solid #9ca3af;
              width: 250px;
              text-align: center;
              padding-top: 5px;
              color: #4b5563;
              font-size: 14px;
            }
            
            .qr-container {
              text-align: right;
            }
            
            .qr-container p {
              margin-top: 4px;
              font-size: 12px;
              color: #6b7280;
            }
            
            .text-content {
              background-color: #f9fafb;
              padding: 12px;
              border-radius: 4px;
              white-space: pre-line;
              font-size: 14px;
            }
            
            @media print {
              body {
                background-color: #ffffff;
              }
              
              .print-container {
                box-shadow: none;
                padding: 0;
              }
              
              .no-print {
                display: none;
              }
            }
          </style>
        </head>
        <body>
          <div class="print-container">
            ${contentToPrint}
          </div>
          <script>
            window.onload = function() {
              window.print();
              window.setTimeout(function() {
                window.close();
              }, 500);
            }
          </script>
        </body>
      </html>
    `);
    
    printWindow.document.close();
  };
  
  // Generate the base URL for the QR code
  const getBaseUrl = () => {
    const url = window.location.origin;
    return `${url}/requests/${id}`;
  };

  return {
    id,
    request,
    isLoading,
    error,
    navigate,
    printContentRef,
    handlePrint,
    baseUrl: getBaseUrl()
  };
};
