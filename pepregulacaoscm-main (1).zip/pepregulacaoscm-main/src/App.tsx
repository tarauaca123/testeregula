
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { UserProvider } from "@/contexts/UserContext";
import DashboardWrapper from "./components/layout/DashboardWrapper";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Patients from "./pages/Patients";
import PatientDetail from "./pages/PatientDetail";
import PatientNew from "./pages/PatientNew";
import Requests from "./pages/Requests";
import RequestNew from "./pages/RequestNew";
import RequestDetail from "./pages/RequestDetail";
import RequestPrint from "./pages/RequestPrint";
import Units from "./pages/Units";
import UnitNew from "./pages/UnitNew";
import UnitProfessionals from "./pages/UnitProfessionals";
import UnitRequests from "./pages/UnitRequests";
import UnitProcedures from "./pages/UnitProcedures";
import Settings from "./pages/Settings";
import NotFound from "./pages/NotFound";
import Error from "./pages/Error";
import Index from "./pages/Index";
import PatientEdit from "./pages/PatientEdit";
import UserProfile from "./pages/UserProfile";
import UserPreferences from "./pages/UserPreferences";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <UserProvider>
        <BrowserRouter>
          <Routes>
            {/* Root route redirects based on auth status */}
            <Route path="/" element={<Index />} />
            
            {/* Auth routes */}
            <Route path="/login" element={<Login />} />
            
            {/* Error routes */}
            <Route path="/error" element={<Error />} />
            
            {/* Protected dashboard routes - DashboardWrapper handles auth check */}
            <Route element={<DashboardWrapper />}>
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/patients" element={<Patients />} />
              <Route path="/patients/new" element={<PatientNew />} />
              <Route path="/patients/:id" element={<PatientDetail />} />
              <Route path="/patients/edit/:id" element={<PatientEdit />} />
              <Route path="/requests" element={<Requests />} />
              <Route path="/requests/new" element={<RequestNew />} />
              <Route path="/requests/:id" element={<RequestDetail />} />
              <Route path="/requests/print/:id" element={<RequestPrint />} />
              <Route path="/units" element={<Units />} />
              <Route path="/units/new" element={<UnitNew />} />
              <Route path="/units/:id/professionals" element={<UnitProfessionals />} />
              <Route path="/units/:id/procedures" element={<UnitProcedures />} />
              <Route path="/units/:id/requests" element={<UnitRequests />} />
              <Route path="/settings" element={<Settings />} />
              <Route path="/profile" element={<UserProfile />} />
              <Route path="/preferences" element={<UserPreferences />} />
            </Route>
            
            {/* 404 route */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
        <Toaster />
        <Sonner />
      </UserProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
