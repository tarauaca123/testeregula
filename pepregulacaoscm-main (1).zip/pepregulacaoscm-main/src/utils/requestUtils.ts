
import { RequestStatus, RequestPriority, RequestType } from '@/types';

// Get request status class
export const getStatusClass = (status: RequestStatus) => {
  switch (status) {
    case 'pending': return 'bg-yellow-100 text-yellow-800 px-2 py-1 rounded text-xs font-medium';
    case 'approved': return 'bg-green-100 text-green-800 px-2 py-1 rounded text-xs font-medium';
    case 'rejected': return 'bg-red-100 text-red-800 px-2 py-1 rounded text-xs font-medium';
    case 'processing': return 'bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs font-medium';
    case 'closed': return 'bg-gray-100 text-gray-800 px-2 py-1 rounded text-xs font-medium';
    case 'in_unit': return 'bg-purple-100 text-purple-800 px-2 py-1 rounded text-xs font-medium';
    default: return '';
  }
};

// Get priority class
export const getPriorityClass = (priority: RequestPriority | 'auto') => {
  switch (priority) {
    case 'low': return 'bg-gray-100 text-gray-800 px-2 py-1 rounded text-xs font-medium';
    case 'medium': return 'bg-orange-100 text-orange-800 px-2 py-1 rounded text-xs font-medium';
    case 'high': return 'bg-red-100 text-red-800 px-2 py-1 rounded text-xs font-medium';
    case 'auto': return 'bg-purple-100 text-purple-800 px-2 py-1 rounded text-xs font-medium';
    default: return '';
  }
};

// Get status text in Portuguese
export const getStatusText = (status: RequestStatus) => {
  switch (status) {
    case 'pending': return 'Pendente';
    case 'approved': return 'Aprovada';
    case 'rejected': return 'Rejeitada';
    case 'processing': return 'Em Análise';
    case 'closed': return 'Regulação Fechada';
    case 'in_unit': return 'Paciente na Unidade';
    default: return status;
  }
};

// Get priority text in Portuguese
export const getPriorityText = (priority: RequestPriority | 'auto') => {
  switch (priority) {
    case 'low': return 'Baixa';
    case 'medium': return 'Média';
    case 'high': return 'Alta';
    case 'auto': return 'Automática';
    default: return priority;
  }
};

// Get request type text in Portuguese
export const getRequestTypeText = (type: string) => {
  switch (type) {
    case 'consultation': return 'Consulta';
    case 'exam': return 'Exame';
    case 'surgery': return 'Cirurgia';
    case 'hospitalization': return 'Internação';
    default: return type;
  }
};

// Format date to Brazilian format
export const formatDate = (dateString: string) => {
  return new Date(dateString).toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  });
};
