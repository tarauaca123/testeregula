
export class DashboardUtils {
  static getStatusClass(status: string) {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800 px-2 py-1 rounded text-xs font-medium';
      case 'approved': return 'bg-green-100 text-green-800 px-2 py-1 rounded text-xs font-medium';
      case 'rejected': return 'bg-red-100 text-red-800 px-2 py-1 rounded text-xs font-medium';
      case 'processing': return 'bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs font-medium';
      default: return '';
    }
  }

  static getPriorityClass(priority: string) {
    switch (priority) {
      case 'low': return 'bg-green-100 text-green-800 px-2 py-1 rounded text-xs font-medium';
      case 'medium': return 'bg-yellow-100 text-yellow-800 px-2 py-1 rounded text-xs font-medium';
      case 'high': return 'bg-red-100 text-red-800 px-2 py-1 rounded text-xs font-medium';
      default: return '';
    }
  }

  static formatDate(dateString: string) {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  }
}
