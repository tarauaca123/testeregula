
import { RequestStatus, RequestPriority } from '@/types';
import { formatDate } from '@/utils/requestUtils';

// Format CPF function
export const formatCPF = (cpf: string) => {
  if (!cpf) return '';
  if (cpf.includes('.') || cpf.includes('-')) return cpf;
  return cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
};

// Get gender in readable format
export const getGenderText = (gender: string) => {
  switch (gender) {
    case 'male': return 'Masculino';
    case 'female': return 'Feminino';
    case 'other': return 'Outro';
    default: return gender;
  }
};

// Get request status in readable format
export const getStatusText = (status: string) => {
  switch (status) {
    case 'pending': return 'Pendente';
    case 'approved': return 'Aprovado';
    case 'rejected': return 'Rejeitado';
    case 'processing': return 'Em Análise';
    default: return status;
  }
};

// Get priority in readable format
export const getPriorityText = (priority: string) => {
  switch (priority) {
    case 'low': return 'Baixa';
    case 'medium': return 'Média';
    case 'high': return 'Alta';
    default: return priority;
  }
};

// Get priority CSS class
export const getPriorityClass = (priority: string) => {
  switch (priority) {
    case 'low': return 'priority-low';
    case 'medium': return 'priority-medium';
    case 'high': return 'priority-high';
    default: return '';
  }
};

// Get status CSS class
export const getStatusClass = (status: string) => {
  switch (status) {
    case 'pending': return 'status-pending';
    case 'approved': return 'status-approved';
    case 'rejected': return 'status-rejected';
    case 'processing': return 'status-processing';
    default: return '';
  }
};

// Get request type in readable format
export const getRequestTypeText = (type: string) => {
  switch (type) {
    case 'consultation': return 'Consulta';
    case 'exam': return 'Exame';
    case 'surgery': return 'Cirurgia';
    case 'hospitalization': return 'Internação';
    default: return type;
  }
};

// Format datetime - show date and time
export const formatDateTime = (dateString: string) => {
  if (!dateString) return '--';
  
  return new Date(dateString).toLocaleString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
};

// Re-export formatDate to avoid circular dependency
export { formatDate };
