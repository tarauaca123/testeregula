
/**
 * Format CPF (Brazilian ID) with dots and dash
 */
export const formatCPF = (value: string) => {
  // If already formatted, return as is
  if (value.includes('.') || value.includes('-')) return value;
  
  // Remove any non-digit character
  value = value.replace(/\D/g, '');
  
  // Format the CPF
  if (value.length <= 11) {
    value = value.replace(/(\d{3})(\d)/, '$1.$2');
    value = value.replace(/(\d{3})(\d)/, '$1.$2');
    value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
  }
  
  return value;
};

/**
 * Format CEP (Brazilian Postal Code) with dash
 */
export const formatCEP = (value: string) => {
  // If already formatted, return as is
  if (value.includes('-')) return value;
  
  // Remove any non-digit character
  value = value.replace(/\D/g, '');
  
  // Format the CEP
  if (value.length <= 8) {
    value = value.replace(/(\d{5})(\d)/, '$1-$2');
  }
  
  return value;
};

/**
 * Format phone number with parentheses and dash
 */
export const formatPhone = (value: string) => {
  // If already formatted, return as is
  if (value.includes('(') || value.includes(')') || value.includes('-')) return value;
  
  // Remove any non-digit character
  value = value.replace(/\D/g, '');
  
  // Format the phone number
  if (value.length <= 10) {
    // Fixed phone format: (XX) XXXX-XXXX
    value = value.replace(/(\d{2})(\d)/, '($1) $2');
    value = value.replace(/(\d{4})(\d)/, '$1-$2');
  } else {
    // Mobile phone format: (XX) XXXXX-XXXX
    value = value.replace(/(\d{2})(\d)/, '($1) $2');
    value = value.replace(/(\d{5})(\d)/, '$1-$2');
  }
  
  return value;
};

/**
 * Format CNS (National Health Card) - 15 digits with no separators
 */
export const formatCNS = (value: string) => {
  // Remove any non-digit character
  value = value.replace(/\D/g, '');
  
  // Limit to 15 digits
  if (value.length > 15) {
    value = value.substring(0, 15);
  }
  
  return value;
};

/**
 * Validate CPF according to Brazilian rules
 */
export const validateCPF = (cpf: string): boolean => {
  // Remove non-digits
  cpf = cpf.replace(/\D/g, '');
  
  // Check if has 11 digits
  if (cpf.length !== 11) return false;
  
  // Check if all digits are the same
  if (/^(\d)\1{10}$/.test(cpf)) return false;
  
  // Validate check digits
  let sum = 0;
  let remainder;
  
  for (let i = 1; i <= 9; i++) {
    sum += parseInt(cpf.substring(i - 1, i)) * (11 - i);
  }
  
  remainder = (sum * 10) % 11;
  if (remainder === 10 || remainder === 11) remainder = 0;
  if (remainder !== parseInt(cpf.substring(9, 10))) return false;
  
  sum = 0;
  for (let i = 1; i <= 10; i++) {
    sum += parseInt(cpf.substring(i - 1, i)) * (12 - i);
  }
  
  remainder = (sum * 10) % 11;
  if (remainder === 10 || remainder === 11) remainder = 0;
  if (remainder !== parseInt(cpf.substring(10, 11))) return false;
  
  return true;
};

/**
 * Validate CNS according to Brazilian rules
 */
export const validateCNS = (cns: string): boolean => {
  // Remove non-digits
  cns = cns.replace(/\D/g, '');
  
  // Check if has 15 digits
  if (cns.length !== 15) return false;
  
  // CNS starting with 1 or 2
  if (['1', '2'].includes(cns.substring(0, 1))) {
    let sum = 0;
    for (let i = 0; i < 15; i++) {
      sum += parseInt(cns.substring(i, i + 1)) * (15 - i);
    }
    return sum % 11 === 0;
  }
  
  // CNS starting with 7, 8 or 9
  if (['7', '8', '9'].includes(cns.substring(0, 1))) {
    let sum = 0;
    for (let i = 0; i < 15; i++) {
      sum += parseInt(cns.substring(i, i + 1)) * (15 - i);
    }
    return sum % 11 === 0;
  }
  
  return false;
};
