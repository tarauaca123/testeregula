
import React, { useEffect } from 'react';
import { SidebarProvider, SidebarTrigger } from '@/components/ui/sidebar';
import { Toaster } from '@/components/ui/toaster';
import { AppSidebar } from './AppSidebar';
import { AppHeader } from './AppHeader';
import { Outlet, useNavigate } from 'react-router-dom';
import { useUser } from '@/contexts/UserContext';
import { useToast } from '@/components/ui/use-toast';
import { Skeleton } from '@/components/ui/skeleton';
import { Loader2 } from 'lucide-react';

export const DashboardWrapper = () => {
  const { currentUser, session, loading } = useUser();
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    // Check if user is authenticated
    if (!loading && !session) {
      console.log('No session in DashboardWrapper, redirecting to login');
      toast({
        variant: "destructive",
        title: "Acesso não autorizado",
        description: "É necessário estar logado para acessar esta página."
      });
      navigate('/login');
    }
  }, [session, loading, navigate, toast]);

  // Mostrar um carregamento mais discreto enquanto verifica autenticação
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto mb-4" />
          <h2 className="text-xl font-semibold">Verificando autenticação...</h2>
          <p className="text-muted-foreground">Aguarde enquanto verificamos suas credenciais.</p>
        </div>
      </div>
    );
  }

  // Se não estiver carregando e não estiver autenticado, não renderiza conteúdo
  // Isso previne qualquer flash de conteúdo protegido antes do redirecionamento
  if (!session) {
    return null;
  }

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <AppSidebar />
        <div className="flex-1 flex flex-col min-h-screen">
          <AppHeader />
          <main className="flex-1 container mx-auto p-4 md:p-6">
            <Outlet />
          </main>
        </div>
      </div>
      <Toaster />
    </SidebarProvider>
  );
};

export default DashboardWrapper;
