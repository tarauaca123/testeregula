
import React from 'react';
import { User } from 'lucide-react';
import { User as UserType } from '@/contexts/types/userTypes';

interface UserAvatarProps {
  currentUser: UserType | null;
}

export const UserAvatar: React.FC<UserAvatarProps> = ({ currentUser }) => {
  // Get display initial for avatar
  const getInitial = () => {
    if (currentUser?.name) {
      return currentUser.name.charAt(0).toUpperCase();
    }
    return 'U';
  };

  return (
    <div className="w-8 h-8 rounded-full bg-medical-primary text-white flex items-center justify-center">
      {currentUser?.name ? getInitial() : <User className="h-4 w-4" />}
    </div>
  );
};
