
import React from 'react';
import { useLocation } from 'react-router-dom';

interface BreadcrumbItem {
  path: string;
  label: string;
  isLast: boolean;
}

const routeTitles: Record<string, string> = {
  '/dashboard': 'Dashboard',
  '/patients': 'Pacientes',
  '/patients/new': 'Novo Paciente',
  '/patients/edit': 'Editar Paciente',
  '/patients/view': 'Detalhes do Paciente',
  '/requests': 'Solicitações',
  '/requests/new': 'Nova Solicitação',
  '/requests/edit': 'Editar Solicitação',
  '/requests/view': 'Detalhes da Solicitação',
  '/units': 'Unidades',
  '/units/new': 'Nova Unidade',
  '/units/edit': 'Editar Unidade',
  '/units/view': 'Detalhes da Unidade',
  '/settings': 'Configurações',
  '/login': 'Login',
};

export const HeaderBreadcrumbs = () => {
  const location = useLocation();
  
  const pathParts = location.pathname.split('/');
  const basePath = `/${pathParts[1]}`;
  const subPath = pathParts[2] ? `/${pathParts[2]}` : '';
  const titlePath = pathParts[3] ? basePath + '/view' : basePath + subPath;
  
  const pageTitle = routeTitles[titlePath] || 'Health Regulation';

  const generateBreadcrumbs = () => {
    const crumbs: BreadcrumbItem[] = [];
    let path = '';
    
    pathParts.forEach((part, index) => {
      if (index === 0 || part === '') return;
      
      path += `/${part}`;
      const isLast = index === pathParts.length - 1;
      
      if (index > 1 && !isNaN(Number(part))) return;
      
      let label = part.charAt(0).toUpperCase() + part.slice(1);
      if (routeTitles[path]) {
        label = routeTitles[path];
      } else if (path.includes('new')) {
        label = 'Novo';
      } else if (path.includes('edit')) {
        label = 'Editar';
      } else if (path.includes('view')) {
        label = 'Detalhes';
      }
      
      crumbs.push({
        path,
        label,
        isLast
      });
    });
    
    return crumbs;
  };

  const breadcrumbs = generateBreadcrumbs();

  return (
    <div>
      <h1 className="text-xl font-bold">{pageTitle}</h1>
      {breadcrumbs.length > 0 && (
        <div className="breadcrumb-container">
          <span>Home</span>
          {breadcrumbs.map((crumb, index) => (
            <React.Fragment key={index}>
              <span className="breadcrumb-separator">/</span>
              <span className={crumb.isLast ? 'breadcrumb-current' : ''}>
                {crumb.label}
              </span>
            </React.Fragment>
          ))}
        </div>
      )}
    </div>
  );
};

export { routeTitles };
