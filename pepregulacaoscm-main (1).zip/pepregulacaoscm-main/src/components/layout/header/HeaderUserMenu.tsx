
import React from 'react';
import { ChevronDown } from 'lucide-react';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { useUser } from '@/contexts/UserContext';
import { UserAvatar } from './UserAvatar';
import { UserInfo } from './UserInfo';
import { UserMenuItems } from './UserMenuItems';

export const HeaderUserMenu = () => {
  const { currentUser, logout } = useUser();

  const handleSignOut = async () => {
    try {
      await logout();
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="flex items-center gap-2 hover:bg-muted">
          <UserAvatar currentUser={currentUser} />
          <UserInfo currentUser={currentUser} />
          <ChevronDown className="h-4 w-4 text-muted-foreground" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <UserInfo currentUser={currentUser} compact />
        <UserMenuItems onSignOut={handleSignOut} />
      </DropdownMenuContent>
    </DropdownMenu>
  );
};
