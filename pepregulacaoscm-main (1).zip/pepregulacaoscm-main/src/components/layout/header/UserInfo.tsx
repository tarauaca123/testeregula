
import React from 'react';
import { User } from '@/contexts/types/userTypes';

interface UserInfoProps {
  currentUser: User | null;
  compact?: boolean;
}

export const UserInfo: React.FC<UserInfoProps> = ({ currentUser, compact = false }) => {
  // Get display name with proper fallback
  const displayName = currentUser?.name || currentUser?.email || 'Usuário';
  const unitName = currentUser?.unit?.name || 'Unidade de Saúde';
  
  if (compact) {
    return (
      <div className="p-2">
        <p className="font-medium">{displayName}</p>
        <p className="text-xs text-muted-foreground truncate">{currentUser?.email || 'usuario@email.com'}</p>
      </div>
    );
  }
  
  return (
    <div className="hidden md:block text-left">
      <p className="text-sm font-medium">{displayName}</p>
      <p className="text-xs text-muted-foreground">{unitName}</p>
    </div>
  );
};
