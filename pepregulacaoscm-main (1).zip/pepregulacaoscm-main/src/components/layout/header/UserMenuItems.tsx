
import React from 'react';
import { Link } from 'react-router-dom';
import {
  DropdownMenuItem,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';

interface UserMenuItemsProps {
  onSignOut: () => void;
}

export const UserMenuItems: React.FC<UserMenuItemsProps> = ({ onSignOut }) => {
  return (
    <>
      <DropdownMenuSeparator />
      <DropdownMenuItem asChild>
        <Link to="/profile" className="w-full cursor-pointer">Perfil</Link>
      </DropdownMenuItem>
      <DropdownMenuItem asChild>
        <Link to="/preferences" className="w-full cursor-pointer">Preferências</Link>
      </DropdownMenuItem>
      <DropdownMenuSeparator />
      <DropdownMenuItem onClick={onSignOut}>Sair</DropdownMenuItem>
    </>
  );
};
