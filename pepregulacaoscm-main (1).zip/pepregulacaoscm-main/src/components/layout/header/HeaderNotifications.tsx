
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Bell } from 'lucide-react';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { useRecentRequests } from '@/hooks/useRecentRequests';
import { useUnitRecentRequests } from '@/hooks/useUnitRecentRequests';
import { useUser } from '@/contexts/UserContext';
import { NotificationsList } from '@/components/notifications/NotificationsList';
import { useNotifications } from '@/hooks/useNotifications';

export const HeaderNotifications = () => {
  const navigate = useNavigate();
  const { currentUser } = useUser();
  const isAdmin = currentUser?.role === 'admin';
  
  const { requests: adminRequests, loading: isAdminLoading } = useRecentRequests();
  const { requests: unitRequests, loading: isUnitLoading } = useUnitRecentRequests();
  
  const requests = isAdmin ? adminRequests : unitRequests;
  const isLoading = isAdmin ? isAdminLoading : isUnitLoading;

  const { 
    viewedNotifications, 
    unviewedCount, 
    isOpen, 
    handleNotificationClick, 
    handleDropdownOpenChange 
  } = useNotifications({
    requests,
    onNavigate: (requestId) => navigate(`/requests/${requestId}`)
  });

  return (
    <DropdownMenu open={isOpen} onOpenChange={handleDropdownOpenChange}>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="h-5 w-5" />
          {unviewedCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full w-4 h-4 text-xs flex items-center justify-center">
              {unviewedCount}
            </span>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80">
        <div className="px-4 py-2 font-medium border-b">
          <h3>Notificações</h3>
        </div>
        <div className="max-h-[400px] overflow-y-auto">
          <NotificationsList
            requests={requests}
            isLoading={isLoading}
            viewedNotifications={viewedNotifications}
            onNotificationClick={handleNotificationClick}
          />
        </div>
        <div className="p-2 border-t">
          <Button 
            variant="ghost" 
            size="sm" 
            className="w-full text-xs" 
            onClick={() => navigate('/requests')}
          >
            Ver todas as solicitações
          </Button>
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};
