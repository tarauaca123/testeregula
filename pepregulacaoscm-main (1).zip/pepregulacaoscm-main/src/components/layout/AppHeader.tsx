
import React from 'react';
import { SidebarTrigger } from '@/components/ui/sidebar';
import { HeaderNotifications } from './header/HeaderNotifications';
import { HeaderUserMenu } from './header/HeaderUserMenu';
import { HeaderBreadcrumbs } from './header/HeaderBreadcrumbs';

export const AppHeader = () => {
  return (
    <header className="border-b bg-background px-4 py-3 flex items-center justify-between">
      <div className="flex items-center">
        <SidebarTrigger className="mr-2 md:mr-4" />
        <HeaderBreadcrumbs />
      </div>
      <div className="flex items-center gap-4">
        <HeaderNotifications />
        <HeaderUserMenu />
      </div>
    </header>
  );
};
