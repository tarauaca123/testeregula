
import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import {
  Activity,
  Users,
  FileText,
  Building2,
  Settings,
  LogOut,
  HelpCircle,
} from 'lucide-react';
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from '@/components/ui/sidebar';
import { useUser } from '@/contexts/UserContext';
import { useToast } from '@/components/ui/use-toast';

// Configuração dos itens do menu
const menuItems = [
  { 
    title: 'Dashboard', 
    path: '/dashboard', 
    icon: Activity, 
    allowedRoles: ['admin', 'manager', 'operator', 'readonly', 'doctor', 'regulator', 'receptionist'] 
  },
  { 
    title: 'Pacientes', 
    path: '/patients', 
    icon: Users,
    allowedRoles: ['admin', 'manager', 'operator', 'readonly', 'doctor', 'regulator', 'receptionist'] 
  },
  { 
    title: 'Solicitações', 
    path: '/requests', 
    icon: FileText,
    allowedRoles: ['admin', 'manager', 'operator', 'readonly', 'doctor', 'regulator', 'receptionist'] 
  },
  { 
    title: 'Unidades', 
    path: '/units', 
    icon: Building2,
    allowedRoles: ['admin', 'manager', 'readonly'] 
  },
  { 
    title: 'Configurações', 
    path: '/settings', 
    icon: Settings,
    allowedRoles: ['admin'] 
  },
];

export function AppSidebar() {
  const { currentUser, hasPermission, logout } = useUser();
  const navigate = useNavigate();
  const { toast } = useToast();

  // Filtra itens do menu com base na função do usuário
  const filteredMenuItems = menuItems.filter(item => 
    item.allowedRoles.includes(currentUser?.role || '')
  );

  const handleLogout = () => {
    logout();
    toast({
      title: "Logout realizado",
      description: "Você foi desconectado com sucesso.",
    });
    navigate('/login');
  };

  return (
    <Sidebar>
      <SidebarHeader className="flex justify-center items-center p-4">
        <h2 className="text-lg font-bold text-white">Regulação em Saúde</h2>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              {filteredMenuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <NavLink 
                      to={item.path}
                      className={({ isActive }) => isActive ? "bg-sidebar-primary" : ""}
                    >
                      <item.icon className="h-5 w-5" />
                      <span>{item.title}</span>
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="p-4">
        <div className="flex flex-col space-y-2">
          <SidebarMenu>
            <SidebarMenuItem>
              <SidebarMenuButton asChild>
                <button className="flex items-center w-full">
                  <HelpCircle className="h-5 w-5" />
                  <span>Ajuda</span>
                </button>
              </SidebarMenuButton>
            </SidebarMenuItem>
            <SidebarMenuItem>
              <SidebarMenuButton asChild>
                <button 
                  className="flex items-center w-full text-destructive hover:text-destructive/90"
                  onClick={handleLogout}
                >
                  <LogOut className="h-5 w-5" />
                  <span>Sair</span>
                </button>
              </SidebarMenuButton>
            </SidebarMenuItem>
          </SidebarMenu>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
