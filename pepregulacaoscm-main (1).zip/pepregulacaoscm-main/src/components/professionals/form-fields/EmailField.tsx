
import React from 'react';
import { useFormContext } from 'react-hook-form';
import { FormField, FormItem, FormLabel, FormControl, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';

interface EmailFieldProps {
  name?: string;
}

export const EmailField: React.FC<EmailFieldProps> = ({ name = "email" }) => {
  const form = useFormContext();
  
  return (
    <FormField
      control={form.control}
      name={name}
      render={({ field }) => (
        <FormItem>
          <FormLabel>Email</FormLabel>
          <FormControl>
            <Input {...field} placeholder="email@exemplo.com" type="email" />
          </FormControl>
          <FormMessage />
        </FormItem>
      )}
    />
  );
};
