
import React from 'react';
import { useFormContext } from 'react-hook-form';
import { FormField, FormItem, FormLabel, FormControl, FormMessage } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { FormRoleType } from '../ProfessionalForm';

interface RoleSelectFieldProps {
  name?: string;
}

export const RoleSelectField: React.FC<RoleSelectFieldProps> = ({ name = "role" }) => {
  const form = useFormContext();
  
  return (
    <FormField
      control={form.control}
      name={name}
      render={({ field }) => (
        <FormItem>
          <FormLabel>Função</FormLabel>
          <Select 
            onValueChange={field.onChange} 
            defaultValue={field.value}
          >
            <FormControl>
              <SelectTrigger>
                <SelectValue placeholder="Selecione uma função" />
              </SelectTrigger>
            </FormControl>
            <SelectContent>
              <SelectItem value="doctor">Médico</SelectItem>
              <SelectItem value="nurse">Enfermeiro</SelectItem>
              <SelectItem value="receptionist">Recepcionista</SelectItem>
              <SelectItem value="operator">Operador</SelectItem>
              <SelectItem value="manager">Gerente</SelectItem>
              <SelectItem value="readonly">Somente leitura</SelectItem>
            </SelectContent>
          </Select>
          <FormMessage />
        </FormItem>
      )}
    />
  );
};
