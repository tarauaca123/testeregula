
import React from 'react';
import { Loader2, AlertCircle, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { UserRole } from '@/contexts/types/userTypes';

interface Professional {
  id: string;
  name: string;
  email: string;
  role: UserRole;
}

interface ProfessionalsTableProps {
  professionals: Professional[];
  loading: boolean;
  error: Error | null;
  canManage: boolean;
  onRemove: (id: string) => void;
  onError: () => void;
}

export const ProfessionalsTable: React.FC<ProfessionalsTableProps> = ({
  professionals,
  loading,
  error,
  canManage,
  onRemove,
  onError,
}) => {
  const navigate = useNavigate();

  const getRoleLabel = (role: UserRole) => {
    const roleMap: Record<string, string> = {
      admin: 'Administrador',
      manager: 'Gerente',
      doctor: 'Médico',
      nurse: 'Enfermeiro',
      receptionist: 'Recepcionista',
      operator: 'Operador',
      readonly: 'Somente leitura',
      regulator: 'Regulador',
    };
    return roleMap[role] || role;
  };

  if (loading) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-4 text-destructive">
        <Button variant="outline" onClick={onError}>
          <AlertCircle className="mr-2 h-4 w-4" />
          Ocorreu um erro. Clique para ver detalhes.
        </Button>
      </div>
    );
  }

  if (professionals.length === 0) {
    return (
      <div className="text-center py-4 text-muted-foreground">
        Nenhum profissional cadastrado nesta unidade.
      </div>
    );
  }

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Nome</TableHead>
          <TableHead>Email</TableHead>
          <TableHead>Função</TableHead>
          {canManage && <TableHead className="w-[100px]">Ações</TableHead>}
        </TableRow>
      </TableHeader>
      <TableBody>
        {professionals.map((professional) => (
          <TableRow key={professional.id}>
            <TableCell className="font-medium">{professional.name}</TableCell>
            <TableCell>{professional.email}</TableCell>
            <TableCell>{getRoleLabel(professional.role)}</TableCell>
            {canManage && (
              <TableCell>
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={() => onRemove(professional.id)}
                >
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </TableCell>
            )}
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
};
