
import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form } from '@/components/ui/form';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { EmailField } from './form-fields/EmailField';
import { NameField } from './form-fields/NameField';
import { RoleSelectField } from './form-fields/RoleSelectField';
import { FormActions } from './form-fields/FormActions';
import { FormErrorAlert } from './form-fields/FormErrorAlert';

const formRoles = ['doctor', 'nurse', 'receptionist', 'operator', 'readonly', 'manager'] as const;
export type FormRoleType = typeof formRoles[number];

export const professionalFormSchema = z.object({
  email: z.string().email('Email inválido'),
  name: z.string().min(2, 'Nome deve ter pelo menos 2 caracteres'),
  role: z.enum(formRoles)
});

export type ProfessionalFormValues = z.infer<typeof professionalFormSchema>;

interface ProfessionalFormProps {
  unitId: string;
  onSuccess: () => void;
  onCancel: () => void;
}

export const ProfessionalForm: React.FC<ProfessionalFormProps> = ({ unitId, onSuccess, onCancel }) => {
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const { toast } = useToast();

  const form = useForm<ProfessionalFormValues>({
    resolver: zodResolver(professionalFormSchema),
    defaultValues: {
      email: '',
      name: '',
      role: 'readonly',
    },
  });

  const onSubmit = async (values: ProfessionalFormValues) => {
    if (!unitId) return;
    
    try {
      setSubmitting(true);
      setErrorMessage(null);

      // First check if the profile already exists
      const { data: existingProfile, error: profileError } = await supabase
        .from('profiles')
        .select('id')
        .eq('email', values.email)
        .maybeSingle();

      if (profileError) throw profileError;

      if (existingProfile) {
        // If profile exists, update it
        const { error: updateError } = await supabase
          .from('profiles')
          .update({
            name: values.name,
            role: values.role,
            unit_id: unitId
          })
          .eq('id', existingProfile.id);

        if (updateError) throw updateError;
      } else {
        // If profile doesn't exist, we need to handle this differently
        setErrorMessage("O email não está associado a nenhuma conta existente. O usuário deve se cadastrar primeiro.");
        throw new Error("Usuário não encontrado. O profissional precisa ter uma conta registrada primeiro.");
      }

      toast({
        title: "Profissional atualizado",
        description: "O profissional foi adicionado à unidade com sucesso.",
      });

      form.reset();
      onSuccess();
    } catch (error: any) {
      console.error('Error adding professional:', error);
      toast({
        variant: "destructive",
        title: "Erro ao adicionar profissional",
        description: error.message || "Ocorreu um erro ao adicionar o profissional.",
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <>
      <FormErrorAlert message={errorMessage} />
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <EmailField />
            <NameField />
            <RoleSelectField />
          </div>
          <FormActions 
            onCancel={onCancel}
            isSubmitting={submitting}
          />
        </form>
      </Form>
    </>
  );
};
