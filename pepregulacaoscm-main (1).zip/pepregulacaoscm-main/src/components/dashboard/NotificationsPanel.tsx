
import React, { useState, useEffect } from 'react';
import { Bell, ExternalLink } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { useNavigate } from 'react-router-dom';
import { RegulationRequest } from '@/types';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Info } from "lucide-react";
import { useToast } from '@/components/ui/use-toast';

interface NotificationsPanelProps {
  requests: RegulationRequest[];
  loading: boolean;
  title: string;
}

export const NotificationsPanel = ({ requests, loading, title }: NotificationsPanelProps) => {
  const navigate = useNavigate();
  const { toast } = useToast();

  // Get viewed notification IDs from localStorage
  const [viewedNotifications, setViewedNotifications] = useState<string[]>(() => {
    const saved = localStorage.getItem('viewedNotifications');
    return saved ? JSON.parse(saved) : [];
  });

  // Save viewed notifications to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('viewedNotifications', JSON.stringify(viewedNotifications));
  }, [viewedNotifications]);

  // Check if a notification has been viewed
  const isNotificationViewed = (requestId: string): boolean => {
    return viewedNotifications.includes(requestId);
  };

  // Formatar a data para o formato pt-BR
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return format(date, "dd 'de' MMMM 'às' HH:mm", { locale: ptBR });
  };

  // Obter status para exibição
  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'pending': return 'Pendente';
      case 'approved': return 'Aprovada';
      case 'rejected': return 'Rejeitada';
      case 'processing': return 'Em Análise';
      default: return status;
    }
  };

  // Obter classe CSS para o status
  const getStatusClass = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'approved': return 'bg-green-100 text-green-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      case 'processing': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  // Function to translate request types to Portuguese
  const getRequestTypeInPortuguese = (type: string): string => {
    switch (type) {
      case 'consultation': return 'Consulta';
      case 'exam': return 'Exame';
      case 'surgery': return 'Cirurgia';
      case 'hospitalization': return 'Internação';
      default: return type;
    }
  };

  // Handle clicking on an individual request
  const handleRequestClick = (requestId: string) => {
    // Mark as viewed if not already viewed
    if (!viewedNotifications.includes(requestId)) {
      const newViewedNotifications = [...viewedNotifications, requestId];
      setViewedNotifications(newViewedNotifications);
      localStorage.setItem('viewedNotifications', JSON.stringify(newViewedNotifications));
      
      toast({
        description: "Notificação marcada como visualizada",
        duration: 3000,
      });
    }
    
    navigate(`/requests/${requestId}`);
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-lg font-medium">
          <div className="flex items-center space-x-2">
            <Bell className="h-5 w-5" />
            <span>{title}</span>
          </div>
        </CardTitle>
        <Button
          variant="ghost"
          size="sm"
          className="text-xs"
          onClick={() => navigate('/requests')}
        >
          Ver todas
        </Button>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="space-y-4">
            <Skeleton className="h-20 w-full" />
            <Skeleton className="h-20 w-full" />
            <Skeleton className="h-20 w-full" />
          </div>
        ) : requests.length === 0 ? (
          <Alert>
            <Info className="h-4 w-4" />
            <AlertTitle>Sem notificações</AlertTitle>
            <AlertDescription>
              Nenhuma notificação disponível no momento.
            </AlertDescription>
          </Alert>
        ) : (
          <div className="space-y-4">
            {requests.map((request) => {
              const isViewed = isNotificationViewed(request.id);
              return (
                <div
                  key={request.id}
                  className={`flex flex-col space-y-2 p-3 border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer ${
                    !isViewed ? 'bg-blue-50 dark:bg-blue-900/20' : ''
                  }`}
                  onClick={() => handleRequestClick(request.id)}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-medium flex items-center">
                        Solicitação para {request.patient.name}
                        {!isViewed && (
                          <span className="ml-2 inline-block w-2 h-2 bg-blue-500 rounded-full"></span>
                        )}
                      </h4>
                      <p className="text-sm text-muted-foreground">
                        {getRequestTypeInPortuguese(request.requestType)} - {request.specialty}
                      </p>
                    </div>
                    <Badge className={getStatusClass(request.status)}>
                      {getStatusLabel(request.status)}
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-muted-foreground">
                      {formatDate(request.updatedAt)}
                    </span>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 w-8 p-0"
                      onClick={(e) => {
                        e.stopPropagation();
                        navigate(`/requests/${request.id}`);
                      }}
                    >
                      <ExternalLink className="h-4 w-4" />
                      <span className="sr-only">Ver detalhes</span>
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
};
