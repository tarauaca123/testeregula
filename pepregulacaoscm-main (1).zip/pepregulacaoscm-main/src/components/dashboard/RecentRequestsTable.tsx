
import React from 'react';
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { RegulationRequest } from '@/types';
import { DashboardUtils } from '@/utils/dashboard-utils';

interface RecentRequestsTableProps {
  recentRequests: RegulationRequest[];
  requestsLoading: boolean;
  isFilteredByUnit?: boolean;
}

export const RecentRequestsTable: React.FC<RecentRequestsTableProps> = ({ 
  recentRequests, 
  requestsLoading,
  isFilteredByUnit = false
}) => {
  // Calculate priority data from requests
  const priorityChartData = React.useMemo(() => {
    const high = recentRequests.filter(r => r.priority === 'high').length;
    const medium = recentRequests.filter(r => r.priority === 'medium').length;
    const low = recentRequests.filter(r => r.priority === 'low').length;
    
    return [
      { name: 'Alta', value: high, color: '#D14343' },
      { name: 'Média', value: medium, color: '#FFB020' },
      { name: 'Baixa', value: low, color: '#14B8A6' }
    ];
  }, [recentRequests]);

  // Function to translate request types to Portuguese
  const getRequestTypeInPortuguese = (type: string): string => {
    switch (type) {
      case 'consultation': return 'Consulta';
      case 'exam': return 'Exame';
      case 'surgery': return 'Cirurgia';
      case 'hospitalization': return 'Internação';
      default: return type;
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <Card className="lg:col-span-2">
        <CardHeader>
          <CardTitle className="text-lg">Solicitações Recentes</CardTitle>
        </CardHeader>
        <CardContent>
          {requestsLoading ? (
            <Skeleton className="h-96 w-full" />
          ) : recentRequests.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-4 font-medium text-sm">ID</th>
                    <th className="text-left py-3 px-4 font-medium text-sm">Paciente</th>
                    <th className="text-left py-3 px-4 font-medium text-sm">Tipo</th>
                    <th className="text-left py-3 px-4 font-medium text-sm">Especialidade</th>
                    <th className="text-left py-3 px-4 font-medium text-sm">Status</th>
                    <th className="text-left py-3 px-4 font-medium text-sm">Prioridade</th>
                    <th className="text-right py-3 px-4 font-medium text-sm">Data</th>
                  </tr>
                </thead>
                <tbody>
                  {recentRequests.map((request) => (
                    <tr key={request.id} className="border-b hover:bg-muted/30">
                      <td className="py-3 px-4 text-sm">#{request.id.substring(0, 8)}</td>
                      <td className="py-3 px-4 text-sm font-medium">{request.patient.name}</td>
                      <td className="py-3 px-4 text-sm">{getRequestTypeInPortuguese(request.requestType)}</td>
                      <td className="py-3 px-4 text-sm">{request.specialty}</td>
                      <td className="py-3 px-4">
                        <span className={DashboardUtils.getStatusClass(request.status)}>
                          {request.status === 'pending' && 'Pendente'}
                          {request.status === 'approved' && 'Aprovada'}
                          {request.status === 'rejected' && 'Rejeitada'}
                          {request.status === 'processing' && 'Em Análise'}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <span className={DashboardUtils.getPriorityClass(request.priority)}>
                          {request.priority === 'low' && 'Baixa'}
                          {request.priority === 'medium' && 'Média'}
                          {request.priority === 'high' && 'Alta'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right text-sm text-muted-foreground">
                        {DashboardUtils.formatDate(request.updatedAt)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="h-40 flex items-center justify-center">
              <p className="text-muted-foreground">Não há solicitações recentes</p>
            </div>
          )}
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Solicitações por Prioridade</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            {requestsLoading ? (
              <Skeleton className="h-full w-full" />
            ) : recentRequests.length > 0 && priorityChartData.some(item => item.value > 0) ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={priorityChartData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => percent > 0 ? `${name}: ${(percent * 100).toFixed(0)}%` : ''}
                  >
                    {priorityChartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center">
                <p className="text-muted-foreground">Não há dados para exibir</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
