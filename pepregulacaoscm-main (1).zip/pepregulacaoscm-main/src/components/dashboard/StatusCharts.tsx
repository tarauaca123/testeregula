
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { DashboardStats } from '@/hooks/useDashboardStats';

interface StatusChartsProps {
  stats: DashboardStats | null;
  statsLoading: boolean;
}

export const StatusCharts: React.FC<StatusChartsProps> = ({ stats, statsLoading }) => {
  const statusChartData = !statsLoading && stats ? [
    { name: 'Pendentes', value: stats.requestsByStatus.pending, color: '#FFB020' },
    { name: 'Aprovadas', value: stats.requestsByStatus.approved, color: '#14B8A6' },
    { name: 'Rejeitadas', value: stats.requestsByStatus.rejected, color: '#D14343' },
    { name: 'Em Análise', value: stats.requestsByStatus.processing, color: '#2196F3' },
  ] : [];
  
  const typeChartData = !statsLoading && stats ? [
    { name: 'Consultas', value: stats.requestsByType.consultation },
    { name: 'Exames', value: stats.requestsByType.exam },
    { name: 'Cirurgias', value: stats.requestsByType.surgery },
    { name: 'Internações', value: stats.requestsByType.hospitalization },
  ] : [];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Solicitações por Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            {statsLoading ? (
              <Skeleton className="h-full w-full" />
            ) : stats && statusChartData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={statusChartData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => percent > 0 ? `${name}: ${(percent * 100).toFixed(0)}%` : ''}
                  >
                    {statusChartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center">
                <p className="text-muted-foreground">Não há dados para exibir</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Solicitações por Tipo</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            {statsLoading ? (
              <Skeleton className="h-full w-full" />
            ) : stats && typeChartData.some(item => item.value > 0) ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={typeChartData}
                  margin={{
                    top: 5,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="value" fill="#0077B6" />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center">
                <p className="text-muted-foreground">Não há dados para exibir</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
