
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { User } from '@/contexts/types/userTypes';

interface UnitInformationProps {
  currentUser: User | null;
}

export const UnitInformation: React.FC<UnitInformationProps> = ({ currentUser }) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Informações da Unidade</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <h3 className="text-sm font-medium text-muted-foreground mb-1">Nome da Unidade</h3>
            <p className="font-medium">{currentUser?.unit?.name || 'Unidade não definida'}</p>
          </div>
          <div>
            <h3 className="text-sm font-medium text-muted-foreground mb-1">Código</h3>
            <p className="font-medium">{currentUser?.unit?.code || 'N/A'}</p>
          </div>
          <div>
            <h3 className="text-sm font-medium text-muted-foreground mb-1">Tipo</h3>
            <p className="font-medium">{currentUser?.unit?.type || 'N/A'}</p>
          </div>
          <div className="md:col-span-2 lg:col-span-3">
            <h3 className="text-sm font-medium text-muted-foreground mb-1">Endereço</h3>
            <p className="font-medium">{currentUser?.unit?.address || 'Endereço não disponível'}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
