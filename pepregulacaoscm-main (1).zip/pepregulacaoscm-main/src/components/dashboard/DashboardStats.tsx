
import React from 'react';
import { Activity, Clock, AlertTriangle, CheckCircle } from 'lucide-react';
import { StatCard } from '@/components/dashboard/StatCard';
import { DashboardStats as Stats } from '@/hooks/useDashboardStats';

interface DashboardStatsProps {
  stats: Stats | null;
}

export const DashboardStats: React.FC<DashboardStatsProps> = ({ stats }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <StatCard 
        title="Total de Solicitações" 
        value={stats?.totalRequests || 0} 
        icon={Activity} 
        trend={{ value: 0, isPositive: true }}
      />
      <StatCard 
        title="Solicitações Pendentes" 
        value={stats?.pendingRequests || 0} 
        icon={Clock}
        color="warning"
      />
      <StatCard 
        title="Alta Prioridade" 
        value={stats?.highPriorityRequests || 0} 
        icon={AlertTriangle}
        color="destructive"
      />
      <StatCard 
        title="Solicitações Aprovadas" 
        value={stats?.approvedRequests || 0} 
        icon={CheckCircle}
        color="success"
      />
    </div>
  );
};
