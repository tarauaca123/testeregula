
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: number | string;
  description?: string;
  icon: LucideIcon;
  trend?: {
    value: number;
    isPositive: boolean;
  };
  color?: 'default' | 'primary' | 'secondary' | 'accent' | 'destructive' | 'warning' | 'success';
}

export const StatCard = ({
  title,
  value,
  description,
  icon: Icon,
  trend,
  color = 'default'
}: StatCardProps) => {
  const getColorClasses = () => {
    switch (color) {
      case 'primary':
        return 'bg-primary text-primary-foreground';
      case 'secondary':
        return 'bg-secondary text-secondary-foreground';
      case 'accent':
        return 'bg-accent text-accent-foreground';
      case 'destructive':
        return 'bg-destructive text-destructive-foreground';
      case 'warning':
        return 'bg-amber-500 text-white';
      case 'success':
        return 'bg-green-500 text-white';
      default:
        return 'bg-card text-card-foreground';
    }
  };

  const getIconColorClass = () => {
    if (color === 'default') {
      return 'bg-medical-light text-medical-primary';
    }
    return 'bg-background/10 text-current';
  };

  return (
    <Card className={`overflow-hidden ${color !== 'default' ? getColorClasses() : ''}`}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className={`text-sm ${color === 'default' ? 'text-muted-foreground' : 'text-current/70'}`}>
              {title}
            </p>
            <h3 className="text-2xl font-bold mt-1">{value}</h3>
            {description && (
              <p className={`text-xs mt-1 ${color === 'default' ? 'text-muted-foreground' : 'text-current/70'}`}>
                {description}
              </p>
            )}
            {trend && (
              <div className="flex items-center mt-2">
                <span 
                  className={`text-xs font-medium ${
                    trend.isPositive 
                      ? 'text-green-500' 
                      : 'text-red-500'
                  }`}
                >
                  {trend.isPositive ? '+' : '-'}{trend.value}%
                </span>
                <span className={`text-xs ml-1 ${color === 'default' ? 'text-muted-foreground' : 'text-current/70'}`}>
                  vs. último mês
                </span>
              </div>
            )}
          </div>
          <div className={`p-2 rounded-full ${getIconColorClass()}`}>
            <Icon className="h-6 w-6" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
