
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Download, Upload, MoreHorizontal } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface PatientActionsProps {
  canCreatePatient: boolean;
}

export const PatientActions: React.FC<PatientActionsProps> = ({
  canCreatePatient,
}) => {
  const navigate = useNavigate();
  
  return (
    <div className="flex gap-2">
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline">
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem className="flex gap-2">
            <Download className="h-4 w-4" />
            <span>Exportar</span>
          </DropdownMenuItem>
          <DropdownMenuItem className="flex gap-2">
            <Upload className="h-4 w-4" />
            <span>Importar</span>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
      
      {canCreatePatient && (
        <Button onClick={() => navigate('/patients/new')} className="flex gap-2">
          <Plus className="h-4 w-4" />
          <span>Novo Paciente</span>
        </Button>
      )}
    </div>
  );
};
