
import React from 'react';
import { Search, Filter } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface PatientFiltersProps {
  searchTerm: string;
  setSearchTerm: (value: string) => void;
  statusFilter: 'all' | 'active' | 'inactive';
  handleStatusFilterChange: (status: 'all' | 'active' | 'inactive') => void;
}

export const PatientFilters: React.FC<PatientFiltersProps> = ({
  searchTerm,
  setSearchTerm,
  statusFilter,
  handleStatusFilterChange,
}) => {
  return (
    <div className="flex-1 flex flex-col sm:flex-row gap-2">
      <div className="relative flex-1">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          type="search"
          placeholder="Buscar por nome, CPF ou CNS..."
          className="pl-9"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>
      
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" className="flex gap-2">
            <Filter className="h-4 w-4" />
            <span>Filtrar</span>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuLabel>Status</DropdownMenuLabel>
          <DropdownMenuItem 
            className={statusFilter === 'all' ? 'bg-muted' : ''}
            onClick={() => handleStatusFilterChange('all')}
          >
            Todos
          </DropdownMenuItem>
          <DropdownMenuItem 
            className={statusFilter === 'active' ? 'bg-muted' : ''}
            onClick={() => handleStatusFilterChange('active')}
          >
            Ativos
          </DropdownMenuItem>
          <DropdownMenuItem 
            className={statusFilter === 'inactive' ? 'bg-muted' : ''}
            onClick={() => handleStatusFilterChange('inactive')}
          >
            Inativos
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
};
