
import React from 'react';

interface PatientDetailFieldProps {
  label: string;
  value?: string | null;
}

export const PatientDetailField: React.FC<PatientDetailFieldProps> = ({ 
  label, 
  value 
}) => {
  if (!value) return null;
  
  return (
    <div>
      <h4 className="text-sm text-muted-foreground mb-1">{label}</h4>
      <p className="font-medium">{value}</p>
    </div>
  );
};
