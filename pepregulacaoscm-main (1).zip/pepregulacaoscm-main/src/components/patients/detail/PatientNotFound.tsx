
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';

export const PatientNotFound: React.FC = () => {
  const navigate = useNavigate();
  
  return (
    <div className="flex flex-col items-center justify-center py-10 space-y-4">
      <h2 className="text-xl font-semibold">Paciente não encontrado</h2>
      <p className="text-muted-foreground">O paciente solicitado não existe ou foi removido.</p>
      <Button onClick={() => navigate('/patients')}>
        Voltar para lista de pacientes
      </Button>
    </div>
  );
};
