
import React from 'react';
import { Patient } from '@/types';
import { PatientDetailField } from './PatientDetailField';
import { PatientDetailSection } from './PatientDetailSection';

interface PatientPersonalInfoProps {
  patient: Patient;
  formatCPF: (cpf: string) => string;
  loading?: boolean;
}

export const PatientPersonalInfo: React.FC<PatientPersonalInfoProps> = ({
  patient,
  formatCPF,
  loading = false
}) => {
  if (loading) {
    return <PatientDetailSection title="Dados Pessoais" loading />;
  }
  
  const genderMap = {
    'male': 'Masculino',
    'female': 'Feminino',
    'other': 'Outro'
  };
  
  return (
    <PatientDetailSection title="Dados Pessoais">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-y-6 gap-x-10">
        <PatientDetailField label="Nome Completo" value={patient.name} />
        <PatientDetailField label="CPF" value={formatCPF(patient.cpf)} />
        <PatientDetailField label="RG" value={patient.rg} />
        <PatientDetailField label="CNS" value={patient.cns} />
        <PatientDetailField 
          label="Data de Nascimento" 
          value={new Date(patient.birthDate).toLocaleDateString('pt-BR')} 
        />
        <PatientDetailField 
          label="Gênero" 
          value={genderMap[patient.gender] || patient.gender} 
        />
        <PatientDetailField label="Raça/Cor" value={patient.race} />
        <PatientDetailField label="Tipo Sanguíneo" value={patient.bloodType} />
        <PatientDetailField label="Nome da Mãe" value={patient.motherName} />
        <PatientDetailField label="Nome do Pai" value={patient.fatherName} />
      </div>
    </PatientDetailSection>
  );
};
