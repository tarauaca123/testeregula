
import React from 'react';
import { Patient } from '@/types';
import { PatientDetailField } from './PatientDetailField';
import { PatientDetailSection } from './PatientDetailSection';

interface PatientContactInfoProps {
  patient: Patient;
  loading?: boolean;
}

export const PatientContactInfo: React.FC<PatientContactInfoProps> = ({
  patient,
  loading = false
}) => {
  if (loading) {
    return <PatientDetailSection title="Contatos" loading />;
  }
  
  const contactTypeMap = {
    'phone': 'Telefone',
    'mobile': 'Celular',
    'email': 'Email'
  };
  
  return (
    <PatientDetailSection title="Contatos">
      {patient.contacts.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-y-6 gap-x-10">
          {patient.contacts.map((contact, index) => (
            <div key={index}>
              <h4 className="text-sm text-muted-foreground mb-1">
                {contactTypeMap[contact.type] || contact.type}
              </h4>
              <p className="font-medium">{contact.value}</p>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-muted-foreground">Nenhum contato cadastrado.</p>
      )}
    </PatientDetailSection>
  );
};
