
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Edit, UserX } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Patient } from '@/types';

interface PatientDetailHeaderProps {
  patient: Patient | null;
  loading: boolean;
  canEditPatient: boolean;
  canDeactivatePatient: boolean;
}

export const PatientDetailHeader: React.FC<PatientDetailHeaderProps> = ({
  patient,
  loading,
  canEditPatient,
  canDeactivatePatient
}) => {
  const navigate = useNavigate();
  
  if (loading) {
    return (
      <div className="flex justify-between items-center gap-4 mb-6">
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" disabled>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <Skeleton className="h-8 w-48" />
        </div>
        <div className="flex gap-2">
          <Skeleton className="h-10 w-24" />
          <Skeleton className="h-10 w-24" />
        </div>
      </div>
    );
  }
  
  if (!patient) return null;
  
  return (
    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
      <div className="flex items-center gap-2">
        <Button variant="outline" size="icon" onClick={() => navigate('/patients')}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-2xl font-bold">{patient.name}</h1>
        <Badge variant={patient.status === 'active' ? 'default' : 'destructive'}>
          {patient.status === 'active' ? 'Ativo' : 'Inativo'}
        </Badge>
      </div>
      
      <div className="flex gap-2 w-full sm:w-auto">
        {canEditPatient && (
          <Button 
            variant="outline" 
            className="flex gap-2" 
            onClick={() => navigate(`/patients/edit/${patient.id}`)}
          >
            <Edit className="h-4 w-4" />
            <span>Editar</span>
          </Button>
        )}
        
        {canDeactivatePatient && (
          <Button variant="destructive" className="flex gap-2">
            <UserX className="h-4 w-4" />
            <span>{patient.status === 'active' ? 'Desativar' : 'Ativar'}</span>
          </Button>
        )}
      </div>
    </div>
  );
};
