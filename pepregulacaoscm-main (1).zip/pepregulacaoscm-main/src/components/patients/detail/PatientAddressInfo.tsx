
import React from 'react';
import { Patient } from '@/types';
import { PatientDetailField } from './PatientDetailField';
import { PatientDetailSection } from './PatientDetailSection';

interface PatientAddressInfoProps {
  patient: Patient;
  loading?: boolean;
}

export const PatientAddressInfo: React.FC<PatientAddressInfoProps> = ({
  patient,
  loading = false
}) => {
  if (loading) {
    return <PatientDetailSection title="Endereço" loading />;
  }
  
  return (
    <PatientDetailSection title="Endereço">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-y-6 gap-x-10">
        <PatientDetailField label="Logradouro" value={patient.address.street} />
        <PatientDetailField label="Número" value={patient.address.number} />
        <PatientDetailField label="Complemento" value={patient.address.complement} />
        <PatientDetailField label="Bairro" value={patient.address.neighborhood} />
        <PatientDetailField label="Cidade" value={patient.address.city} />
        <PatientDetailField label="Estado" value={patient.address.state} />
        <PatientDetailField label="CEP" value={patient.address.zipCode} />
      </div>
    </PatientDetailSection>
  );
};
