
import React from 'react';
import { Patient } from '@/types';
import { PatientFormWrapper } from './form/PatientFormWrapper';

interface PatientFormProps {
  patient?: Patient | null;
  isNew?: boolean;
  userData?: {
    userId?: string;
  };
}

export const PatientForm: React.FC<PatientFormProps> = (props) => {
  return <PatientFormWrapper {...props} />;
};
