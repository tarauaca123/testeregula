
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import { supabase } from '@/integrations/supabase/client';
import { Patient } from '@/types';
import { useUser } from '@/contexts/UserContext';
import { toast } from '@/components/ui/use-toast';
import { PatientFormValues } from './types';

interface UsePatientSubmitProps {
  isNew: boolean;
  patient?: Patient | null;
  userData?: {
    userId?: string;
  };
}

export const usePatientSubmit = ({ isNew, patient, userData }: UsePatientSubmitProps) => {
  const navigate = useNavigate();
  const { currentUser } = useUser();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const onSubmit = async (data: PatientFormValues) => {
    try {
      setIsSubmitting(true);
      console.log("Current user:", currentUser);
      console.log("User data from props:", userData);
      
      const patientData = {
        name: data.name,
        cpf: data.cpf.replace(/\D/g, ''),
        rg: data.rg || null,
        cns: data.cns || null,
        gender: data.gender,
        birth_date: format(data.birthDate, 'yyyy-MM-dd'),
        race: data.race || null,
        blood_type: data.bloodType || null,
        mother_name: data.motherName || null,
        father_name: data.fatherName || null,
        street: data.address.street,
        number: data.address.number,
        complement: data.address.complement || null,
        neighborhood: data.address.neighborhood,
        city: data.address.city,
        state: data.address.state,
        zip_code: data.address.zipCode,
        contacts: data.contacts?.filter(contact => contact.value.trim() !== '') || [],
        status: data.status,
        signature: data.signature || null,
        unit_id: currentUser?.unit?.id || null
      };
      
      // Use userData prop first, then fall back to currentUser from context
      const createdBy = userData?.userId || currentUser?.id;
      
      // Only add created_by if we have a valid UUID
      if (createdBy && typeof createdBy === 'string' && createdBy.length > 10) {
        Object.assign(patientData, { created_by: createdBy });
      }
      
      console.log("Patient data being sent:", patientData);
      
      let result;
      
      if (isNew) {
        result = await supabase
          .from('patients')
          .insert(patientData)
          .select('id')
          .single();
      } else if (patient) {
        result = await supabase
          .from('patients')
          .update({
            ...patientData,
            updated_at: new Date().toISOString()
          })
          .eq('id', patient.id)
          .select('id')
          .single();
      }
      
      if (result?.error) {
        console.error('Supabase error:', result.error);
        throw result.error;
      }
      
      toast({
        title: isNew ? "Paciente cadastrado com sucesso" : "Paciente atualizado com sucesso",
        description: data.name,
      });
      
      navigate(isNew && result?.data ? `/patients/${result.data.id}` : '/patients');
    } catch (error: any) {
      console.error('Error saving patient:', error);
      toast({
        variant: "destructive",
        title: "Erro ao salvar paciente",
        description: error.message || "Houve um problema ao salvar os dados."
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return {
    onSubmit,
    isSubmitting
  };
};
