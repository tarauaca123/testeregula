
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';

interface FormActionsProps {
  isSubmitting: boolean;
  isNew: boolean;
  onCancel?: () => void;
}

export const FormActions: React.FC<FormActionsProps> = ({ 
  isSubmitting, 
  isNew, 
  onCancel 
}) => {
  const navigate = useNavigate();
  
  const handleCancel = () => {
    if (onCancel) {
      onCancel();
    } else {
      navigate('/patients');
    }
  };
  
  return (
    <div className="flex justify-end gap-2">
      <Button 
        type="button" 
        variant="outline"
        onClick={handleCancel}
      >
        Cancelar
      </Button>
      <Button type="submit" disabled={isSubmitting}>
        {isSubmitting ? 'Salvando...' : isNew ? 'Cadastrar' : 'Salvar'}
      </Button>
    </div>
  );
};
