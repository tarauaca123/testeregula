
import { z } from 'zod';

export const patientFormSchema = z.object({
  name: z.string().min(3, { message: 'Nome deve ter pelo menos 3 caracteres' }),
  cpf: z.string()
    .min(11, { message: 'CPF inválido' })
    .max(14, { message: 'CPF inválido' })
    .refine(value => {
      if (value.includes('.') || value.includes('-')) return true;
      return value.length === 11;
    }, { message: 'CPF deve ter 11 dígitos' }),
  rg: z.string().optional(),
  cns: z.string().optional(),
  birthDate: z.date({ required_error: 'Data de nascimento é obrigatória' }),
  gender: z.enum(['male', 'female', 'other'], { 
    required_error: 'Selecione um gênero'
  }),
  race: z.string().optional(),
  bloodType: z.string().optional(),
  motherName: z.string().optional(),
  fatherName: z.string().optional(),
  address: z.object({
    street: z.string().min(3, { message: 'Informe o nome da rua' }),
    number: z.string().min(1, { message: 'Informe o número' }),
    complement: z.string().optional(),
    neighborhood: z.string().min(2, { message: 'Informe o bairro' }),
    city: z.string().min(2, { message: 'Informe a cidade' }),
    state: z.string().length(2, { message: 'Use a sigla do estado (ex: SP)' }),
    zipCode: z.string().min(8, { message: 'CEP inválido' })
  }),
  contacts: z.array(
    z.object({
      type: z.enum(['phone', 'mobile', 'email']),
      value: z.string().min(1, { message: 'Valor de contato não pode ser vazio' })
    })
  ).optional().default([]),
  status: z.enum(['active', 'inactive']).default('active'),
  signature: z.string().nullable().optional()
});

export type PatientFormValues = z.infer<typeof patientFormSchema>;
