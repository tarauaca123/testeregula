
import React from 'react';
import { useFormContext } from 'react-hook-form';
import { PatientFormValues } from './types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  FormField, 
  FormItem, 
  FormControl, 
  FormMessage 
} from '@/components/ui/form';
import { SignaturePad } from '../SignaturePad';

export const SignatureFormWrapper = () => {
  const { control } = useFormContext<PatientFormValues>();
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Assinatura</CardTitle>
      </CardHeader>
      <CardContent>
        <FormField
          control={control}
          name="signature"
          render={({ field }) => (
            <FormItem>
              <FormControl>
                <SignaturePad 
                  value={field.value || null}
                  onChange={(value) => field.onChange(value)}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      </CardContent>
    </Card>
  );
};
