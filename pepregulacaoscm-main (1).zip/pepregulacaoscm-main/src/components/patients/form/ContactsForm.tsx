
import React from 'react';
import { PlusCircle, TrashIcon } from 'lucide-react';
import { useFormContext, useWatch } from 'react-hook-form';
import { PatientFormValues } from './types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  FormField, 
  FormItem, 
  FormLabel, 
  FormControl, 
  FormMessage 
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';

export const ContactsForm = () => {
  const { control, setValue, getValues } = useFormContext<PatientFormValues>();
  const contacts = useWatch({ control, name: 'contacts' }) || [];
  
  const addContact = () => {
    const currentContacts = getValues('contacts') || [];
    setValue('contacts', [
      ...currentContacts,
      { type: 'phone', value: '' }
    ]);
  };
  
  const removeContact = (index: number) => {
    const currentContacts = getValues('contacts') || [];
    setValue('contacts', 
      currentContacts.filter((_, i) => i !== index)
    );
  };
  
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Contatos</CardTitle>
        <Button 
          type="button" 
          variant="outline" 
          size="sm"
          onClick={addContact}
        >
          <PlusCircle className="h-4 w-4 mr-2" />
          Adicionar Contato
        </Button>
      </CardHeader>
      <CardContent className="space-y-4">
        {contacts.map((_, index) => (
          <div key={index} className="flex items-end gap-2">
            <FormField
              control={control}
              name={`contacts.${index}.type`}
              render={({ field }) => (
                <FormItem className="flex-1">
                  <FormLabel>Tipo</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="phone">Telefone</SelectItem>
                      <SelectItem value="mobile">Celular</SelectItem>
                      <SelectItem value="email">Email</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={control}
              name={`contacts.${index}.value`}
              render={({ field }) => (
                <FormItem className="flex-[2]">
                  <FormLabel>Valor</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Button 
              type="button" 
              variant="outline" 
              size="icon"
              onClick={() => removeContact(index)}
              disabled={contacts.length <= 1}
            >
              <TrashIcon className="h-4 w-4" />
            </Button>
          </div>
        ))}
      </CardContent>
    </Card>
  );
};
