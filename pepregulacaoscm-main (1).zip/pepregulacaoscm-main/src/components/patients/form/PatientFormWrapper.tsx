
import React from 'react';
import { z } from 'zod';
import { useForm, FormProvider } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Patient } from '@/types';
import { Form } from '@/components/ui/form';
import { usePatientSubmit } from './usePatientSubmit';
import { patientFormSchema, PatientFormValues } from './types';
import { BasicInfoForm } from './BasicInfoForm';
import { AddressForm } from './AddressForm';
import { ContactsForm } from './ContactsForm';
import { SignatureFormWrapper } from './SignatureFormWrapper';
import { StatusForm } from './StatusForm';
import { FormActions } from './FormActions';

interface PatientFormWrapperProps {
  patient?: Patient | null;
  isNew?: boolean;
  userData?: {
    userId?: string;
  };
}

export const PatientFormWrapper: React.FC<PatientFormWrapperProps> = ({ 
  patient, 
  isNew = false,
  userData 
}) => {
  const form = useForm<PatientFormValues>({
    resolver: zodResolver(patientFormSchema),
    defaultValues: isNew 
      ? {
          name: '',
          cpf: '',
          gender: 'male',
          birthDate: new Date(),
          address: {
            street: '',
            number: '',
            neighborhood: '',
            city: '',
            state: '',
            zipCode: ''
          },
          contacts: [{ type: 'phone', value: '' }],
          status: 'active',
          signature: null
        }
      : patient
        ? {
            ...patient,
            birthDate: new Date(patient.birthDate),
            contacts: patient.contacts.length > 0 
              ? patient.contacts 
              : [{ type: 'phone', value: '' }],
            signature: patient.signature || null
          }
        : undefined
  });
  
  const { handleSubmit, formState, control } = form;
  const { isSubmitting } = formState;
  
  const { onSubmit } = usePatientSubmit({
    isNew,
    patient,
    userData
  });
  
  return (
    <FormProvider {...form}>
      <Form {...form}>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          <BasicInfoForm />
          <AddressForm />
          <ContactsForm />
          <SignatureFormWrapper />
          <StatusForm />
          <FormActions isSubmitting={isSubmitting} isNew={isNew} />
        </form>
      </Form>
    </FormProvider>
  );
};
