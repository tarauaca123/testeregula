
import React from 'react';
import { useFormContext } from 'react-hook-form';
import { PatientFormValues } from './types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  FormField, 
  FormItem, 
  FormLabel, 
  FormControl, 
  FormDescription 
} from '@/components/ui/form';
import { Checkbox } from '@/components/ui/checkbox';

export const StatusForm = () => {
  const { control } = useFormContext<PatientFormValues>();
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Status</CardTitle>
      </CardHeader>
      <CardContent>
        <FormField
          control={control}
          name="status"
          render={({ field }) => (
            <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
              <FormControl>
                <Checkbox
                  checked={field.value === 'active'}
                  onCheckedChange={(checked) => {
                    field.onChange(checked ? 'active' : 'inactive');
                  }}
                />
              </FormControl>
              <div className="space-y-1 leading-none">
                <FormLabel>
                  Ativo
                </FormLabel>
                <FormDescription>
                  Paciente está ativo e pode receber atendimento
                </FormDescription>
              </div>
            </FormItem>
          )}
        />
      </CardContent>
    </Card>
  );
};
