
import React, { useRef, useState, useEffect } from 'react';
import SignatureCanvas from 'react-signature-canvas';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Trash2, Edit, Save } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

interface SignaturePadProps {
  value: string | null;
  onChange: (signatureDataUrl: string | null) => void;
}

export const SignaturePad: React.FC<SignaturePadProps> = ({ value, onChange }) => {
  const sigCanvas = useRef<SignatureCanvas>(null);
  const [isEditing, setIsEditing] = useState<boolean>(!value);
  
  // Clear the signature pad
  const clear = () => {
    if (sigCanvas.current) {
      sigCanvas.current.clear();
    }
  };
  
  // Save the signature as a data URL
  const save = () => {
    if (sigCanvas.current) {
      if (sigCanvas.current.isEmpty()) {
        toast({
          title: "Assinatura vazia",
          description: "Por favor, assine antes de salvar.",
          variant: "destructive"
        });
        return;
      }
      
      const dataUrl = sigCanvas.current.toDataURL('image/png');
      onChange(dataUrl);
      setIsEditing(false);
      toast({
        title: "Assinatura salva",
        description: "A assinatura foi salva com sucesso."
      });
    }
  };
  
  // Delete the saved signature
  const deleteSignature = () => {
    onChange(null);
    setIsEditing(true);
    clear();
    toast({
      title: "Assinatura removida",
      description: "A assinatura foi removida com sucesso."
    });
  };
  
  // Edit the existing signature
  const editSignature = () => {
    setIsEditing(true);
  };
  
  // Reset the canvas when switching to edit mode
  useEffect(() => {
    if (isEditing && value && sigCanvas.current) {
      // Clear the canvas when entering edit mode
      clear();
    }
  }, [isEditing, value]);
  
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Assinatura do Paciente</CardTitle>
      </CardHeader>
      <CardContent>
        {isEditing ? (
          <div className="border rounded-md p-2 bg-white">
            <SignatureCanvas
              ref={sigCanvas}
              penColor="black"
              canvasProps={{
                width: 500,
                height: 200,
                className: 'w-full h-[200px] border border-gray-200 rounded-md'
              }}
            />
          </div>
        ) : (
          <div className="border rounded-md p-2 bg-white">
            {value && (
              <img 
                src={value} 
                alt="Assinatura do paciente" 
                className="w-full h-[200px] object-contain" 
              />
            )}
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between">
        {isEditing ? (
          <>
            <Button variant="outline" onClick={clear} type="button">
              <Trash2 className="h-4 w-4 mr-2" />
              Limpar
            </Button>
            <Button onClick={save} type="button">
              <Save className="h-4 w-4 mr-2" />
              Salvar Assinatura
            </Button>
          </>
        ) : (
          <>
            <Button variant="outline" onClick={deleteSignature} type="button">
              <Trash2 className="h-4 w-4 mr-2" />
              Excluir
            </Button>
            <Button onClick={editSignature} type="button">
              <Edit className="h-4 w-4 mr-2" />
              Editar
            </Button>
          </>
        )}
      </CardFooter>
    </Card>
  );
};
