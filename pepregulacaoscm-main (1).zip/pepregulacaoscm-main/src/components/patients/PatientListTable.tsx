
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { UserX, MoreHorizontal, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Patient } from '@/types';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useUser } from '@/contexts/UserContext';

interface PatientListTableProps {
  patients: Patient[];
  canEditPatient: boolean;
  canDeactivatePatient: boolean;
  formatCPF: (cpf: string) => string;
}

export const PatientListTable: React.FC<PatientListTableProps> = ({
  patients,
  canEditPatient,
  canDeactivatePatient,
  formatCPF,
}) => {
  const navigate = useNavigate();
  const { hasPermission } = useUser();
  
  // Determine if user can see all patients (admin/manager)
  const canSeeAllPatients = hasPermission(['admin', 'manager']);
  
  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Nome</TableHead>
            <TableHead>CPF</TableHead>
            <TableHead>CNS</TableHead>
            <TableHead>Data de Nascimento</TableHead>
            <TableHead>Status</TableHead>
            {canSeeAllPatients && <TableHead>Unidade</TableHead>}
            <TableHead className="text-right">Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {patients.length > 0 ? (
            patients.map((patient) => (
              <TableRow key={patient.id}>
                <TableCell>{patient.name}</TableCell>
                <TableCell>{formatCPF(patient.cpf)}</TableCell>
                <TableCell>{patient.cns || 'N/A'}</TableCell>
                <TableCell>
                  {new Date(patient.birthDate).toLocaleDateString('pt-BR')}
                </TableCell>
                <TableCell>
                  <span className={`px-2 py-1 text-xs rounded-full ${
                    patient.status === 'active' 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {patient.status === 'active' ? 'Ativo' : 'Inativo'}
                  </span>
                </TableCell>
                {canSeeAllPatients && (
                  <TableCell>
                    {patient.unitName || 'Não atribuído'}
                  </TableCell>
                )}
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => navigate(`/patients/${patient.id}`)}>
                        <Eye className="h-4 w-4 mr-2" />
                        Visualizar
                      </DropdownMenuItem>
                      {canEditPatient && (
                        <DropdownMenuItem onClick={() => navigate(`/patients/edit/${patient.id}`)}>
                          Editar
                        </DropdownMenuItem>
                      )}
                      {canDeactivatePatient && (
                        <>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-destructive flex items-center gap-2">
                            <UserX className="h-4 w-4" />
                            <span>{patient.status === 'active' ? 'Desativar' : 'Ativar'}</span>
                          </DropdownMenuItem>
                        </>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell colSpan={canSeeAllPatients ? 7 : 6} className="text-center py-6 text-muted-foreground">
                Nenhum paciente encontrado.
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
};
