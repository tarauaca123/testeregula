
import React from 'react';

interface RequestsStatusMessageProps {
  type: 'error' | 'empty';
}

export const RequestsStatusMessage: React.FC<RequestsStatusMessageProps> = ({ type }) => {
  return (
    <div className={`text-center py-4 ${type === 'error' ? 'text-destructive' : 'text-muted-foreground'}`}>
      {type === 'error' 
        ? 'Ocorreu um erro ao carregar as solicitações.' 
        : 'Nenhuma solicitação encontrada para esta unidade.'}
    </div>
  );
};
