
import React from 'react';
import { Badge } from '@/components/ui/badge';

interface PriorityBadgeProps {
  priority: 'low' | 'medium' | 'high';
}

export const PriorityBadge: React.FC<PriorityBadgeProps> = ({ priority }) => {
  const priorityMap = {
    low: { label: 'Baixa', variant: 'outline' as const },
    medium: { label: 'Média', variant: 'secondary' as const },
    high: { label: 'Alta', variant: 'destructive' as const },
  };

  const priorityInfo = priorityMap[priority];

  return <Badge variant={priorityInfo.variant}>{priorityInfo.label}</Badge>;
};
