
import React from 'react';
import { Badge } from '@/components/ui/badge';
import { FileCheck, FileX, Clock, CheckSquare, Building2 } from 'lucide-react';
import { RequestStatus } from '@/types';

interface StatusBadgeProps {
  status: RequestStatus;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status }) => {
  const statusMap = {
    pending: { label: 'Pendente', variant: 'default' as const },
    processing: { label: 'Em Análise', variant: 'secondary' as const },
    approved: { label: 'Aprovada', variant: 'success' as const },
    rejected: { label: 'Rejeitada', variant: 'destructive' as const },
    closed: { label: 'Regulação Fechada', variant: 'outline' as const },
    in_unit: { label: 'Paciente na Unidade', variant: 'secondary' as const },
  };

  const statusInfo = statusMap[status] || statusMap.pending;

  return (
    <Badge variant={statusInfo.variant}>
      {status === 'approved' ? <FileCheck className="mr-1 h-3 w-3" /> : 
       status === 'rejected' ? <FileX className="mr-1 h-3 w-3" /> : 
       status === 'closed' ? <CheckSquare className="mr-1 h-3 w-3" /> :
       status === 'in_unit' ? <Building2 className="mr-1 h-3 w-3" /> :
       <Clock className="mr-1 h-3 w-3" />}
      {statusInfo.label}
    </Badge>
  );
};
