
import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form } from '@/components/ui/form';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { FormErrorAlert } from '@/components/professionals/form-fields/FormErrorAlert';
import { EmailField } from '@/components/professionals/form-fields/EmailField';
import { NameField } from '@/components/professionals/form-fields/NameField';
import { RoleSelectField } from '@/components/professionals/form-fields/RoleSelectField';
import { UserRole } from '@/contexts/types/userTypes';
import { useSupabaseAuth } from '@/hooks/useSupabaseAuth';

const userFormSchema = z.object({
  email: z.string().email('Email inválido'),
  name: z.string().min(2, 'Nome deve ter pelo menos 2 caracteres'),
  role: z.string() as z.ZodType<UserRole>,
  password: z.string().min(6, 'Senha deve ter pelo menos 6 caracteres'),
});

export type UserFormValues = z.infer<typeof userFormSchema>;

interface UserFormProps {
  onSuccess: () => void;
  onCancel: () => void;
}

export const UserForm: React.FC<UserFormProps> = ({ onSuccess, onCancel }) => {
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const { toast } = useToast();
  const { session } = useSupabaseAuth();

  const form = useForm<UserFormValues>({
    resolver: zodResolver(userFormSchema),
    defaultValues: {
      email: '',
      name: '',
      role: 'readonly',
      password: '',
    },
  });

  const onSubmit = async (values: UserFormValues) => {
    try {
      setSubmitting(true);
      setErrorMessage(null);

      console.log("Submitting user form with values:", {
        email: values.email,
        name: values.name,
        role: values.role
      });

      // First check if the user already exists in profiles
      const { data: existingUser, error: userError } = await supabase
        .from('profiles')
        .select('id')
        .eq('email', values.email)
        .maybeSingle();

      if (userError) throw userError;

      if (existingUser) {
        setErrorMessage("Um usuário com este email já existe.");
        return;
      }
      
      // Call our edge function to create the user
      console.log("Calling create-user edge function...");
      const response = await fetch('https://emzjmycfeaoebnoqykwe.supabase.co/functions/v1/create-user', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session?.access_token}`,
        },
        body: JSON.stringify({
          email: values.email,
          password: values.password,
          name: values.name,
          role: values.role,
        }),
      });
      
      const result = await response.json();
      
      if (!response.ok || !result.success) {
        throw new Error(result.message || 'Erro ao criar usuário');
      }

      console.log("User created successfully, now sending welcome email...");
      // Send welcome email
      try {
        console.log("Calling send-welcome-email function...");
        const emailResponse = await fetch('https://emzjmycfeaoebnoqykwe.supabase.co/functions/v1/send-welcome-email', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            email: values.email,
            name: values.name,
            role: values.role,
          }),
        });
        
        const emailResult = await emailResponse.json();
        console.log("Email function response:", emailResult);
        
        if (!emailResponse.ok || !emailResult.success) {
          console.warn("Usuário criado, mas falha ao enviar e-mail de confirmação:", emailResult.message);
          toast({
            variant: "default",
            title: "Usuário cadastrado",
            description: "O usuário foi criado com sucesso, mas houve um problema ao enviar o e-mail de confirmação.",
          });
        } else {
          toast({
            title: "Usuário cadastrado",
            description: "O usuário foi criado com sucesso e um e-mail de confirmação foi enviado.",
          });
        }
      } catch (emailError) {
        console.error("Erro ao enviar e-mail de confirmação:", emailError);
        toast({
          title: "Usuário cadastrado",
          description: "O usuário foi criado com sucesso, mas houve um problema ao enviar o e-mail de confirmação.",
        });
      }

      form.reset();
      onSuccess();
    } catch (error: any) {
      console.error('Error creating user:', error);
      setErrorMessage(error.message || "Ocorreu um erro ao criar o usuário.");
      toast({
        variant: "destructive",
        title: "Erro ao criar usuário",
        description: error.message || "Ocorreu um erro ao criar o usuário.",
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <>
      <FormErrorAlert message={errorMessage} />
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid gap-4">
            <EmailField />
            <NameField />
            <RoleSelectField />
            <div className="space-y-2">
              <label htmlFor="password" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                Senha
              </label>
              <input
                id="password"
                type="password"
                {...form.register('password')}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              />
              {form.formState.errors.password && (
                <p className="text-sm font-medium text-destructive">{form.formState.errors.password.message}</p>
              )}
            </div>
          </div>
          <div className="flex justify-end space-x-2 pt-2">
            <Button 
              type="button" 
              variant="outline" 
              onClick={onCancel} 
              disabled={submitting}
            >
              Cancelar
            </Button>
            <Button type="submit" disabled={submitting}>
              {submitting ? 'Criando...' : 'Criar Usuário'}
            </Button>
          </div>
        </form>
      </Form>
    </>
  );
};
