
import React from 'react';
import { Download, Upload } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';

export const DataTabContent: React.FC = () => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Importar e Exportar Dados</CardTitle>
        <CardDescription>
          Ferramentas para importação e exportação de dados do sistema.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid gap-6">
          <div className="space-y-4">
            <h3 className="text-base font-medium">Exportar Dados</h3>
            <p className="text-sm text-muted-foreground">
              Exporte dados do sistema para backup ou análise externa.
            </p>
            
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <Button variant="outline" className="h-auto flex flex-col items-center justify-center gap-2 p-4">
                <Download className="h-5 w-5 text-medical-primary" />
                <span>Pacientes</span>
              </Button>
              
              <Button variant="outline" className="h-auto flex flex-col items-center justify-center gap-2 p-4">
                <Download className="h-5 w-5 text-medical-primary" />
                <span>Solicitações</span>
              </Button>
              
              <Button variant="outline" className="h-auto flex flex-col items-center justify-center gap-2 p-4">
                <Download className="h-5 w-5 text-medical-primary" />
                <span>Unidades</span>
              </Button>
              
              <Button variant="outline" className="h-auto flex flex-col items-center justify-center gap-2 p-4">
                <Download className="h-5 w-5 text-medical-primary" />
                <span>Usuários</span>
              </Button>
            </div>
            
            <Button className="flex items-center gap-2 mt-2">
              <Download className="h-4 w-4" />
              <span>Exportar Todos os Dados</span>
            </Button>
          </div>
          
          <Separator />
          
          <div className="space-y-4">
            <h3 className="text-base font-medium">Importar Dados</h3>
            <p className="text-sm text-muted-foreground">
              Importe dados de planilhas ou sistemas externos.
            </p>
            
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <Button variant="outline" className="h-auto flex flex-col items-center justify-center gap-2 p-4">
                <Upload className="h-5 w-5 text-medical-primary" />
                <span>Pacientes</span>
              </Button>
              
              <Button variant="outline" className="h-auto flex flex-col items-center justify-center gap-2 p-4">
                <Upload className="h-5 w-5 text-medical-primary" />
                <span>Solicitações</span>
              </Button>
              
              <Button variant="outline" className="h-auto flex flex-col items-center justify-center gap-2 p-4">
                <Upload className="h-5 w-5 text-medical-primary" />
                <span>Unidades</span>
              </Button>
              
              <Button variant="outline" className="h-auto flex flex-col items-center justify-center gap-2 p-4">
                <Upload className="h-5 w-5 text-medical-primary" />
                <span>Usuários</span>
              </Button>
            </div>
          </div>
          
          <Separator />
          
          <div className="space-y-4">
            <h3 className="text-base font-medium">Backup do Sistema</h3>
            <p className="text-sm text-muted-foreground">
              Gerencie backups completos do sistema.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button variant="default" className="flex items-center gap-2">
                <Download className="h-4 w-4" />
                <span>Criar Backup</span>
              </Button>
              
              <Button variant="outline" className="flex items-center gap-2">
                <Upload className="h-4 w-4" />
                <span>Restaurar Backup</span>
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
