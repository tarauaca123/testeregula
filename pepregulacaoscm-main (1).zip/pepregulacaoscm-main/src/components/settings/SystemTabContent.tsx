
import React from 'react';
import { Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';

export const SystemTabContent: React.FC = () => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Configurações do Sistema</CardTitle>
        <CardDescription>
          Gerencie as configurações gerais do sistema de regulação.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <h3 className="text-base font-medium">Configurações Gerais</h3>
          
          <div className="grid gap-4">
            <div className="grid grid-cols-2 items-center gap-4">
              <Label htmlFor="system-name">Nome do Sistema</Label>
              <Input id="system-name" defaultValue="Sistema de Regulação em Saúde" />
            </div>
            
            <div className="grid grid-cols-2 items-center gap-4">
              <Label htmlFor="organization">Organização</Label>
              <Input id="organization" defaultValue="Secretaria Municipal de Saúde" />
            </div>
          </div>
        </div>
        
        <Separator />
        
        <div className="space-y-4">
          <h3 className="text-base font-medium">Segurança</h3>
          
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="two-factor">Autenticação de Dois Fatores</Label>
              <Switch id="two-factor" />
            </div>
            
            <div className="flex items-center justify-between">
              <Label htmlFor="session-timeout">Tempo Limite da Sessão (minutos)</Label>
              <Input id="session-timeout" type="number" defaultValue="30" className="w-20" />
            </div>
            
            <div className="flex items-center justify-between">
              <Label htmlFor="password-policy">Política de Senha Forte</Label>
              <Switch id="password-policy" defaultChecked />
            </div>
          </div>
        </div>
        
        <Separator />
        
        <div className="space-y-4">
          <h3 className="text-base font-medium">Notificações</h3>
          
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="email-notifications">Notificações por Email</Label>
              <Switch id="email-notifications" defaultChecked />
            </div>
            
            <div className="flex items-center justify-between">
              <Label htmlFor="system-notifications">Notificações do Sistema</Label>
              <Switch id="system-notifications" defaultChecked />
            </div>
          </div>
        </div>
        
        <div className="flex justify-end">
          <Button className="flex items-center gap-2">
            <Save className="h-4 w-4" />
            <span>Salvar Configurações</span>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};
