
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { 
  Table,
  TableHeader,
  TableBody,
  TableHead,
  TableRow,
  TableCell
} from '@/components/ui/table';
import { supabase } from '@/integrations/supabase/client';
import { UserRole } from '@/contexts/types/userTypes';
import { Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface UserData {
  id: string;
  name: string | null;
  email: string | null;
  role: UserRole;
  unit?: { name: string } | null;
}

export const UsersTable: React.FC = () => {
  const [users, setUsers] = useState<UserData[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    async function fetchUsers() {
      try {
        setLoading(true);
        // Fetch profiles from the public.profiles table
        const { data: profiles, error } = await supabase
          .from('profiles')
          .select('id, name, email, role, unit_id');
          
        if (error) throw error;

        // Get units data for users with unit_id
        const usersWithUnitIds = profiles.filter(profile => profile.unit_id);
        let unitData = {};
        
        if (usersWithUnitIds.length > 0) {
          const { data: units } = await supabase
            .from('health_units')
            .select('id, name')
            .in('id', usersWithUnitIds.map(u => u.unit_id));
            
          if (units) {
            unitData = units.reduce((acc, unit) => {
              acc[unit.id] = unit;
              return acc;
            }, {});
          }
        }

        // Format data
        const formattedUsers = profiles.map(profile => ({
          id: profile.id,
          name: profile.name || 'Usuário sem nome',
          email: profile.email,
          role: profile.role as UserRole || 'readonly',
          unit: profile.unit_id ? unitData[profile.unit_id] : null
        }));

        setUsers(formattedUsers);
      } catch (error) {
        console.error('Error fetching users:', error);
        toast({
          variant: "destructive",
          title: "Erro ao carregar usuários",
          description: "Ocorreu um erro ao buscar a lista de usuários."
        });
      } finally {
        setLoading(false);
      }
    }

    fetchUsers();
  }, [toast]);

  const getRoleLabel = (role: UserRole) => {
    const roleMap: Record<string, string> = {
      admin: 'Administrador',
      manager: 'Gerente',
      doctor: 'Médico',
      nurse: 'Enfermeiro',
      receptionist: 'Recepcionista',
      operator: 'Operador',
      readonly: 'Somente leitura',
      regulator: 'Regulador',
    };
    return roleMap[role] || role;
  };

  if (loading) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Nome</TableHead>
            <TableHead>Email</TableHead>
            <TableHead>Função</TableHead>
            <TableHead>Unidade</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {users.length > 0 ? (
            users.map((user) => (
              <TableRow key={user.id}>
                <TableCell>{user.name}</TableCell>
                <TableCell>{user.email}</TableCell>
                <TableCell className="capitalize">{getRoleLabel(user.role)}</TableCell>
                <TableCell>{user.unit?.name || 'N/A'}</TableCell>
                <TableCell>
                  <span className="bg-green-100 text-green-800 px-2 py-0.5 rounded-full text-xs font-medium">
                    Ativo
                  </span>
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm">Editar</Button>
                </TableCell>
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell colSpan={6} className="text-center py-4 text-muted-foreground">
                Nenhum usuário encontrado
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
};
