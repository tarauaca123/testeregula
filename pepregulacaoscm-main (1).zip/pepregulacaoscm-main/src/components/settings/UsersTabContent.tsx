
import React, { useState } from 'react';
import { UserPlus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { UserForm } from '@/components/settings/UserForm';
import { UsersTable } from '@/components/settings/UsersTable';

export const UsersTabContent: React.FC = () => {
  const [isAddUserDialogOpen, setIsAddUserDialogOpen] = useState(false);
  
  return (
    <>
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-lg font-semibold">Gerenciamento de Usuários</h2>
          <Button 
            className="flex items-center gap-2"
            onClick={() => setIsAddUserDialogOpen(true)}
          >
            <UserPlus className="h-4 w-4" />
            <span>Novo Usuário</span>
          </Button>
        </div>
        
        <Card>
          <CardHeader className="py-4">
            <CardTitle className="text-base">Lista de Usuários</CardTitle>
            <CardDescription>Gerencie os usuários do sistema.</CardDescription>
          </CardHeader>
          <CardContent>
            <UsersTable />
          </CardContent>
        </Card>
        
        <Dialog open={isAddUserDialogOpen} onOpenChange={setIsAddUserDialogOpen}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Adicionar Novo Usuário</DialogTitle>
            </DialogHeader>
            <UserForm 
              onSuccess={() => setIsAddUserDialogOpen(false)} 
              onCancel={() => setIsAddUserDialogOpen(false)}
            />
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
};
