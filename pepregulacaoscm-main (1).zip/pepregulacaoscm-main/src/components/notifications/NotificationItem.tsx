
import React from 'react';
import { ExternalLink } from 'lucide-react';
import { Badge } from "@/components/ui/badge";
import { RegulationRequest } from '@/types';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface NotificationItemProps {
  request: RegulationRequest;
  isUnread: boolean;
  onClick: (requestId: string) => void;
}

export const NotificationItem: React.FC<NotificationItemProps> = ({ 
  request, 
  isUnread, 
  onClick 
}) => {
  // Format date to Portuguese locale
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return format(date, "dd 'de' MMMM 'às' HH:mm", { locale: ptBR });
  };

  // Get status label in Portuguese
  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'pending': return 'Pendente';
      case 'approved': return 'Aprovada';
      case 'rejected': return 'Rejeitada';
      case 'processing': return 'Em Análise';
      default: return status;
    }
  };

  // Get appropriate CSS class for status
  const getStatusClass = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'approved': return 'bg-green-100 text-green-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      case 'processing': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  // Get request type in Portuguese
  const getRequestTypeInPortuguese = (type: string): string => {
    switch (type) {
      case 'consultation': return 'Consulta';
      case 'exam': return 'Exame';
      case 'surgery': return 'Cirurgia';
      case 'hospitalization': return 'Internação';
      default: return type;
    }
  };

  return (
    <div 
      className={`p-2 hover:bg-muted/50 border-b cursor-pointer ${
        isUnread ? 'bg-blue-50 dark:bg-blue-900/20' : ''
      }`}
      onClick={() => onClick(request.id)}
    >
      <div className="flex justify-between items-start mb-1">
        <p className="text-sm font-medium">
          {request.patient.name}
          {isUnread && (
            <span className="ml-2 inline-block w-2 h-2 bg-blue-500 rounded-full"></span>
          )}
        </p>
        <Badge className={getStatusClass(request.status)}>
          {getStatusLabel(request.status)}
        </Badge>
      </div>
      <p className="text-xs text-muted-foreground">
        {getRequestTypeInPortuguese(request.requestType)}
        {' - '}
        {request.specialty}
      </p>
      <div className="flex justify-between items-center mt-1">
        <span className="text-xs text-muted-foreground">
          {formatDate(request.updatedAt)}
        </span>
        <ExternalLink className="h-3 w-3 text-muted-foreground" />
      </div>
    </div>
  );
};
