
import React from 'react';
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { Info } from 'lucide-react';
import { RegulationRequest } from '@/types';
import { NotificationItem } from './NotificationItem';

interface NotificationsListProps {
  requests: RegulationRequest[] | null;
  isLoading: boolean;
  viewedNotifications: string[];
  onNotificationClick: (requestId: string) => void;
}

export const NotificationsList: React.FC<NotificationsListProps> = ({
  requests,
  isLoading,
  viewedNotifications,
  onNotificationClick
}) => {
  if (isLoading) {
    return (
      <div className="p-4 space-y-2">
        <Skeleton className="h-14 w-full" />
        <Skeleton className="h-14 w-full" />
        <Skeleton className="h-14 w-full" />
      </div>
    );
  }

  if (!requests || requests.length === 0) {
    return (
      <div className="p-4">
        <Alert>
          <Info className="h-4 w-4" />
          <AlertTitle>Sem notificações</AlertTitle>
          <AlertDescription>
            Não há notificações disponíveis no momento.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <>
      {requests.map((request) => {
        const isUnread = !viewedNotifications.includes(request.id);
        
        return (
          <NotificationItem
            key={request.id}
            request={request}
            isUnread={isUnread}
            onClick={onNotificationClick}
          />
        );
      })}
    </>
  );
};
