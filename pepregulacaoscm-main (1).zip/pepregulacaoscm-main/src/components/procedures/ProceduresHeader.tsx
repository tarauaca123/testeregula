
import React from 'react';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useHealthUnits } from '@/hooks/useHealthUnits';

interface ProceduresHeaderProps {
  showUnitSelection: boolean;
  effectiveUnitId?: string;
  setSelectedUnitId: (unitId: string) => void;
  canAddProcedures: boolean;
  openCreateDialog: () => void;
  unitsLoading?: boolean;
  units: Array<{ id: string; name: string }>;
}

export const ProceduresHeader: React.FC<ProceduresHeaderProps> = ({
  showUnitSelection,
  effectiveUnitId,
  setSelectedUnitId,
  canAddProcedures,
  openCreateDialog,
  unitsLoading = false,
  units
}) => {
  return (
    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
      <h2 className="text-lg font-medium">Procedimentos</h2>
      
      <div className="flex flex-col md:flex-row items-start md:items-center gap-2">
        {showUnitSelection && (
          <Select 
            value={effectiveUnitId} 
            onValueChange={setSelectedUnitId}
            disabled={unitsLoading}
          >
            <SelectTrigger className="w-[250px]">
              <SelectValue placeholder="Selecione uma unidade" />
            </SelectTrigger>
            <SelectContent>
              {units.map(unit => (
                <SelectItem key={unit.id} value={unit.id}>
                  {unit.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
        
        {canAddProcedures && (
          <Button onClick={openCreateDialog}>
            <Plus className="h-4 w-4 mr-2" />
            Novo Procedimento
          </Button>
        )}
      </div>
    </div>
  );
};
