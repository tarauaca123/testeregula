
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { UnitProcedure } from '@/services/procedures';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { User } from '@/contexts/types/userTypes';
import { SingleProcedureForm } from './dialog/SingleProcedureForm';
import { MultipleProceduresForm } from './dialog/MultipleProceduresForm';
import { ImportProceduresForm } from './dialog/ImportProceduresForm';
import { parseImportText, getDefaultValues } from './dialog/utils';

interface ProcedureDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  procedure: UnitProcedure | null;
  unitId?: string;
  currentUser: User | null;
  onSubmit: (data: UnitProcedure | { id: string; updates: Partial<UnitProcedure> } | UnitProcedure[]) => void;
}

export const ProcedureDialog = ({
  open,
  onOpenChange,
  procedure,
  unitId,
  currentUser,
  onSubmit
}: ProcedureDialogProps) => {
  const isEditing = !!procedure;
  const [activeTab, setActiveTab] = useState<string>("single");
  const [multipleProcedures, setMultipleProcedures] = useState<Array<{
    name: string;
    description: string;
    price: string;
    type: 'exam' | 'surgery' | 'consultation';
  }>>([]);
  const [importText, setImportText] = useState<string>("");
  
  const defaultValues = getDefaultValues(procedure);
  
  // Reset form when dialog closes or procedure changes
  useEffect(() => {
    if (open) {
      setActiveTab(isEditing ? "single" : "single");
      setMultipleProcedures([]);
      setImportText("");
    }
  }, [open, procedure, isEditing]);
  
  const handleFormSubmit = (data: any) => {
    // No longer adding creator info as the column doesn't exist in the database
    if (activeTab === "single") {
      if (isEditing && procedure) {
        onSubmit({
          id: procedure.id,
          updates: {
            name: data.name,
            description: data.description || null,
            price: data.price ? Number(data.price) : null,
            type: data.type
          }
        });
      } else {
        console.log('Creating single procedure');
        onSubmit({
          unit_id: unitId || '',
          name: data.name,
          description: data.description || null,
          price: data.price ? Number(data.price) : null,
          type: data.type
        } as UnitProcedure);
      }
    } else if (activeTab === "multiple") {
      const procedures = multipleProcedures.map(proc => ({
        unit_id: unitId || '',
        name: proc.name,
        description: proc.description || null,
        price: proc.price ? Number(proc.price) : null,
        type: proc.type
      } as UnitProcedure));
      
      console.log('Creating multiple procedures:', procedures);
      onSubmit(procedures);
    } else if (activeTab === "import") {
      try {
        const procedures = parseImportText(importText).map(proc => ({
          unit_id: unitId || '',
          name: proc.name,
          description: proc.description || null,
          price: proc.price ? Number(proc.price) : null,
          type: proc.type || 'exam'
        } as UnitProcedure));
        
        console.log('Creating imported procedures:', procedures);
        onSubmit(procedures);
      } catch (error) {
        console.error("Error parsing import text:", error);
      }
    }
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle>{isEditing ? 'Editar Procedimento' : 'Novo Procedimento'}</DialogTitle>
          {currentUser && (
            <div className="text-sm text-muted-foreground">
              Operador: {currentUser.name}
            </div>
          )}
        </DialogHeader>
        
        {!isEditing && (
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-3 mb-4">
              <TabsTrigger value="single">Procedimento Único</TabsTrigger>
              <TabsTrigger value="multiple">Múltiplos Procedimentos</TabsTrigger>
              <TabsTrigger value="import">Importar</TabsTrigger>
            </TabsList>
            
            <TabsContent value="single">
              <SingleProcedureForm 
                defaultValues={defaultValues}
                onSubmit={handleFormSubmit}
                isEditing={false}
              />
            </TabsContent>
            
            <TabsContent value="multiple">
              <MultipleProceduresForm
                procedures={multipleProcedures}
                onProceduresChange={setMultipleProcedures}
                onSubmit={handleFormSubmit}
              />
            </TabsContent>
            
            <TabsContent value="import">
              <ImportProceduresForm
                importText={importText}
                onTextChange={setImportText}
                onSubmit={handleFormSubmit}
              />
            </TabsContent>
            
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancelar
              </Button>
              <Button 
                type="button"
                onClick={() => handleFormSubmit(activeTab === "single" ? defaultValues : null)}
                disabled={
                  (activeTab === "multiple" && multipleProcedures.length === 0) ||
                  (activeTab === "import" && !importText.trim())
                }
              >
                Criar Procedimento
              </Button>
            </DialogFooter>
          </Tabs>
        )}
        
        {isEditing && (
          <>
            <SingleProcedureForm 
              defaultValues={defaultValues}
              onSubmit={handleFormSubmit}
              isEditing={true}
            />
            
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancelar
              </Button>
              <Button 
                type="button"
                onClick={() => handleFormSubmit(defaultValues)}
              >
                Salvar Alterações
              </Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
};
