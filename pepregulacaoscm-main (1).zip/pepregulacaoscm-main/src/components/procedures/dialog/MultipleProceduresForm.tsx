
import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Trash2 } from 'lucide-react';

interface ProcedureItem {
  name: string;
  description: string;
  price: string;
  type: 'exam' | 'surgery' | 'consultation';
}

interface MultipleProceduresFormProps {
  procedures: ProcedureItem[];
  onProceduresChange: (procedures: ProcedureItem[]) => void;
  onSubmit: (data: any) => void;
}

export const MultipleProceduresForm: React.FC<MultipleProceduresFormProps> = ({
  procedures,
  onProceduresChange,
  onSubmit
}) => {
  const addNewProcedure = () => {
    onProceduresChange([
      ...procedures,
      { name: '', description: '', price: '', type: 'exam' }
    ]);
  };

  const updateProcedure = (index: number, field: string, value: string) => {
    const updated = [...procedures];
    updated[index] = { ...updated[index], [field]: value };
    onProceduresChange(updated);
  };

  const removeProcedure = (index: number) => {
    onProceduresChange(procedures.filter((_, i) => i !== index));
  };

  return (
    <form onSubmit={(e) => {
      e.preventDefault();
      onSubmit(procedures);
    }} className="space-y-4">
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nome</TableHead>
              <TableHead>Tipo</TableHead>
              <TableHead>Valor (R$)</TableHead>
              <TableHead className="w-[100px]">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {procedures.map((proc, index) => (
              <TableRow key={index}>
                <TableCell>
                  <Input
                    value={proc.name}
                    onChange={(e) => updateProcedure(index, 'name', e.target.value)}
                    placeholder="Nome do procedimento"
                  />
                </TableCell>
                <TableCell>
                  <Select 
                    value={proc.type}
                    onValueChange={(value) => updateProcedure(
                      index, 
                      'type', 
                      value as 'exam' | 'surgery' | 'consultation'
                    )}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="exam">Exame</SelectItem>
                      <SelectItem value="surgery">Cirurgia</SelectItem>
                      <SelectItem value="consultation">Consulta</SelectItem>
                    </SelectContent>
                  </Select>
                </TableCell>
                <TableCell>
                  <Input
                    type="number"
                    step="0.01"
                    value={proc.price}
                    onChange={(e) => updateProcedure(index, 'price', e.target.value)}
                    placeholder="0.00"
                  />
                </TableCell>
                <TableCell>
                  <Button 
                    type="button" 
                    variant="ghost" 
                    size="icon" 
                    onClick={() => removeProcedure(index)}
                  >
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
      
      <Button
        type="button"
        variant="outline"
        onClick={addNewProcedure}
        className="w-full"
      >
        <Plus className="h-4 w-4 mr-2" /> Adicionar Procedimento
      </Button>

      <div className="pt-4 flex justify-end gap-2">
        {/* Form actions will be rendered by the parent component */}
      </div>
    </form>
  );
};
