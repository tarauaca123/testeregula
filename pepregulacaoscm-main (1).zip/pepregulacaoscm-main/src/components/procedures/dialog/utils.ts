
import { UnitProcedure } from '@/services/procedures';

export const parseImportText = (text: string): Array<{
  name: string;
  description?: string;
  price?: string;
  type?: 'exam' | 'surgery' | 'consultation';
}> => {
  // Try to parse as JSON first
  try {
    const parsed = JSON.parse(text);
    if (Array.isArray(parsed)) {
      return parsed;
    }
    return [parsed];
  } catch (e) {
    // If not JSON, try to parse as CSV-like format
    return text.split('\n')
      .filter(line => line.trim() !== '')
      .map(line => {
        const [name, description, price, type] = line.split(';').map(item => item.trim());
        return {
          name: name || '',
          description: description || null,
          price: price || null,
          type: (type as 'exam' | 'surgery' | 'consultation') || 'exam'
        };
      });
  }
};

export const getDefaultValues = (procedure: UnitProcedure | null) => {
  return {
    name: procedure?.name || '',
    description: procedure?.description || '',
    price: procedure?.price !== undefined && procedure?.price !== null 
      ? procedure.price.toString() 
      : '',
    type: procedure?.type || 'exam'
  };
};
