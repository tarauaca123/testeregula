
import React from 'react';
import { useForm } from 'react-hook-form';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { UnitProcedure } from '@/services/procedures';

interface SingleProcedureFormProps {
  defaultValues: {
    name: string;
    description: string;
    price: string;
    type: string;
  };
  onSubmit: (data: any) => void;
  isEditing: boolean;
}

export const SingleProcedureForm: React.FC<SingleProcedureFormProps> = ({
  defaultValues,
  onSubmit,
  isEditing
}) => {
  const { register, handleSubmit, formState: { errors } } = useForm({
    defaultValues
  });

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="name">Nome do Procedimento</Label>
        <Input
          id="name"
          {...register('name', { required: true })}
        />
        {errors.name && <p className="text-sm text-destructive">Nome é obrigatório</p>}
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="description">Descrição (Opcional)</Label>
        <Textarea
          id="description"
          {...register('description')}
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="price">Valor (R$)</Label>
        <Input
          id="price"
          type="number"
          step="0.01"
          {...register('price')}
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="type">Tipo</Label>
        <Select defaultValue={defaultValues.type} {...register('type', { required: true })}>
          <SelectTrigger>
            <SelectValue placeholder="Selecione o tipo" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="exam">Exame</SelectItem>
            <SelectItem value="surgery">Cirurgia</SelectItem>
            <SelectItem value="consultation">Consulta</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="pt-4 flex justify-end gap-2">
        {/* Form actions will be rendered by the parent component */}
      </div>
    </form>
  );
};
