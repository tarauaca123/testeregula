
import React from 'react';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

interface ImportProceduresFormProps {
  importText: string;
  onTextChange: (text: string) => void;
  onSubmit: (data: any) => void;
}

export const ImportProceduresForm: React.FC<ImportProceduresFormProps> = ({
  importText,
  onTextChange,
  onSubmit
}) => {
  return (
    <form onSubmit={(e) => {
      e.preventDefault();
      onSubmit(importText);
    }} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="import">
          Cole os dados no formato JSON ou CSV (nome;descrição;valor;tipo)
        </Label>
        <Textarea
          id="import"
          rows={10}
          value={importText}
          onChange={(e) => onTextChange(e.target.value)}
          placeholder={`Formato JSON:
[
  {"name": "Raio X", "description": "Raio X completo", "price": "150", "type": "exam"},
  {"name": "Consulta", "price": "200", "type": "consultation"}
]

OU formato CSV:
Raio X;Raio X completo;150;exam
Consulta;;200;consultation`}
          className="font-mono text-sm"
        />
      </div>

      <div className="pt-4 flex justify-end gap-2">
        {/* Form actions will be rendered by the parent component */}
      </div>
    </form>
  );
};
