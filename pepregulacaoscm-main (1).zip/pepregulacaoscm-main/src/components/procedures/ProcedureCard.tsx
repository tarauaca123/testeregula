
import React from 'react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Edit, Trash2 } from 'lucide-react';
import { UnitProcedure } from '@/services/procedures';

interface ProcedureCardProps {
  procedure: UnitProcedure;
  onEdit: (procedure: UnitProcedure) => void;
  onDelete: (id: string) => void;
  canManage: boolean;
}

export const ProcedureCard: React.FC<ProcedureCardProps> = ({
  procedure,
  onEdit,
  onDelete,
  canManage
}) => {
  const formatPrice = (price: number | null) => {
    if (price === null) return 'Sem preço definido';
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(price);
  };

  return (
    <Card className="transition-shadow hover:shadow-md">
      <CardHeader>
        <CardTitle className="text-lg">{procedure.name}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-muted-foreground mb-2">
          {procedure.description || "Sem descrição disponível"}
        </p>
        <p className="font-medium text-lg">{formatPrice(procedure.price)}</p>
        {procedure.created_by_name && (
          <p className="text-sm text-muted-foreground mt-2">
            Adicionado por: {procedure.created_by_name}
          </p>
        )}
      </CardContent>
      {canManage && (
        <CardFooter className="flex justify-end gap-2">
          <Button variant="outline" size="icon" onClick={() => onEdit(procedure)}>
            <Edit className="h-4 w-4" />
          </Button>
          <Button 
            variant="outline" 
            size="icon" 
            className="text-destructive hover:bg-destructive/10"
            onClick={() => onDelete(procedure.id)}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </CardFooter>
      )}
    </Card>
  );
};
