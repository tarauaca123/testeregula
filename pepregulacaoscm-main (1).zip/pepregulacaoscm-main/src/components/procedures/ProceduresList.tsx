
import React, { useState } from 'react';
import { UnitProcedure } from '@/services/procedures';
import { ProcedureDialog } from './ProcedureDialog';
import { useUnitProcedures } from '@/hooks/useUnitProcedures';
import { useUser } from '@/contexts/UserContext';
import { useHealthUnits } from '@/hooks/useHealthUnits';
import { ProceduresHeader } from './ProceduresHeader';
import { ProceduresTabs } from './ProceduresTabs';

interface ProceduresListProps {
  unitId?: string;
  canManage?: boolean;
  allowUnitChange?: boolean;
}

export const ProceduresList: React.FC<ProceduresListProps> = ({ 
  unitId: initialUnitId,
  canManage = false,
  allowUnitChange = false
}) => {
  const { currentUser, hasPermission } = useUser();
  const { units, loading: unitsLoading } = useHealthUnits();
  
  // Determine if user has admin rights to change units
  const isAdmin = hasPermission(['admin']);
  
  // For receptionist and manager roles, use their assigned unit if no unitId was provided
  const userUnitId = currentUser?.unit?.id;
  const defaultUnitId = initialUnitId || userUnitId;
  
  // State to track selected unit (for admins who can change it)
  const [selectedUnitId, setSelectedUnitId] = useState<string | undefined>(defaultUnitId);
  
  // The effective unit ID to use - either the selected one or the default
  const effectiveUnitId = selectedUnitId || defaultUnitId;
  
  const {
    exams,
    surgeries,
    consultations,
    isLoading,
    isDialogOpen,
    setIsDialogOpen,
    procedureToEdit,
    openCreateDialog,
    openEditDialog,
    handleDeleteProcedure,
    handleSubmit
  } = useUnitProcedures(effectiveUnitId);

  // Determine if user can add procedures (admin, manager, or receptionist)
  const canAddProcedures = hasPermission(['admin', 'manager', 'receptionist']);
  
  // Show unit selection for admins when allowUnitChange is true
  const showUnitSelection = isAdmin && allowUnitChange;
  
  // Determine if the user has enough permissions to view procedures
  const hasAccessToView = hasPermission(['admin', 'manager', 'receptionist', 'doctor']);
  
  if (!hasAccessToView || (!effectiveUnitId && !isAdmin)) {
    return (
      <div className="py-12 text-center">
        <p className="text-muted-foreground">Você não tem permissão para visualizar procedimentos ou nenhuma unidade foi selecionada.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <ProceduresHeader
        showUnitSelection={showUnitSelection}
        effectiveUnitId={effectiveUnitId}
        setSelectedUnitId={setSelectedUnitId}
        canAddProcedures={canAddProcedures}
        openCreateDialog={openCreateDialog}
        unitsLoading={unitsLoading}
        units={units}
      />

      <ProceduresTabs
        exams={exams}
        surgeries={surgeries}
        consultations={consultations}
        isLoading={isLoading}
        openEditDialog={openEditDialog}
        handleDeleteProcedure={handleDeleteProcedure}
        canManage={canManage}
      />

      <ProcedureDialog
        open={isDialogOpen}
        onOpenChange={setIsDialogOpen}
        procedure={procedureToEdit}
        unitId={effectiveUnitId}
        onSubmit={handleSubmit}
        currentUser={currentUser}
      />
    </div>
  );
};
