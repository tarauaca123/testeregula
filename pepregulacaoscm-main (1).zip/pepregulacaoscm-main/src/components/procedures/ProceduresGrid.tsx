
import React from 'react';
import { UnitProcedure } from '@/services/procedures';
import { ProcedureCard } from './ProcedureCard';
import { Skeleton } from '@/components/ui/skeleton';

interface ProceduresGridProps {
  procedures: UnitProcedure[];
  isLoading: boolean;
  onEdit: (procedure: UnitProcedure) => void;
  onDelete: (id: string) => void;
  canManage: boolean;
}

export const ProceduresGrid: React.FC<ProceduresGridProps> = ({
  procedures,
  isLoading,
  onEdit,
  onDelete,
  canManage
}) => {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <div key={i} className="space-y-2">
            <Skeleton className="h-32" />
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-4 w-1/2" />
          </div>
        ))}
      </div>
    );
  }

  if (procedures.length === 0) {
    return (
      <div className="py-12 text-center">
        <p className="text-muted-foreground">Nenhum procedimento encontrado.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {procedures.map((procedure) => (
        <ProcedureCard
          key={procedure.id}
          procedure={procedure}
          onEdit={onEdit}
          onDelete={onDelete}
          canManage={canManage}
        />
      ))}
    </div>
  );
};
