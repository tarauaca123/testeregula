
import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ProceduresGrid } from './ProceduresGrid';
import { UnitProcedure } from '@/services/procedures';

interface ProceduresTabsProps {
  exams: UnitProcedure[];
  surgeries: UnitProcedure[];
  consultations: UnitProcedure[];
  isLoading: boolean;
  openEditDialog: (procedure: UnitProcedure) => void;
  handleDeleteProcedure: (id: string) => void;
  canManage: boolean;
}

export const ProceduresTabs: React.FC<ProceduresTabsProps> = ({
  exams,
  surgeries,
  consultations,
  isLoading,
  openEditDialog,
  handleDeleteProcedure,
  canManage
}) => {
  return (
    <Tabs defaultValue="exams">
      <TabsList className="grid grid-cols-3 w-full max-w-md">
        <TabsTrigger value="exams">Exames</TabsTrigger>
        <TabsTrigger value="surgeries">Cirurgias</TabsTrigger>
        <TabsTrigger value="consultations">Consultas</TabsTrigger>
      </TabsList>
      
      <TabsContent value="exams" className="mt-4">
        <ProceduresGrid 
          procedures={exams} 
          isLoading={isLoading}
          onEdit={openEditDialog}
          onDelete={handleDeleteProcedure}
          canManage={canManage}
        />
      </TabsContent>
      
      <TabsContent value="surgeries" className="mt-4">
        <ProceduresGrid 
          procedures={surgeries} 
          isLoading={isLoading}
          onEdit={openEditDialog}
          onDelete={handleDeleteProcedure}
          canManage={canManage}
        />
      </TabsContent>
      
      <TabsContent value="consultations" className="mt-4">
        <ProceduresGrid 
          procedures={consultations} 
          isLoading={isLoading}
          onEdit={openEditDialog}
          onDelete={handleDeleteProcedure}
          canManage={canManage}
        />
      </TabsContent>
    </Tabs>
  );
};
