
import React from 'react';
import { RequestRecord } from '@/types';
import { RequestActionsMenu } from './RequestActionsMenu';
import { getStatusClass, getPriorityClass, getStatusText, getPriorityText, getRequestTypeText, formatDate } from '@/utils/requestUtils';

interface RequestTableRowProps {
  request: RequestRecord;
  canEvaluateRequest: boolean;
  canDeleteRequest: boolean;
  updateRequestStatus: (requestId: string, status: any) => Promise<void>;
  onDeleteClick: (requestId: string) => void;
}

export const RequestTableRow: React.FC<RequestTableRowProps> = ({ 
  request, 
  canEvaluateRequest, 
  canDeleteRequest, 
  updateRequestStatus,
  onDeleteClick
}) => {
  return (
    <tr className="border-b hover:bg-muted/30">
      <td className="py-3 px-4">#{request.id.substring(0, 8)}</td>
      <td className="py-3 px-4 font-medium">{request.patient?.name || 'N/A'}</td>
      <td className="py-3 px-4">{getRequestTypeText(request.request_type)}</td>
      <td className="py-3 px-4">{request.specialty}</td>
      <td className="py-3 px-4">
        <span className={getStatusClass(request.status as any)}>
          {getStatusText(request.status as any)}
        </span>
      </td>
      <td className="py-3 px-4">
        <span className={getPriorityClass(request.priority as any)}>
          {getPriorityText(request.priority as any)}
        </span>
      </td>
      <td className="py-3 px-4 text-sm text-muted-foreground">
        {formatDate(request.requested_at)}
      </td>
      <td className="py-3 px-4 text-right">
        <RequestActionsMenu 
          requestId={request.id}
          status={request.status}
          canEvaluateRequest={canEvaluateRequest}
          canDeleteRequest={canDeleteRequest}
          updateRequestStatus={updateRequestStatus}
          onDeleteClick={onDeleteClick}
        />
      </td>
    </tr>
  );
};
