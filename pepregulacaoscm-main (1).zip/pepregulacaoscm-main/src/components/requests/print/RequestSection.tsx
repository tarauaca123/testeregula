
import React from 'react';
import { 
  getRequestTypeText, 
  getPriorityText, 
  getStatusText, 
  getPriorityClass,
  getStatusClass,
  formatDateTime
} from '@/utils/printUtils';

interface RequestSectionProps {
  request: any;
}

export const RequestSection: React.FC<RequestSectionProps> = ({ request }) => {
  return (
    <div className="section">
      <h2 className="section-title">DADOS DA SOLICITAÇÃO</h2>
      <div className="field">
        <span className="field-label">Tipo de Solicitação:</span>
        <span className="field-value">{getRequestTypeText(request?.request_type || '')}</span>
      </div>
      <div className="field">
        <span className="field-label">Especialidade:</span>
        <span className="field-value">{request?.specialty}</span>
      </div>
      <div className="field">
        <span className="field-label">Prioridade:</span>
        <span className={`field-value ${request?.priority ? getPriorityClass(request.priority) : ''}`}>
          {getPriorityText(request?.priority || '')}
        </span>
      </div>
      <div className="field">
        <span className="field-label">Status:</span>
        <span className={`field-value ${request?.status ? getStatusClass(request.status) : ''}`}>
          {getStatusText(request?.status || '')}
        </span>
      </div>
      <div className="field">
        <span className="field-label">Código CID:</span>
        <span className="field-value">{request?.icd_code || '--'}</span>
      </div>
      <div className="field">
        <span className="field-label">Data e Hora da Solicitação:</span>
        <span className="field-value">{formatDateTime(request?.requested_at || '')}</span>
      </div>
      <div className="field">
        <span className="field-label">Solicitado por:</span>
        <span className="field-value">{request?.requestedBy?.name || '--'}</span>
      </div>
      {request?.suggestedUnit && (
        <div className="field">
          <span className="field-label">Unidade Sugerida:</span>
          <span className="field-value">{request?.suggestedUnit?.name || '--'}</span>
        </div>
      )}
    </div>
  );
};
