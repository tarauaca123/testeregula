
import React from 'react';
import { QRCodeSVG } from 'qrcode.react';

interface DocumentFooterProps {
  signature?: string | null;
  baseUrl: string;
}

export const DocumentFooter: React.FC<DocumentFooterProps> = ({ signature, baseUrl }) => {
  return (
    <div className="footer">
      <div>
        <div className="signature">
          {signature && (
            <img 
              src={signature}
              alt="Assinatura do Paciente"
              style={{ maxHeight: '60px', maxWidth: '100%', margin: '0 auto 5px' }}
            />
          )}
          <p>Assinatura do Paciente</p>
        </div>
      </div>
      
      <div className="qr-container">
        <QRCodeSVG 
          value={baseUrl} 
          size={80}
          level="H"
          bgColor="#ffffff"
          fgColor="#000000"
        />
        <p>Escaneie para visualizar</p>
      </div>
    </div>
  );
};
