
import React from 'react';

interface ClinicalSectionProps {
  clinicalReason: string | undefined;
  observations?: string | null;
}

export const ClinicalSection: React.FC<ClinicalSectionProps> = ({ clinicalReason, observations }) => {
  return (
    <>
      <div className="section">
        <h2 className="section-title">MOTIVO CLÍNICO</h2>
        <div className="text-content">
          {clinicalReason || '--'}
        </div>
      </div>
      
      {observations && (
        <div className="section">
          <h2 className="section-title">OBSERVAÇÕES</h2>
          <div className="text-content">
            {observations}
          </div>
        </div>
      )}
    </>
  );
};
