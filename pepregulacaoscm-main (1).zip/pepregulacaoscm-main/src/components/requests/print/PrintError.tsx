
import React from 'react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

interface PrintErrorProps {
  onRetry?: () => void;
}

export const PrintError: React.FC<PrintErrorProps> = ({ onRetry }) => {
  const navigate = useNavigate();
  
  return (
    <div className="p-6 text-center">
      <h2 className="text-xl text-red-600 font-medium">Erro ao carregar solicitação</h2>
      <p className="mt-2 text-gray-500">Não foi possível carregar os detalhes desta solicitação para impressão.</p>
      <div className="mt-4 flex gap-4 justify-center">
        <Button onClick={() => navigate(-1)}>Voltar</Button>
        {onRetry && <Button onClick={onRetry}>Tentar novamente</Button>}
      </div>
    </div>
  );
};
