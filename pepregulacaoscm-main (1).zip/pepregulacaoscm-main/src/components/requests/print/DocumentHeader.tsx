
import React from 'react';
import { Calendar, Clock } from 'lucide-react';
import { formatDate } from '@/utils/requestUtils';

interface DocumentHeaderProps {
  id: string | undefined;
}

export const DocumentHeader: React.FC<DocumentHeaderProps> = ({ id }) => {
  return (
    <div className="header">
      <h1>SOLICITAÇÃO DE REGULAÇÃO</h1>
      <div className="header-code">
        <div className="dots">
          <div className="dot"></div>
          <div className="dot"></div>
          <div className="dot"></div>
        </div>
        <span className="code-text">{id?.substring(0, 8).toUpperCase()}</span>
      </div>
      <div className="header-date">
        <div>
          <Calendar className="h-4 w-4" />
          <span>Data: {formatDate(new Date().toISOString())}</span>
        </div>
        <div>
          <Clock className="h-4 w-4" />
          <span>Hora: {new Date().toLocaleTimeString('pt-BR')}</span>
        </div>
      </div>
    </div>
  );
};
