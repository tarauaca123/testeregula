
import React from 'react';
import { ArrowLeft, Printer } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

interface PrintHeaderProps {
  handlePrint: () => void;
}

export const PrintHeader: React.FC<PrintHeaderProps> = ({ handlePrint }) => {
  const navigate = useNavigate();
  
  return (
    <div className="flex items-center justify-between no-print">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-2xl font-semibold">Impressão de Solicitação</h1>
      </div>
      <div>
        <Button 
          onClick={handlePrint} 
          className="gap-2"
        >
          <Printer className="h-4 w-4" />
          <span>Imprimir</span>
        </Button>
      </div>
    </div>
  );
};
