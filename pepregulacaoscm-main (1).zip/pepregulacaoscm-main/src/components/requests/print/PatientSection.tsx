
import React from 'react';
import { formatCPF, formatDate, getGenderText } from '@/utils/printUtils';

interface PatientSectionProps {
  patient: any;
  priorityClass: string;
}

export const PatientSection: React.FC<PatientSectionProps> = ({ patient, priorityClass }) => {
  return (
    <div className="section">
      <h2 className="section-title">DADOS DO PACIENTE</h2>
      <div className="field">
        <span className="field-label">Nome:</span>
        <span className={`field-value ${priorityClass}`}>
          {patient?.name}
        </span>
      </div>
      <div className="field">
        <span className="field-label">CPF:</span>
        <span className="field-value">{formatCPF(patient?.cpf || '')}</span>
      </div>
      <div className="field">
        <span className="field-label">Data de Nascimento:</span>
        <span className="field-value">{formatDate(patient?.birth_date || '')}</span>
      </div>
      <div className="field">
        <span className="field-label">Gênero:</span>
        <span className="field-value">{getGenderText(patient?.gender || '')}</span>
      </div>
    </div>
  );
};
