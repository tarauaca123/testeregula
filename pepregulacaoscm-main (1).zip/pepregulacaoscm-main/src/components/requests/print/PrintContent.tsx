
import React from 'react';
import { Skeleton } from '@/components/ui/skeleton';
import { DocumentHeader } from './DocumentHeader';
import { PatientSection } from './PatientSection';
import { RequestSection } from './RequestSection';
import { ClinicalSection } from './ClinicalSection';
import { DocumentFooter } from './DocumentFooter';
import { getPriorityClass } from '@/utils/printUtils';

interface PrintContentProps {
  isLoading: boolean;
  id: string | undefined;
  request: any;
  printContentRef: React.RefObject<HTMLDivElement>;
  baseUrl: string;
}

export const PrintContent: React.FC<PrintContentProps> = ({ 
  isLoading, 
  id, 
  request, 
  printContentRef,
  baseUrl
}) => {
  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-3/4" />
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-32 w-full" />
      </div>
    );
  }
  
  // Get priority class for patient name
  const priorityClass = request?.priority ? getPriorityClass(request.priority) : '';
  
  return (
    <div ref={printContentRef}>
      <DocumentHeader id={id} />
      
      <PatientSection 
        patient={request?.patient} 
        priorityClass={priorityClass}
      />
      
      <RequestSection request={request} />
      
      <ClinicalSection
        clinicalReason={request?.clinical_reason}
        observations={request?.observations}
      />
      
      <DocumentFooter
        signature={request?.patient?.signature}
        baseUrl={baseUrl}
      />
    </div>
  );
};
