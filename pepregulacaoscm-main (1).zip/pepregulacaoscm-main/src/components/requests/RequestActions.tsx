
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Printer, Download, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface RequestActionsProps {
  canCreateRequest: boolean;
}

export const RequestActions: React.FC<RequestActionsProps> = ({ canCreateRequest }) => {
  const navigate = useNavigate();
  
  return (
    <div className="flex gap-2">
      <Button variant="outline" className="flex gap-2">
        <Printer className="h-4 w-4" />
        <span className="hidden sm:inline">Imprimir</span>
      </Button>
      
      <Button variant="outline" className="flex gap-2">
        <Download className="h-4 w-4" />
        <span className="hidden sm:inline">Exportar</span>
      </Button>
      
      {canCreateRequest && (
        <Button onClick={() => navigate('/requests/new')} className="flex gap-2">
          <Plus className="h-4 w-4" />
          <span>Nova Solicitação</span>
        </Button>
      )}
    </div>
  );
};
