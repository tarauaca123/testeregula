
import React from 'react';
import { UnitProcedure } from '@/services/procedures';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';

interface ProcedureItemProps {
  procedure: UnitProcedure;
  isSelected: boolean;
  toggleProcedure: (id: string) => void;
  quantity: number;
  updateQuantity: (id: string, quantity: number) => void;
  notes: string;
  updateNotes: (id: string, notes: string) => void;
}

export const ProcedureItem: React.FC<ProcedureItemProps> = ({
  procedure,
  isSelected,
  toggleProcedure,
  quantity,
  updateQuantity,
  notes,
  updateNotes
}) => {
  const formatPrice = (price: number | null) => {
    if (price === null) return 'Sem preço';
    return new Intl.NumberFormat('pt-BR', { 
      style: 'currency', 
      currency: 'BRL' 
    }).format(price);
  };

  return (
    <div 
      className={`py-4 ${isSelected ? 'bg-muted/40' : ''}`}
    >
      <div className="flex items-start">
        <Checkbox
          id={`proc-${procedure.id}`}
          checked={isSelected}
          onCheckedChange={() => toggleProcedure(procedure.id)}
          className="mt-1"
        />
        <div className="ml-3 flex-grow">
          <Label
            htmlFor={`proc-${procedure.id}`}
            className="font-medium cursor-pointer"
          >
            {procedure.name}
          </Label>
          {procedure.description && (
            <p className="text-sm text-muted-foreground mt-1">
              {procedure.description}
            </p>
          )}
          <p className="font-medium mt-2">
            {formatPrice(procedure.price)}
          </p>
        </div>
      </div>

      {isSelected && (
        <div className="mt-3 ml-7 space-y-3">
          <div>
            <Label htmlFor={`qty-${procedure.id}`}>
              Quantidade:
            </Label>
            <Input
              id={`qty-${procedure.id}`}
              type="number"
              min="1"
              value={quantity}
              onChange={(e) =>
                updateQuantity(
                  procedure.id,
                  parseInt(e.target.value) || 1
                )
              }
              className="w-24 mt-1"
            />
          </div>
          <div>
            <Label htmlFor={`notes-${procedure.id}`}>
              Observações (opcional):
            </Label>
            <Textarea
              id={`notes-${procedure.id}`}
              placeholder="Adicione observações específicas..."
              value={notes}
              onChange={(e) =>
                updateNotes(procedure.id, e.target.value)
              }
              className="mt-1"
              rows={2}
            />
          </div>
        </div>
      )}
    </div>
  );
};
