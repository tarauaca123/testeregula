
import React from 'react';
import { UnitProcedure } from '@/services/procedures';
import { ProcedureItem } from './ProcedureItem';
import { SelectedProcedure } from '@/hooks/useProcedureSelection';

interface ProcedureTabContentProps {
  procedures: UnitProcedure[];
  loading: boolean;
  selectedProcedures: { [key: string]: SelectedProcedure };
  toggleProcedure: (id: string) => void;
  updateQuantity: (id: string, quantity: number) => void;
  updateNotes: (id: string, notes: string) => void;
}

export const ProcedureTabContent: React.FC<ProcedureTabContentProps> = ({
  procedures,
  loading,
  selectedProcedures,
  toggleProcedure,
  updateQuantity,
  updateNotes
}) => {
  if (loading) {
    return <div className="text-center py-8">Carregando procedimentos...</div>;
  }
  
  if (procedures.length === 0) {
    return <div className="text-center py-8">Nenhum procedimento encontrado</div>;
  }
  
  return (
    <div className="divide-y">
      {procedures.map((procedure) => {
        const isSelected = !!selectedProcedures[procedure.id];
        return (
          <ProcedureItem
            key={procedure.id}
            procedure={procedure}
            isSelected={isSelected}
            toggleProcedure={toggleProcedure}
            quantity={selectedProcedures[procedure.id]?.quantity || 1}
            updateQuantity={updateQuantity}
            notes={selectedProcedures[procedure.id]?.notes || ''}
            updateNotes={updateNotes}
          />
        );
      })}
    </div>
  );
};
