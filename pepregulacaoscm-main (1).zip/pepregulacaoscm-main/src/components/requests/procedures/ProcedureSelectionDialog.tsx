
import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useUser } from '@/contexts/UserContext';
import { useProcedureSelection } from '@/hooks/useProcedureSelection';
import { ProcedureTabContent } from './ProcedureTabContent';

interface ProcedureSelectionDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onAddProcedures: (selectedProcedures: { procedureId: string; quantity: number; notes?: string }[]) => void;
  unitId?: string;
}

export const ProcedureSelectionDialog: React.FC<ProcedureSelectionDialogProps> = ({
  open,
  onOpenChange,
  onAddProcedures,
  unitId: suggestedUnitId,
}) => {
  const { currentUser } = useUser();
  
  // Use unit ID from props or from current user
  const unitId = suggestedUnitId || currentUser?.unit?.id;

  const {
    filteredProcedures,
    loading,
    selectedTab,
    setSelectedTab,
    searchTerm,
    setSearchTerm,
    selectedProcedures,
    toggleProcedure,
    updateQuantity,
    updateNotes,
    getSelectedProcedures
  } = useProcedureSelection({ open, unitId });

  const handleSubmit = () => {
    onAddProcedures(getSelectedProcedures());
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[80%] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Selecionar Procedimentos</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <Input
            placeholder="Buscar procedimentos..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />

          <Tabs value={selectedTab} onValueChange={setSelectedTab}>
            <TabsList className="grid grid-cols-3 w-full max-w-md">
              <TabsTrigger value="exams">Exames</TabsTrigger>
              <TabsTrigger value="surgeries">Cirurgias</TabsTrigger>
              <TabsTrigger value="consultations">Consultas</TabsTrigger>
            </TabsList>

            {['exams', 'surgeries', 'consultations'].map((tab) => (
              <TabsContent key={tab} value={tab} className="mt-4">
                <ProcedureTabContent
                  procedures={filteredProcedures}
                  loading={loading}
                  selectedProcedures={selectedProcedures}
                  toggleProcedure={toggleProcedure}
                  updateQuantity={updateQuantity}
                  updateNotes={updateNotes}
                />
              </TabsContent>
            ))}
          </Tabs>
        </div>

        <DialogFooter className="mt-6">
          <Button
            type="button"
            variant="outline"
            onClick={() => onOpenChange(false)}
          >
            Cancelar
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={Object.keys(selectedProcedures).length === 0}
          >
            Adicionar Selecionados
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
