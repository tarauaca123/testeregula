
import React from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Plus, Trash2 } from 'lucide-react';
import { useRequestProcedures } from '@/hooks/useRequestProcedures';
import { Skeleton } from '@/components/ui/skeleton';
import { ProcedureSelectionDialog } from './ProcedureSelectionDialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

interface RequestProceduresSectionProps {
  requestId?: string;
  readOnly?: boolean;
}

export const RequestProceduresSection: React.FC<RequestProceduresSectionProps> = ({
  requestId,
  readOnly = false
}) => {
  const {
    requestProcedures,
    isLoading,
    isDialogOpen,
    setIsDialogOpen,
    openAddDialog,
    handleAddProcedures,
    handleRemoveProcedure,
    totalPrice
  } = useRequestProcedures(requestId);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('pt-BR', { 
      style: 'currency', 
      currency: 'BRL' 
    }).format(price);
  };

  const getProcedureTypeLabel = (type: string) => {
    switch (type) {
      case 'exam': return 'Exame';
      case 'surgery': return 'Cirurgia';
      case 'consultation': return 'Consulta';
      default: return type;
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle><Skeleton className="h-6 w-36" /></CardTitle>
          <CardDescription><Skeleton className="h-4 w-48" /></CardDescription>
        </CardHeader>
        <CardContent>
          <Skeleton className="h-16" />
          <div className="flex justify-between mt-4">
            <Skeleton className="h-4 w-24" />
            <Skeleton className="h-4 w-24" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Procedimentos</CardTitle>
          <CardDescription>
            {requestProcedures.length === 0
              ? "Nenhum procedimento adicionado"
              : `${requestProcedures.length} procedimento(s) nesta solicitação`}
          </CardDescription>
        </div>
        {!readOnly && (
          <Button onClick={openAddDialog} size="sm">
            <Plus className="h-4 w-4 mr-1" />
            Adicionar
          </Button>
        )}
      </CardHeader>
      <CardContent>
        {requestProcedures.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <p>Nenhum procedimento adicionado a esta solicitação.</p>
            {!readOnly && (
              <Button 
                variant="outline" 
                className="mt-4" 
                onClick={openAddDialog}
              >
                <Plus className="h-4 w-4 mr-2" />
                Adicionar Procedimento
              </Button>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Procedimento</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Quantidade</TableHead>
                  <TableHead>Preço unitário</TableHead>
                  <TableHead>Total</TableHead>
                  {!readOnly && <TableHead className="w-[80px]">Ações</TableHead>}
                </TableRow>
              </TableHeader>
              <TableBody>
                {requestProcedures.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell className="font-medium">
                      {item.procedure?.name}
                      {item.notes && (
                        <div className="text-xs text-muted-foreground mt-1">
                          Obs: {item.notes}
                        </div>
                      )}
                    </TableCell>
                    <TableCell>{item.procedure?.type ? getProcedureTypeLabel(item.procedure.type) : '-'}</TableCell>
                    <TableCell>{item.quantity}</TableCell>
                    <TableCell>
                      {item.procedure?.price !== null 
                        ? formatPrice(item.procedure.price)
                        : 'N/A'}
                    </TableCell>
                    <TableCell className="font-medium">
                      {item.procedure?.price !== null 
                        ? formatPrice(item.procedure.price * item.quantity)
                        : 'N/A'}
                    </TableCell>
                    {!readOnly && (
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleRemoveProcedure(item.id)}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </TableCell>
                    )}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            
            <div className="flex justify-between items-center border-t pt-4">
              <div className="font-medium">Total</div>
              <div className="font-bold text-lg">
                {formatPrice(totalPrice)}
              </div>
            </div>
          </div>
        )}
      </CardContent>

      {!readOnly && (
        <ProcedureSelectionDialog
          open={isDialogOpen}
          onOpenChange={setIsDialogOpen}
          onAddProcedures={handleAddProcedures}
          unitId={requestProcedures[0]?.procedure?.unit_id}
        />
      )}
    </Card>
  );
};
