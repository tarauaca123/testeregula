
import * as z from 'zod';

// Form validation schema
export const requestFormSchema = z.object({
  patientId: z.string().min(1, 'O paciente é obrigatório'),
  requestType: z.enum(['consultation', 'exam', 'surgery', 'hospitalization'], {
    required_error: 'O tipo de solicitação é obrigatório',
  }),
  specialty: z.string().min(1, 'A especialidade é obrigatória'),
  priority: z.enum(['low', 'medium', 'high'], {
    required_error: 'A prioridade é obrigatória',
  }),
  icdCode: z.string().min(1, 'O código CID é obrigatório'),
  clinicalReason: z.string().min(5, 'O motivo clínico deve ter pelo menos 5 caracteres'),
  suggestedUnitId: z.string().optional(),
  observations: z.string().optional(),
});

export type RequestFormValues = z.infer<typeof requestFormSchema>;
