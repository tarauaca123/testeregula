
import React from 'react';
import {
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormMessage
} from '@/components/ui/form';
import { Textarea } from '@/components/ui/textarea';
import { Control } from 'react-hook-form';
import { RequestFormValues } from './RequestFormSchema';

interface ObservationsFieldProps {
  control: Control<RequestFormValues>;
}

export const ObservationsField: React.FC<ObservationsFieldProps> = ({ control }) => {
  return (
    <FormField
      control={control}
      name="observations"
      render={({ field }) => (
        <FormItem>
          <FormLabel>Observações (opcional)</FormLabel>
          <FormControl>
            <Textarea 
              {...field} 
              placeholder="Observações adicionais..." 
              rows={2}
            />
          </FormControl>
          <FormMessage />
        </FormItem>
      )}
    />
  );
};
