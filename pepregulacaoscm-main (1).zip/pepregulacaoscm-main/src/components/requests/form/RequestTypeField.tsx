
import React from 'react';
import {
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormMessage
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { Control } from 'react-hook-form';
import { RequestFormValues } from './RequestFormSchema';

interface RequestTypeFieldProps {
  control: Control<RequestFormValues>;
}

export const RequestTypeField: React.FC<RequestTypeFieldProps> = ({ control }) => {
  return (
    <FormField
      control={control}
      name="requestType"
      render={({ field }) => (
        <FormItem>
          <FormLabel>Tipo de Solicitação</FormLabel>
          <Select
            onValueChange={field.onChange}
            defaultValue={field.value}
          >
            <FormControl>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o tipo" />
              </SelectTrigger>
            </FormControl>
            <SelectContent>
              <SelectItem value="consultation">Consulta</SelectItem>
              <SelectItem value="exam">Exame</SelectItem>
              <SelectItem value="surgery">Cirurgia</SelectItem>
              <SelectItem value="hospitalization">Internação</SelectItem>
            </SelectContent>
          </Select>
          <FormMessage />
        </FormItem>
      )}
    />
  );
};
