
import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import {
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormMessage
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { Control } from 'react-hook-form';
import { RequestFormValues } from './RequestFormSchema';

// Fetch patients from Supabase
const fetchPatients = async () => {
  const { data, error } = await supabase
    .from('patients')
    .select('id, name, cpf')
    .eq('status', 'active')
    .order('name');

  if (error) throw error;
  return data || [];
};

interface PatientSelectFieldProps {
  control: Control<RequestFormValues>;
}

export const PatientSelectField: React.FC<PatientSelectFieldProps> = ({ control }) => {
  // Fetch patients
  const { data: patients = [], isLoading: patientsLoading } = useQuery({
    queryKey: ['patients'],
    queryFn: fetchPatients,
  });
  
  return (
    <FormField
      control={control}
      name="patientId"
      render={({ field }) => (
        <FormItem>
          <FormLabel>Paciente</FormLabel>
          <Select
            disabled={patientsLoading}
            onValueChange={field.onChange}
            defaultValue={field.value}
          >
            <FormControl>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o paciente" />
              </SelectTrigger>
            </FormControl>
            <SelectContent>
              {patients.map((patient) => (
                <SelectItem key={patient.id} value={patient.id}>
                  {patient.name} - CPF: {patient.cpf}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <FormMessage />
        </FormItem>
      )}
    />
  );
};
