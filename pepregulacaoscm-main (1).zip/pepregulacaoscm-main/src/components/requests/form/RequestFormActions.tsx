
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';

interface RequestFormActionsProps {
  isSubmitting: boolean;
}

export const RequestFormActions: React.FC<RequestFormActionsProps> = ({ 
  isSubmitting 
}) => {
  const navigate = useNavigate();
  
  return (
    <div className="flex justify-end gap-2">
      <Button 
        type="button" 
        variant="outline" 
        onClick={() => navigate('/requests')}
      >
        Cancelar
      </Button>
      <Button type="submit" disabled={isSubmitting}>
        {isSubmitting ? "Processando..." : "Criar Solicitação"}
      </Button>
    </div>
  );
};
