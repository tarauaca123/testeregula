
import React from 'react';
import {
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormMessage
} from '@/components/ui/form';
import { Textarea } from '@/components/ui/textarea';
import { Control } from 'react-hook-form';
import { RequestFormValues } from './RequestFormSchema';

interface ClinicalReasonFieldProps {
  control: Control<RequestFormValues>;
}

export const ClinicalReasonField: React.FC<ClinicalReasonFieldProps> = ({ control }) => {
  return (
    <FormField
      control={control}
      name="clinicalReason"
      render={({ field }) => (
        <FormItem>
          <FormLabel>Justificativa Clínica</FormLabel>
          <FormControl>
            <Textarea 
              {...field} 
              placeholder="Descreva o quadro clínico do paciente..." 
              rows={4}
            />
          </FormControl>
          <FormMessage />
        </FormItem>
      )}
    />
  );
};
