
import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import {
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormMessage
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { Control } from 'react-hook-form';
import { RequestFormValues } from './RequestFormSchema';

// Fetch health units from Supabase
const fetchHealthUnits = async () => {
  const { data, error } = await supabase
    .from('health_units')
    .select('id, name, type')
    .order('name');

  if (error) throw error;
  return data || [];
};

interface SuggestedUnitFieldProps {
  control: Control<RequestFormValues>;
}

export const SuggestedUnitField: React.FC<SuggestedUnitFieldProps> = ({ control }) => {
  // Fetch health units
  const { data: healthUnits = [], isLoading: unitsLoading } = useQuery({
    queryKey: ['healthUnits'],
    queryFn: fetchHealthUnits,
  });
  
  return (
    <FormField
      control={control}
      name="suggestedUnitId"
      render={({ field }) => (
        <FormItem>
          <FormLabel>Unidade Sugerida (opcional)</FormLabel>
          <Select
            disabled={unitsLoading}
            onValueChange={field.onChange}
            defaultValue={field.value}
          >
            <FormControl>
              <SelectTrigger>
                <SelectValue placeholder="Selecione a unidade (opcional)" />
              </SelectTrigger>
            </FormControl>
            <SelectContent>
              {healthUnits.map((unit) => (
                <SelectItem key={unit.id} value={unit.id}>
                  {unit.name} - {unit.type}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <FormMessage />
        </FormItem>
      )}
    />
  );
};
