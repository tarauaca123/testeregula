
import React from 'react';
import { Form } from '@/components/ui/form';
import { Card, CardContent } from '@/components/ui/card';
import { PatientSelectField } from './PatientSelectField';
import { RequestTypeField } from './RequestTypeField';
import { SpecialtyField } from './SpecialtyField';
import { PriorityField } from './PriorityField';
import { IcdCodeField } from './IcdCodeField';
import { ClinicalReasonField } from './ClinicalReasonField';
import { SuggestedUnitField } from './SuggestedUnitField';
import { ObservationsField } from './ObservationsField';
import { RequestFormActions } from './RequestFormActions';
import { useRequestForm } from '@/hooks/useRequestForm';

export const RequestForm = () => {
  const { form, onSubmit, isSubmitting } = useRequestForm();
  
  return (
    <Card>
      <CardContent className="pt-6">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <PatientSelectField control={form.control} />
            <RequestTypeField control={form.control} />
            <SpecialtyField control={form.control} />
            <PriorityField control={form.control} />
            <IcdCodeField control={form.control} />
            <ClinicalReasonField control={form.control} />
            <SuggestedUnitField control={form.control} />
            <ObservationsField control={form.control} />
            <RequestFormActions isSubmitting={isSubmitting} />
          </form>
        </Form>
      </CardContent>
    </Card>
  );
};
