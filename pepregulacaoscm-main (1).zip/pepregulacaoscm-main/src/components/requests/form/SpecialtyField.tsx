
import React from 'react';
import {
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormMessage
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Control } from 'react-hook-form';
import { RequestFormValues } from './RequestFormSchema';

interface SpecialtyFieldProps {
  control: Control<RequestFormValues>;
}

export const SpecialtyField: React.FC<SpecialtyFieldProps> = ({ control }) => {
  return (
    <FormField
      control={control}
      name="specialty"
      render={({ field }) => (
        <FormItem>
          <FormLabel>Especialidade</FormLabel>
          <FormControl>
            <Input {...field} placeholder="Ex: Cardiologia" />
          </FormControl>
          <FormMessage />
        </FormItem>
      )}
    />
  );
};
