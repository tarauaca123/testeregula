
import React from 'react';
import {
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormMessage
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Control } from 'react-hook-form';
import { RequestFormValues } from './RequestFormSchema';

interface IcdCodeFieldProps {
  control: Control<RequestFormValues>;
}

export const IcdCodeField: React.FC<IcdCodeFieldProps> = ({ control }) => {
  return (
    <FormField
      control={control}
      name="icdCode"
      render={({ field }) => (
        <FormItem>
          <FormLabel>Código CID</FormLabel>
          <FormControl>
            <Input {...field} placeholder="Ex: A00" />
          </FormControl>
          <FormMessage />
        </FormItem>
      )}
    />
  );
};
