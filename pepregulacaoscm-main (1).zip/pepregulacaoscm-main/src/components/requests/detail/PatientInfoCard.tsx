
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { formatDate } from '@/utils/requestUtils';

interface PatientInfoCardProps {
  isLoading: boolean;
  patient: any;
}

export const PatientInfoCard: React.FC<PatientInfoCardProps> = ({ isLoading, patient }) => {
  const navigate = useNavigate();

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle>Dados do Paciente</CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            <Skeleton className="h-5 w-3/4" />
            <Skeleton className="h-4 w-1/2" />
            <Skeleton className="h-4 w-2/3" />
          </div>
        ) : (
          <div className="space-y-4">
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Nome</h3>
              <p className="font-medium">{patient?.name || '--'}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">CPF</h3>
              <p>{patient?.cpf || '--'}</p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Gênero</h3>
                <p>{patient?.gender === 'male' ? 'Masculino' : 
                    patient?.gender === 'female' ? 'Feminino' : 
                    patient?.gender === 'other' ? 'Outro' : '--'}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Data de Nascimento</h3>
                <p>{patient?.birth_date ? formatDate(patient.birth_date) : '--'}</p>
              </div>
            </div>
            <div className="pt-2">
              <Button 
                variant="outline" 
                size="sm" 
                className="w-full"
                onClick={() => navigate(`/patients/${patient?.id}`)}
              >
                Ver perfil completo
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
