
import React from 'react';
import { Button } from '@/components/ui/button';

interface ErrorStateProps {
  onBack: () => void;
  onRetry: () => void;
}

export const ErrorState: React.FC<ErrorStateProps> = ({ onBack, onRetry }) => {
  return (
    <div className="p-6 text-center">
      <h2 className="text-xl text-red-600 font-medium">Erro ao carregar solicitação</h2>
      <p className="mt-2 text-gray-500">Não foi possível carregar os detalhes desta solicitação.</p>
      <div className="mt-4 flex gap-4 justify-center">
        <Button onClick={onBack}>Voltar</Button>
        <Button variant="outline" onClick={onRetry}>Tentar novamente</Button>
      </div>
    </div>
  );
};
