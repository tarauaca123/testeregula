
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Printer } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useIsMobile } from '@/hooks/use-mobile';

interface RequestDetailHeaderProps {
  id: string | undefined;
}

export const RequestDetailHeader: React.FC<RequestDetailHeaderProps> = ({ id }) => {
  const navigate = useNavigate();
  const isMobile = useIsMobile();

  return (
    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl sm:text-2xl font-semibold">Detalhes da Solicitação</h1>
      </div>
      <div className="w-full sm:w-auto">
        <Button 
          variant="outline" 
          className="gap-2 w-full sm:w-auto bg-white hover:bg-gray-100 border-medical-primary text-medical-primary hover:text-medical-dark transition-all" 
          onClick={() => navigate(`/requests/print/${id}`)}
        >
          <Printer className="h-4 w-4" />
          <span>{isMobile ? "Imprimir Solicitação" : "Imprimir"}</span>
        </Button>
      </div>
    </div>
  );
};
