
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { formatDate } from '@/utils/requestUtils';

interface RequestInfoCardProps {
  isLoading: boolean;
  requestedBy: any;
  requestedAt: string | undefined;
  evaluatedBy: any;
  evaluatedAt: string | undefined;
}

export const RequestInfoCard: React.FC<RequestInfoCardProps> = ({ 
  isLoading, 
  requestedBy, 
  requestedAt,
  evaluatedBy,
  evaluatedAt
}) => {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle>Dados da Solicitação</CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-3/4" />
          </div>
        ) : (
          <div className="space-y-4">
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Solicitado por</h3>
              <p>{requestedBy?.name || '--'}</p>
              <p className="text-sm text-muted-foreground">{requestedBy?.email || '--'}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Data da Solicitação</h3>
              <p>{requestedAt ? formatDate(requestedAt) : '--'}</p>
            </div>
            {evaluatedBy && (
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Avaliado por</h3>
                <p>{evaluatedBy?.name || '--'}</p>
                <p className="text-sm text-muted-foreground">{evaluatedBy?.email || '--'}</p>
              </div>
            )}
            {evaluatedAt && (
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Data da Avaliação</h3>
                <p>{formatDate(evaluatedAt)}</p>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};
