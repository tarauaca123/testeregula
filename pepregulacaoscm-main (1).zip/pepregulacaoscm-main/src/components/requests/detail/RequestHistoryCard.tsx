
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { formatDate } from '@/utils/requestUtils';
import { Json } from '@/integrations/supabase/types';
import { CircleDot, Clock } from 'lucide-react';

interface HistoryEntry {
  id: string;
  status: string;
  date: string;
  user: {
    id: string;
    name: string;
    email: string;
  };
}

interface RequestHistoryCardProps {
  isLoading: boolean;
  history: Json | null | undefined;
}

export const RequestHistoryCard: React.FC<RequestHistoryCardProps> = ({ 
  isLoading, 
  history 
}) => {
  // Safely convert history to proper array if it's not already
  // We need to ensure history is an array and each item has the required properties
  const historyEntries: HistoryEntry[] = React.useMemo(() => {
    // If history is not an array, return empty array
    if (!Array.isArray(history)) {
      return [];
    }
    
    // Try to convert history items to HistoryEntry objects
    return history.reduce((validEntries: HistoryEntry[], entry) => {
      // Skip non-object entries
      if (typeof entry !== 'object' || entry === null) {
        return validEntries;
      }
      
      // Check if entry has required properties with correct types
      const hasId = 'id' in entry && typeof entry.id === 'string';
      const hasStatus = 'status' in entry && typeof entry.status === 'string';
      const hasDate = 'date' in entry && typeof entry.date === 'string';
      
      const hasUser = 'user' in entry && 
                      typeof entry.user === 'object' && 
                      entry.user !== null && 
                      'id' in entry.user && 
                      'name' in entry.user && 
                      'email' in entry.user;
      
      // If all required properties exist, add to valid entries
      if (hasId && hasStatus && hasDate && hasUser) {
        validEntries.push({
          id: entry.id as string,
          status: entry.status as string,
          date: entry.date as string,
          user: {
            id: (entry.user as any).id as string,
            name: (entry.user as any).name as string,
            email: (entry.user as any).email as string
          }
        });
      }
      
      return validEntries;
    }, []);
  }, [history]);
  
  // Format full date and time
  const formatDateTime = (dateString: string) => {
    if (!dateString) return '--';
    
    return new Date(dateString).toLocaleString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  
  // Get status color
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'text-green-600';
      case 'rejected': return 'text-red-600';
      case 'processing': return 'text-blue-600';
      default: return 'text-amber-600';
    }
  };
  
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle>Histórico</CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            <Skeleton className="h-20 w-full" />
          </div>
        ) : historyEntries.length === 0 ? (
          <p className="text-center text-muted-foreground py-4">Nenhum histórico disponível</p>
        ) : (
          <div className="space-y-4">
            {historyEntries.map((entry: HistoryEntry) => (
              <div key={entry.id} className="border-b pb-4 last:border-0 last:pb-0">
                <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center">
                  <div className={`font-medium flex items-center gap-2 ${getStatusColor(entry.status)}`}>
                    <CircleDot className="h-4 w-4" />
                    {entry.status === 'approved' ? 'Aprovado' : 
                     entry.status === 'rejected' ? 'Rejeitado' : 
                     entry.status === 'processing' ? 'Em Análise' : 'Pendente'}
                  </div>
                  <div className="text-sm text-muted-foreground flex items-center">
                    <Clock className="mr-1 h-3 w-3" />
                    {entry.date ? formatDateTime(entry.date) : '--'}
                  </div>
                </div>
                {entry.user && (
                  <p className="text-sm mt-1 ml-6">
                    Por {entry.user.name || 'Usuário não identificado'}
                  </p>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};
