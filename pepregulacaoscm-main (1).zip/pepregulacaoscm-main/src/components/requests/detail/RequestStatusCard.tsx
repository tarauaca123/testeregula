
import React from 'react';
import { Clock, CheckCircle, XCircle, CheckSquare, Building2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import { useIsMobile } from '@/hooks/use-mobile';
import { RequestStatus } from '@/types';
import { 
  getStatusClass, 
  getStatusText, 
  getPriorityClass, 
  getPriorityText, 
  getRequestTypeText, 
  formatDate 
} from '@/utils/requestUtils';

interface RequestStatusCardProps {
  isLoading: boolean;
  request: any;
  canEvaluateRequest: boolean;
  updateRequestStatus: (status: RequestStatus) => void;
}

export const RequestStatusCard: React.FC<RequestStatusCardProps> = ({ 
  isLoading, 
  request, 
  canEvaluateRequest, 
  updateRequestStatus 
}) => {
  const isMobile = useIsMobile();
  
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle>Status da Solicitação</CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            <Skeleton className="h-8 w-32" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-3/4" />
          </div>
        ) : (
          <>
            <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4 mb-4">
              <div>
                <Badge className={getStatusClass(request?.status as RequestStatus)}>
                  {getStatusText(request?.status as RequestStatus)}
                </Badge>
                <p className="mt-2 text-sm text-muted-foreground">
                  Atualizado em {request?.updated_at ? formatDate(request.updated_at) : '--'}
                </p>
              </div>
              
              {canEvaluateRequest && (
                <div className={`flex ${isMobile ? 'flex-col w-full' : 'gap-2 flex-wrap'}`}>
                  <Button 
                    variant="outline" 
                    size={isMobile ? "default" : "sm"}
                    className={`${isMobile ? 'w-full mb-2' : ''} text-green-600 border-green-200 hover:bg-green-50 hover:text-green-700`}
                    onClick={() => updateRequestStatus('approved')}
                  >
                    <CheckCircle className="h-4 w-4 mr-1" />
                    Aprovar
                  </Button>
                  <Button 
                    variant="outline" 
                    size={isMobile ? "default" : "sm"}
                    className={`${isMobile ? 'w-full mb-2' : ''} text-amber-600 border-amber-200 hover:bg-amber-50 hover:text-amber-700`}
                    onClick={() => updateRequestStatus('processing')}
                  >
                    <Clock className="h-4 w-4 mr-1" />
                    Em Análise
                  </Button>
                  <Button 
                    variant="outline" 
                    size={isMobile ? "default" : "sm"}
                    className={`${isMobile ? 'w-full mb-2' : ''} text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700`}
                    onClick={() => updateRequestStatus('rejected')}
                  >
                    <XCircle className="h-4 w-4 mr-1" />
                    Rejeitar
                  </Button>
                  <Button 
                    variant="outline" 
                    size={isMobile ? "default" : "sm"}
                    className={`${isMobile ? 'w-full mb-2' : ''} text-gray-600 border-gray-200 hover:bg-gray-50 hover:text-gray-700`}
                    onClick={() => updateRequestStatus('closed')}
                  >
                    <CheckSquare className="h-4 w-4 mr-1" />
                    Regulação Fechada
                  </Button>
                  <Button 
                    variant="outline" 
                    size={isMobile ? "default" : "sm"}
                    className={`${isMobile ? 'w-full' : ''} text-blue-600 border-blue-200 hover:bg-blue-50 hover:text-blue-700`}
                    onClick={() => updateRequestStatus('in_unit')}
                  >
                    <Building2 className="h-4 w-4 mr-1" />
                    Paciente na Unidade
                  </Button>
                </div>
              )}
            </div>
            
            <Separator className="my-4" />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Tipo de Solicitação</h3>
                <p>{getRequestTypeText(request?.request_type || '')}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Especialidade</h3>
                <p>{request?.specialty || '--'}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Prioridade</h3>
                <p>
                  <span className={getPriorityClass(request?.priority as any)}>
                    {getPriorityText(request?.priority as any)}
                  </span>
                </p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Código CID</h3>
                <p>{request?.icd_code || '--'}</p>
              </div>
              <div className="md:col-span-2">
                <h3 className="text-sm font-medium text-muted-foreground">Motivo Clínico</h3>
                <p className="whitespace-pre-line">{request?.clinical_reason || '--'}</p>
              </div>
              {request?.observations && (
                <div className="md:col-span-2">
                  <h3 className="text-sm font-medium text-muted-foreground">Observações</h3>
                  <p className="whitespace-pre-line">{request.observations}</p>
                </div>
              )}
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
};
