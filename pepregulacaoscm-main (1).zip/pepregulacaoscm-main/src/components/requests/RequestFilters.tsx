
import React from 'react';
import { Search, Filter } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { RequestStatus, RequestPriority } from '@/types';

interface RequestFiltersProps {
  searchTerm: string;
  setSearchTerm: (value: string) => void;
  statusFilter: RequestStatus | 'all';
  handleStatusFilterChange: (status: RequestStatus | 'all') => void;
  priorityFilter: RequestPriority | 'all';
  handlePriorityFilterChange: (priority: RequestPriority | 'all') => void;
}

export const RequestFilters: React.FC<RequestFiltersProps> = ({
  searchTerm,
  setSearchTerm,
  statusFilter,
  handleStatusFilterChange,
  priorityFilter,
  handlePriorityFilterChange,
}) => {
  return (
    <div className="flex-1 flex flex-col sm:flex-row gap-2">
      <div className="relative flex-1">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          type="search"
          placeholder="Buscar por paciente, ID ou especialidade..."
          className="pl-9"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>
      
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" className="flex gap-2">
            <Filter className="h-4 w-4" />
            <span>Filtrar</span>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-56">
          <DropdownMenuLabel>Status</DropdownMenuLabel>
          <DropdownMenuItem 
            className={statusFilter === 'all' ? 'bg-muted' : ''}
            onClick={() => handleStatusFilterChange('all')}
          >
            Todos
          </DropdownMenuItem>
          <DropdownMenuItem 
            className={statusFilter === 'pending' ? 'bg-muted' : ''}
            onClick={() => handleStatusFilterChange('pending')}
          >
            Pendentes
          </DropdownMenuItem>
          <DropdownMenuItem 
            className={statusFilter === 'approved' ? 'bg-muted' : ''}
            onClick={() => handleStatusFilterChange('approved')}
          >
            Aprovadas
          </DropdownMenuItem>
          <DropdownMenuItem 
            className={statusFilter === 'rejected' ? 'bg-muted' : ''}
            onClick={() => handleStatusFilterChange('rejected')}
          >
            Rejeitadas
          </DropdownMenuItem>
          <DropdownMenuItem 
            className={statusFilter === 'processing' ? 'bg-muted' : ''}
            onClick={() => handleStatusFilterChange('processing')}
          >
            Em Análise
          </DropdownMenuItem>
          
          <DropdownMenuSeparator />
          
          <DropdownMenuLabel>Prioridade</DropdownMenuLabel>
          <DropdownMenuItem 
            className={priorityFilter === 'all' ? 'bg-muted' : ''}
            onClick={() => handlePriorityFilterChange('all')}
          >
            Todas
          </DropdownMenuItem>
          <DropdownMenuItem 
            className={priorityFilter === 'high' ? 'bg-muted' : ''}
            onClick={() => handlePriorityFilterChange('high')}
          >
            Alta
          </DropdownMenuItem>
          <DropdownMenuItem 
            className={priorityFilter === 'medium' ? 'bg-muted' : ''}
            onClick={() => handlePriorityFilterChange('medium')}
          >
            Média
          </DropdownMenuItem>
          <DropdownMenuItem 
            className={priorityFilter === 'low' ? 'bg-muted' : ''}
            onClick={() => handlePriorityFilterChange('low')}
          >
            Baixa
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
};
