
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  MoreHorizontal, 
  Trash2,
  CheckCircle,
  XCircle,
  Clock,
  Printer,
  CheckSquare,
  Building2
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { RequestStatus } from '@/types';

interface RequestActionsMenuProps {
  requestId: string;
  status: string;
  canEvaluateRequest: boolean;
  canDeleteRequest: boolean;
  updateRequestStatus: (requestId: string, status: RequestStatus) => Promise<void>;
  onDeleteClick: (requestId: string) => void;
}

export const RequestActionsMenu: React.FC<RequestActionsMenuProps> = ({
  requestId,
  status,
  canEvaluateRequest,
  canDeleteRequest,
  updateRequestStatus,
  onDeleteClick,
}) => {
  const navigate = useNavigate();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon">
          <MoreHorizontal className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuItem onClick={() => navigate(`/requests/${requestId}`)}>
          Visualizar
        </DropdownMenuItem>
        <DropdownMenuItem 
          className="flex items-center gap-2"
          onClick={() => navigate(`/requests/print/${requestId}`)}
        >
          <Printer className="h-4 w-4" />
          <span>Imprimir</span>
        </DropdownMenuItem>
        
        {canEvaluateRequest && (
          <>
            <DropdownMenuSeparator />
            <DropdownMenuLabel>Avaliação</DropdownMenuLabel>
            <DropdownMenuItem 
              className="flex items-center gap-2 text-green-600"
              onClick={() => updateRequestStatus(requestId, 'approved')}
            >
              <CheckCircle className="h-4 w-4" />
              <span>Aprovar</span>
            </DropdownMenuItem>
            <DropdownMenuItem 
              className="flex items-center gap-2 text-amber-600"
              onClick={() => updateRequestStatus(requestId, 'processing')}
            >
              <Clock className="h-4 w-4" />
              <span>Em Análise</span>
            </DropdownMenuItem>
            <DropdownMenuItem 
              className="flex items-center gap-2 text-red-600"
              onClick={() => updateRequestStatus(requestId, 'rejected')}
            >
              <XCircle className="h-4 w-4" />
              <span>Rejeitar</span>
            </DropdownMenuItem>
            <DropdownMenuItem 
              className="flex items-center gap-2 text-gray-600"
              onClick={() => updateRequestStatus(requestId, 'closed')}
            >
              <CheckSquare className="h-4 w-4" />
              <span>Regulação Fechada</span>
            </DropdownMenuItem>
            <DropdownMenuItem 
              className="flex items-center gap-2 text-blue-600"
              onClick={() => updateRequestStatus(requestId, 'in_unit')}
            >
              <Building2 className="h-4 w-4" />
              <span>Paciente na Unidade</span>
            </DropdownMenuItem>
          </>
        )}
        
        {canDeleteRequest && (
          <>
            <DropdownMenuSeparator />
            <DropdownMenuItem 
              className="text-destructive flex items-center gap-2"
              onClick={() => onDeleteClick(requestId)}
            >
              <Trash2 className="h-4 w-4" />
              <span>Excluir</span>
            </DropdownMenuItem>
          </>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};
