
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { RequestStatus, RequestRecord } from '@/types';
import { RequestTableRow } from './RequestTableRow';
import { RequestDeleteDialog } from './RequestDeleteDialog';
import { useToast } from '@/components/ui/use-toast';

interface RequestTableProps {
  filteredRequests: RequestRecord[];
  isLoading: boolean;
  updateRequestStatus: (requestId: string, status: RequestStatus) => Promise<void>;
  handleDeleteRequest: (requestId: string) => Promise<void>;
  canEvaluateRequest: boolean;
  canDeleteRequest: boolean;
}

export const RequestTable: React.FC<RequestTableProps> = ({
  filteredRequests,
  isLoading,
  updateRequestStatus,
  handleDeleteRequest,
  canEvaluateRequest,
  canDeleteRequest,
}) => {
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [requestToDelete, setRequestToDelete] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const { toast } = useToast();

  const openDeleteDialog = (requestId: string) => {
    setRequestToDelete(requestId);
    setIsDeleteDialogOpen(true);
  };

  const confirmDelete = async () => {
    if (!requestToDelete) return;
    
    try {
      setIsDeleting(true);
      await handleDeleteRequest(requestToDelete);
      
      toast({
        title: "Solicitação excluída",
        description: "A solicitação foi excluída com sucesso."
      });
    } catch (error) {
      console.error("Failed to delete request:", error);
      toast({
        variant: "destructive",
        title: "Erro ao excluir",
        description: "Não foi possível excluir a solicitação. Tente novamente mais tarde."
      });
    } finally {
      // Reset all state variables to prevent UI from freezing
      setIsDeleting(false);
      setRequestToDelete(null);
      setIsDeleteDialogOpen(false);
    }
  };

  return (
    <Card>
      <CardHeader className="py-4">
        <CardTitle className="text-lg">Lista de Solicitações</CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex justify-center p-6">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 px-4 font-medium text-sm">ID</th>
                  <th className="text-left py-3 px-4 font-medium text-sm">Paciente</th>
                  <th className="text-left py-3 px-4 font-medium text-sm">Tipo</th>
                  <th className="text-left py-3 px-4 font-medium text-sm">Especialidade</th>
                  <th className="text-left py-3 px-4 font-medium text-sm">Status</th>
                  <th className="text-left py-3 px-4 font-medium text-sm">Prioridade</th>
                  <th className="text-left py-3 px-4 font-medium text-sm">Data</th>
                  <th className="text-right py-3 px-4 font-medium text-sm">Ações</th>
                </tr>
              </thead>
              <tbody>
                {filteredRequests.length > 0 ? (
                  filteredRequests.map((request) => (
                    <RequestTableRow
                      key={request.id}
                      request={request}
                      canEvaluateRequest={canEvaluateRequest}
                      canDeleteRequest={canDeleteRequest}
                      updateRequestStatus={updateRequestStatus}
                      onDeleteClick={openDeleteDialog}
                    />
                  ))
                ) : (
                  <tr>
                    <td colSpan={8} className="py-6 text-center text-muted-foreground">
                      Nenhuma solicitação encontrada.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>

      <RequestDeleteDialog
        isOpen={isDeleteDialogOpen}
        isDeleting={isDeleting}
        onOpenChange={setIsDeleteDialogOpen}
        onConfirm={confirmDelete}
      />
    </Card>
  );
};
