export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      health_units: {
        Row: {
          address: string
          city: string
          code: string
          created_at: string
          created_by: string | null
          email: string | null
          id: string
          name: string
          phone: string | null
          state: string
          type: string
          updated_at: string
          zip_code: string
        }
        Insert: {
          address: string
          city: string
          code: string
          created_at?: string
          created_by?: string | null
          email?: string | null
          id?: string
          name: string
          phone?: string | null
          state: string
          type: string
          updated_at?: string
          zip_code: string
        }
        Update: {
          address?: string
          city?: string
          code?: string
          created_at?: string
          created_by?: string | null
          email?: string | null
          id?: string
          name?: string
          phone?: string | null
          state?: string
          type?: string
          updated_at?: string
          zip_code?: string
        }
        Relationships: []
      }
      patients: {
        Row: {
          birth_date: string
          blood_type: string | null
          city: string
          cns: string | null
          complement: string | null
          contacts: Json
          cpf: string
          created_at: string | null
          created_by: string | null
          father_name: string | null
          gender: string
          id: string
          mother_name: string | null
          name: string
          neighborhood: string
          number: string
          race: string | null
          rg: string | null
          signature: string | null
          state: string
          status: string
          street: string
          unit_id: string | null
          updated_at: string | null
          zip_code: string
        }
        Insert: {
          birth_date: string
          blood_type?: string | null
          city: string
          cns?: string | null
          complement?: string | null
          contacts?: Json
          cpf: string
          created_at?: string | null
          created_by?: string | null
          father_name?: string | null
          gender: string
          id?: string
          mother_name?: string | null
          name: string
          neighborhood: string
          number: string
          race?: string | null
          rg?: string | null
          signature?: string | null
          state: string
          status?: string
          street: string
          unit_id?: string | null
          updated_at?: string | null
          zip_code: string
        }
        Update: {
          birth_date?: string
          blood_type?: string | null
          city?: string
          cns?: string | null
          complement?: string | null
          contacts?: Json
          cpf?: string
          created_at?: string | null
          created_by?: string | null
          father_name?: string | null
          gender?: string
          id?: string
          mother_name?: string | null
          name?: string
          neighborhood?: string
          number?: string
          race?: string | null
          rg?: string | null
          signature?: string | null
          state?: string
          status?: string
          street?: string
          unit_id?: string | null
          updated_at?: string | null
          zip_code?: string
        }
        Relationships: [
          {
            foreignKeyName: "patients_unit_id_fkey"
            columns: ["unit_id"]
            isOneToOne: false
            referencedRelation: "health_units"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          created_at: string | null
          email: string | null
          id: string
          name: string | null
          role: string | null
          unit_id: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          email?: string | null
          id: string
          name?: string | null
          role?: string | null
          unit_id?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          email?: string | null
          id?: string
          name?: string | null
          role?: string | null
          unit_id?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "profiles_unit_id_fkey"
            columns: ["unit_id"]
            isOneToOne: false
            referencedRelation: "health_units"
            referencedColumns: ["id"]
          },
        ]
      }
      request_procedures: {
        Row: {
          created_at: string
          id: string
          notes: string | null
          procedure_id: string
          quantity: number
          request_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          notes?: string | null
          procedure_id: string
          quantity?: number
          request_id: string
        }
        Update: {
          created_at?: string
          id?: string
          notes?: string | null
          procedure_id?: string
          quantity?: number
          request_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "request_procedures_procedure_id_fkey"
            columns: ["procedure_id"]
            isOneToOne: false
            referencedRelation: "unit_procedures"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "request_procedures_request_id_fkey"
            columns: ["request_id"]
            isOneToOne: false
            referencedRelation: "requests"
            referencedColumns: ["id"]
          },
        ]
      }
      requests: {
        Row: {
          attachments: Json | null
          clinical_reason: string
          evaluated_at: string | null
          evaluated_by: string | null
          history: Json | null
          icd_code: string
          id: string
          observations: string | null
          patient_id: string
          priority: string
          request_type: string
          requested_at: string
          requested_by: string
          specialty: string
          status: string
          suggested_unit_id: string | null
          updated_at: string
        }
        Insert: {
          attachments?: Json | null
          clinical_reason: string
          evaluated_at?: string | null
          evaluated_by?: string | null
          history?: Json | null
          icd_code: string
          id?: string
          observations?: string | null
          patient_id: string
          priority: string
          request_type: string
          requested_at?: string
          requested_by: string
          specialty: string
          status?: string
          suggested_unit_id?: string | null
          updated_at?: string
        }
        Update: {
          attachments?: Json | null
          clinical_reason?: string
          evaluated_at?: string | null
          evaluated_by?: string | null
          history?: Json | null
          icd_code?: string
          id?: string
          observations?: string | null
          patient_id?: string
          priority?: string
          request_type?: string
          requested_at?: string
          requested_by?: string
          specialty?: string
          status?: string
          suggested_unit_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "requests_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "requests_suggested_unit_id_fkey"
            columns: ["suggested_unit_id"]
            isOneToOne: false
            referencedRelation: "health_units"
            referencedColumns: ["id"]
          },
        ]
      }
      unit_procedures: {
        Row: {
          created_at: string
          description: string | null
          id: string
          name: string
          price: number | null
          type: string
          unit_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          name: string
          price?: number | null
          type: string
          unit_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          price?: number | null
          type?: string
          unit_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "unit_procedures_unit_id_fkey"
            columns: ["unit_id"]
            isOneToOne: false
            referencedRelation: "health_units"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DefaultSchema = Database[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
