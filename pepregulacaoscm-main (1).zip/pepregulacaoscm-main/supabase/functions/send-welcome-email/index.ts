
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.38.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  console.log("🚀 send-welcome-email function started");
  
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    console.log("Handling CORS preflight request");
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const siteUrl = Deno.env.get("SITE_URL");

    console.log("Environment variables check:");
    console.log(`- SUPABASE_URL exists: ${!!supabaseUrl}`);
    console.log(`- SUPABASE_SERVICE_ROLE_KEY exists: ${!!supabaseServiceKey}`);
    console.log(`- SITE_URL exists: ${!!siteUrl}`);
    
    // Output masked versions of keys for debugging
    if (supabaseUrl) console.log(`- SUPABASE_URL: ${supabaseUrl.substring(0, 10)}...`);
    if (siteUrl) console.log(`- SITE_URL: ${siteUrl}`);

    if (!supabaseUrl || !supabaseServiceKey) {
      console.error("❌ Missing environment variables");
      throw new Error("Missing environment variables SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY");
    }

    // Initialize the Supabase client with the service role key
    const supabase = createClient(supabaseUrl, supabaseServiceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });

    // Get the request body
    let body;
    try {
      body = await req.json();
      console.log("Request body received:", JSON.stringify(body));
    } catch (jsonError) {
      console.error("❌ Failed to parse request JSON:", jsonError);
      throw new Error("Invalid JSON in request body");
    }
    
    // Extract data from request
    let { email, name, role } = body;
    
    // Check for test mode but don't override email
    const isTestMode = body.test === true;
    if (isTestMode) {
      console.log("⚠️ TEST MODE detected");
      name = name || "Test User";
      role = role || "admin";
    }

    if (!email || !name) {
      console.error("❌ Missing required fields");
      throw new Error("Missing required fields: email and name are required");
    }

    console.log(`📧 Attempting to send email to: ${email}, name: ${name}, role: ${role || 'not specified'}`);

    // Determine role label for better readability
    const roleLabels = {
      admin: "Administrador",
      manager: "Gerente", 
      doctor: "Médico",
      nurse: "Enfermeiro",
      receptionist: "Recepcionista",
      operator: "Operador",
      readonly: "Somente leitura",
      regulator: "Regulador",
    };
    
    const roleLabel = roleLabels[role] || role;
    console.log(`Role label determined: ${roleLabel}`);

    // First check if the user exists
    console.log("Checking if user exists in profiles...");
    const { data: userExists, error: checkError } = await supabase
      .from('profiles')
      .select('id')
      .eq('email', email)
      .maybeSingle();

    if (checkError) {
      console.error("❌ Error checking if user exists:", checkError);
      throw checkError;
    }

    console.log("User exists check result:", userExists ? "Found" : "Not found");

    const redirectUrl = siteUrl || `${supabaseUrl.replace('.supabase.co', '.lovable.app')}/login`;
    console.log(`Using redirect URL: ${redirectUrl}`);

    let result;
    if (userExists && userExists.id) {
      console.log("✓ User exists, sending magic link");
      // If user exists, send a magic link
      try {
        const { data, error } = await supabase.auth.admin.generateLink({
          type: "magiclink",
          email: email,
          options: {
            redirectTo: redirectUrl,
            data: {
              name: name,
              role: role,
              roleLabel: roleLabel
            }
          }
        });
        
        if (error) {
          console.error("❌ Error sending magic link:", error);
          throw error;
        }
        
        result = data;
        console.log("✅ Magic link sent successfully:", JSON.stringify({
          action: "generate_magic_link", 
          email: email,
          success: true,
          redirectUrl: redirectUrl
        }));
      } catch (magicLinkError) {
        console.error("❌ Exception sending magic link:", magicLinkError);
        throw magicLinkError;
      }
    } else {
      console.log("✓ User does not exist, sending invitation");
      // If user doesn't exist, send an invitation
      try {
        const { data, error } = await supabase.auth.admin.inviteUserByEmail(email, {
          redirectTo: redirectUrl,
          data: {
            name: name,
            role: role,
            roleLabel: roleLabel
          }
        });
        
        if (error) {
          console.error("❌ Error sending invitation:", error);
          throw error;
        }
        
        result = data;
        console.log("✅ Invitation sent successfully:", JSON.stringify({
          action: "invite_user", 
          email: email,
          success: true,
          redirectUrl: redirectUrl
        }));
      } catch (inviteError) {
        console.error("❌ Exception sending invitation:", inviteError);
        throw inviteError;
      }
    }

    console.log("📬 Email function completed successfully");
    
    return new Response(
      JSON.stringify({
        success: true,
        message: "E-mail de confirmação enviado com sucesso",
        result: result
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      }
    );
  } catch (error) {
    console.error("❌ Error in send-welcome-email function:", error);
    return new Response(
      JSON.stringify({
        success: false,
        message: error.message || "Falha ao enviar e-mail de confirmação",
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 400,
      }
    );
  }
});
