
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.38.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") || "";
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";

    if (!supabaseUrl || !supabaseServiceKey) {
      throw new Error("Missing environment variables SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY");
    }

    // Initialize the Supabase client with the service role key (ADMIN)
    const supabase = createClient(supabaseUrl, supabaseServiceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      }
    });

    // Get the request body
    const { email, password, name, role } = await req.json();

    if (!email || !password || !name || !role) {
      throw new Error("Missing required fields: email, password, name, and role are required");
    }

    console.log(`Creating user with email: ${email} and role: ${role}`);

    // Create the user using the admin API
    const { data: user, error: createUserError } = await supabase.auth.admin.createUser({
      email,
      password,
      email_confirm: true, // Auto-confirm the email
      user_metadata: { name }
    });

    if (createUserError) {
      console.error("Error creating user:", createUserError);
      throw createUserError;
    }

    if (!user || !user.user) {
      throw new Error("User creation failed without an error message");
    }

    console.log(`User created successfully with ID: ${user.user.id}`);

    // Update the profile with the role
    const { error: updateProfileError } = await supabase
      .from("profiles")
      .update({ role })
      .eq("id", user.user.id);

    if (updateProfileError) {
      console.error("Error updating user profile:", updateProfileError);
      throw updateProfileError;
    }

    return new Response(JSON.stringify({
      success: true,
      message: "Usuário criado com sucesso",
      userId: user.user.id,
    }), { 
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200 
    });
    
  } catch (error) {
    console.error("Error in create-user function:", error);
    return new Response(JSON.stringify({
      success: false,
      message: error.message || "Falha ao criar usuário",
    }), { 
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 400 
    });
  }
});
