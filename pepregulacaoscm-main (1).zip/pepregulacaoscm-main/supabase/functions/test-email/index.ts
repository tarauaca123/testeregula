
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  console.log("🧪 test-email function started");
  
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    console.log("Handling CORS preflight request");
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    if (!supabaseUrl) {
      throw new Error("SUPABASE_URL environment variable not set");
    }

    // Get email from the request - no default email anymore
    let email = '';
    try {
      const body = await req.json();
      if (body.email) {
        email = body.email;
      } else {
        throw new Error("No email provided in request");
      }
    } catch (e) {
      throw new Error("No valid JSON body with email field provided");
    }

    if (!email) {
      throw new Error("Email is required");
    }

    console.log(`Testing email send to: ${email}`);

    // Call the send-welcome-email function
    const response = await fetch(`${supabaseUrl}/functions/v1/send-welcome-email`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        test: true,
        email: email,
        name: "Test User",
        role: "admin"
      })
    });

    const result = await response.json();
    console.log("Email test result:", result);

    return new Response(
      JSON.stringify({
        success: response.ok,
        status: response.status,
        result: result
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      }
    );
  } catch (error) {
    console.error("❌ Error in test-email function:", error);
    return new Response(
      JSON.stringify({
        success: false,
        message: error.message || "Failed to test email sending",
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 400,
      }
    );
  }
});
